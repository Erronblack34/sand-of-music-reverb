# Sand of Music Reverb 0.6.5 — build and test status

## Implemented

- WorkManager foreground worker for long-running audio rendering.
- Live progress from FFmpeg statistics, Android progress notification, and cancellation from both the app and notification.
- Language, presets, media library and controls remain accessible during processing.
- Background file metadata reads, media-library scan, and export copy.
- Album-art track cards, artist/album/duration metadata, search and sorting.
- Adaptive FFmpeg thread budget and throttled progress updates.
- Keeps completed render files when the Android save picker is cancelled or a destination write fails.
- Retains broad audio/video import, MP4 audio extraction, MP3/WAV export and Loki identity.

## Checks passed in the local environment

- Kotlin parser check: no syntax/parser diagnostics were found in the app source files.
- DSP smoke test: duration, pitch/speed separation, reverb tail, finite output, peak guard and stereo isolation all passed.
- FFmpeg CLI smoke test on a 5:05 source WAV: 320 kbps MP3 output created and probed successfully (6:12.1 output with slowed setting and reverb tail).
- MP4 smoke test: the first audio stream was extracted from a video+audio MP4 into an MP3 file successfully.

## Not yet verified

A full Android Gradle APK build was not run in this local container because Gradle and the Android SDK are not installed here. The included GitHub Actions workflow is the required final build check. Do not treat the APK as build-verified until that workflow completes successfully.
