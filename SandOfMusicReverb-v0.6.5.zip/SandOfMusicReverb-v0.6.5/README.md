# Sand of Music Reverb 0.6.5

Offline Android audio workstation for Slowed + Reverb, Nightcore and custom mixes.

## 0.6.5 changes

- **Background rendering:** long jobs run through Android WorkManager as a foreground task. You can leave the app, lock the phone, and continue using the interface while the export runs.
- **Live progress:** a real percentage is derived from FFmpeg's processed audio timestamp. The current stage and processed time are displayed in the app and Android notification.
- **Cancellation:** stop rendering from the app or from the notification. The source file is never modified.
- **Responsive interface:** language, presets, knobs, library and track selection remain available while a render is running. Only conflicting render buttons are disabled.
- **Safer export:** the final copy to the chosen Android folder also runs in the background. If saving fails or the picker is cancelled, the rendered file is kept for another attempt.
- **Faster balanced encoding:** FFmpeg uses a small adaptive CPU thread budget and throttled progress updates to avoid excessive notification/database churn.
- **Improved music library:** album artwork cards, track title, artist, album and duration, background scanning, instant search and title/artist sorting.
- **Metadata reads are asynchronous**, so opening a large or remote file does not freeze the main screen.
- Retains multi-format import, MP4 audio extraction, MP3/WAV export and the Loki-inspired app mark from 0.5.0.

## Import formats

The picker accepts audio and video containers. Common formats include MP3, WAV, M4A/AAC, FLAC, OGG/Vorbis, Opus, MP4, WebM and MKV, depending on the codecs bundled with FFmpeg. For video files, the first audio stream is extracted and the picture is ignored.

Damaged, encrypted or DRM-protected files may still fail. Very large files require enough free storage for a temporary copy and the rendered result. Processing speed depends on the device, file duration, codec and selected effects.

## Processing behavior

- Rendering is performed off the UI thread by a long-running WorkManager foreground worker.
- The Android notification includes the processing stage, percentage and a Cancel action.
- Progress represents the media time FFmpeg has processed; it is not a guessed countdown.
- If the app is force-stopped, Android is rebooted, or the OS terminates the process under exceptional conditions, the job may be interrupted. Battery/performance restrictions can also affect throughput.
- The app asks for notification permission on Android 13+ so background progress is visible in the notification shade. Processing can still run if notification permission is denied, but visibility may be reduced by Android.

## Audio controls

- Speed: 0.50x–1.60x.
- Pitch: -12 to +12 semitones.
- Reverb: 0–65%.
- PRO mode includes room size, 5-band EQ and peak protection.
- WAV export: 16-bit PCM.
- MP3 export: 320 kbps; preview MP3: 192 kbps.

## Build

Requirements: JDK 17, Android SDK Platform 35, Build Tools 35.0.0, Gradle 8.9.

```bash
gradle --no-daemon --stacktrace assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Engine and license notes

The media import/render/export pipeline uses the maintained Android FFmpegKit distribution (`dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9`). The full package includes the audio codec bundle used for decoding and LAME MP3 encoding. See `THIRD_PARTY_NOTICES.md` and the package's bundled third-party notices for component-level licenses.

All media processing is local on the device. Input files are copied to app cache for decoding; temporary input copies are deleted after a job. Completed renders are kept in the app's private `files/renders` folder until they are successfully exported.
