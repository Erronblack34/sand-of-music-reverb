# Sand of Music Reverb 1.2.0

Android music player and offline audio workstation. This update extends the 1.0.0 foundation with a live FFT visualizer, searchable genre/style selection, instrumental-oriented processing profiles, reverse rendering, and a direct action sheet after applying a combination.

## 1.2.0 additions
- Live neon spectrum visualizer using Android `Visualizer` FFT capture. It requests microphone/audio-capture permission only when opened. On Android builds that restrict global output capture, availability depends on device and playback session.
- Searchable genre and remix-style pickers.
- Four instrumental-oriented processing profiles: Clean, Cinematic, Wide Space, and Punch. These are processing presets, not automatic vocal removal.
- Reverse Audio render option, applied to the complete processed output using FFmpeg `areverse`. Long tracks may require additional temporary storage and processing time.
- After applying a genre/style combination, a direct action panel offers preview, WAV export, MP3 export, or continued manual editing.

## Retained 1.0.0 capabilities
- 95 genre profiles and 13 original styles, expanded to 17 styles in 1.2.0 (95 × 17 = 1,615 combinations).
- MediaStore library, queue playback, expanded player, 10-second long-press seek, background rendering with WorkManager, FFmpeg audio processing, Media3 playback service, and per-track settings.

## Vocal / instrumental separation status
High-quality vocal/instrumental separation is **not included in this build**. Reliable offline separation requires bundling and validating a compatible on-device model (for example, a Demucs-family model converted for Android inference). Simple center/side cancellation is not equivalent and would produce misleading results on many stereo tracks. This is kept as a separate implementation milestone rather than presenting a low-quality filter as real stem separation.

## Build
Upload `SandOfMusicReverb-v1.2.0.zip` to the repository root and replace `.github/workflows/build-apk.yml` with the supplied v1.2 workflow. GitHub Actions produces `SandOfMusicReverb_v1.2.apk`.

`applicationId` remains `com.sandofmusic.reverb`. APK update compatibility still depends on using the same signing key as the installed build.
