# Sand of Music Reverb 1.0.0

Android music player and audio editor with an expanded genre × processing-style matrix, MediaStore library, continuous queue, full-screen player, and background rendering.

## Version 1.0.0
- 95 selectable genre profiles (23 existing + 72 additions) and 13 processing styles: 1,235 combinations.
- Added Euro Folk, Russian Rock, Russian Post-Punk, Russian Folk Rock, Opera, Aria, Bel Canto, Operetta, regional/traditional styles, additional metal subgenres, electronic and dance/roots genres.
- Library drill-down navigation now keeps a back stack. Android Back and an in-library Back button return from an album/artist/folder/genre track list to its parent list before closing the library.
- Tapping the mini-player title opens a dedicated full-screen player.
- Long-press previous/next jumps 10 seconds backward/forward; short taps retain previous/next track behavior.
- Successful WAV/MP3 renders are immediately played while the export-save dialog is offered; a playing render is kept until playback ends.
- Media3 playback explicitly handles Android audio focus. Local preview playback also requests/releases audio focus and responds to interruption/duck events.
- Existing WorkManager foreground processing is retained, with a completion notification that opens the app.
- App label remains “Sand of Music Reverb”; applicationId remains `com.sandofmusic.reverb`; versionCode 100 / versionName 1.0.0.

## Audio focus behavior
Playback pauses or ducks when Android reports an audio-focus interruption (for example, a call or another app's media session). Android does not expose a universal notification that any unrelated app has merely opened its microphone; apps that request audio focus and system-managed interruptions are handled.

## Build
Use `.github/workflows/build-apk.yml` in the repository. The workflow expects `SandOfMusicReverb-v1.0.0.zip` in the repository root and publishes an artifact named `SandOfMusicReverb_v1.0.apk`.
