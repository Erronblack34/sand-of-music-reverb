# Sand of Music Reverb 1.0.0 — technical plan and implementation notes

## Main objective
Make the app work as a comfortable music player and audio editor while preserving the working 0.9.0 DSP and library functionality.

## Implemented in this source update

### Library navigation
- Android Back and an in-library Back button return from a scoped genre/album/artist/folder track list to its parent section instead of closing the entire library.
- The parent section, search query, and list position are restored.
- The library dialog closes only when the user is already at its root.

### Player
- Tapping the mini-player title opens an expanded full-screen player view.
- The expanded player has play/pause, previous/next, seek bar, elapsed/total time, and track details.
- A long press on previous/next seeks backward/forward by 10 seconds; a short press keeps its previous/next-track meaning.
- Media3 queue transitions update the player title and artist/album details.

### Render result
- After a WAV/MP3 render completes, the app starts playing the new render immediately and then opens the normal save-location picker.
- An output file is not deleted while it is still needed by playback or an unfinished export copy.

### Audio interruptions
- Media3 playback enables Android audio-focus management.
- Local preview playback requests audio focus and responds to loss, transient loss, duck, and regain events.
- Android phone-call/system interruptions and other apps' audio-focus requests are handled through the platform focus system.
- Android does not provide a universal public callback for every unrelated app that merely opens the microphone without requesting audio focus; this cannot be guaranteed for all apps.

### Background processing
- Existing WorkManager foreground processing is retained.
- Progress notification and cancel action remain available.
- A completion notification opens the app after a render completes.

### Genre/style matrix
- 95 selectable genres, retaining all 23 original profiles and adding 72 new genres.
- 13 processing styles retained.
- Total: 1,235 distinct genre/style combinations.
- New families include Euro/Nordic/Celtic/Slavic/Balkan/Medieval/Neofolk/Dark Folk; Russian Rock/Punk/Post-Punk/Alternative/Indie/Folk Rock/Soviet Pop/Estrada/Chanson/Bard Song; Opera/Aria/Bel Canto/Operetta/Classical Vocal/Sacred/Choral/Art Song; regional and traditional genres; additional metal and electronic subgenres; and Italo Disco, Eurodance, Ska, Rocksteady, Dub, Flamenco, Fado and Tango.

### APK output
- The Android application label remains `Sand of Music Reverb`.
- The generated APK is copied to `SandOfMusicReverb_v1.0.apk` after the build.
- `applicationId` remains `com.sandofmusic.reverb`.
- `versionCode` is 100 and `versionName` is 1.0.0.
- APK signing setup is intentionally unchanged for this release, as requested. Updating an installed APK still requires the same signing key as the installed build.

## Validation performed on the prepared source
- 95 genre entries matched to 95 profile entries.
- 13 processing styles verified.
- 1,235 genre/style profiles validated and unique in the profile test.
- Existing DSP smoke tests passed.
- Feature smoke tests passed.
- XML files parsed successfully.

A full Android Gradle build has not been run in this preparation environment. GitHub Actions is the authoritative Android build check for the repository.
