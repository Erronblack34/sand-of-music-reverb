package com.sandofmusic.reverb

/** A genre profile is combined with a processing style; neither overwrites the other. */
object GenreStyleProfiles {
    data class Profile(
        val speed: Float,
        val pitchSemitones: Float,
        val reverbWet: Float,
        val roomSize: Float,
        val eqGainsDb: FloatArray,
        val displayName: String
    )
    private data class Genre(val eq: FloatArray, val wet: Float, val room: Float, val lowWeight: Float, val highWeight: Float)
    private data class Style(val speed: Float, val pitch: Float, val wetAdd: Float, val roomAdd: Float, val eq: FloatArray)

    private val baseGenres = mapOf(
        "hiphop" to Genre(floatArrayOf(2.6f,1.2f,-0.6f,1.0f,0.6f),0.12f,0.42f,1.0f,0.8f),
        "rock" to Genre(floatArrayOf(1.0f,-0.4f,1.2f,1.8f,1.0f),0.16f,0.48f,0.5f,1.0f),
        "jazz" to Genre(floatArrayOf(0.8f,0.7f,0.4f,0.2f,-0.4f),0.20f,0.38f,0.3f,0.4f),
        "afrobeats" to Genre(floatArrayOf(2.0f,0.8f,0.4f,1.0f,0.7f),0.13f,0.44f,0.9f,0.8f),
        "pop" to Genre(floatArrayOf(0.8f,0.2f,0.5f,0.8f,0.7f),0.14f,0.45f,0.5f,0.7f),
        "rnb" to Genre(floatArrayOf(1.8f,0.8f,-0.2f,0.5f,0.1f),0.22f,0.56f,0.8f,0.5f),
        "edm" to Genre(floatArrayOf(2.2f,0.6f,-0.4f,1.1f,1.2f),0.12f,0.55f,1.0f,1.0f),
        "phonk" to Genre(floatArrayOf(3.2f,1.6f,-1.0f,0.8f,0.5f),0.08f,0.32f,1.2f,0.5f),
        "reggae" to Genre(floatArrayOf(1.6f,0.3f,0.2f,-0.2f,0.2f),0.25f,0.62f,0.8f,0.3f),
        "lofi" to Genre(floatArrayOf(0.8f,0.2f,-0.8f,-1.2f,-2.0f),0.18f,0.52f,0.4f,0.2f),
        "reggaeton" to Genre(floatArrayOf(2.8f,1.0f,-0.5f,0.7f,0.5f),0.13f,0.42f,1.0f,0.7f),
        "trap" to Genre(floatArrayOf(3.0f,1.4f,-0.8f,0.9f,0.7f),0.09f,0.34f,1.1f,0.6f),
        "metal" to Genre(floatArrayOf(0.7f,-0.6f,1.5f,2.0f,1.1f),0.10f,0.35f,0.4f,1.0f),
        "classical" to Genre(floatArrayOf(0.2f,0.4f,0.5f,0.4f,0.2f),0.24f,0.68f,0.2f,0.4f),
        "soul" to Genre(floatArrayOf(1.4f,0.8f,0.3f,0.6f,0.2f),0.22f,0.54f,0.7f,0.5f),
        "disco" to Genre(floatArrayOf(1.2f,0.5f,0.1f,1.0f,1.0f),0.15f,0.48f,0.6f,0.9f),
        "drum_bass" to Genre(floatArrayOf(2.4f,0.5f,-0.7f,1.2f,1.0f),0.10f,0.40f,1.0f,0.9f),
        "dubstep" to Genre(floatArrayOf(2.8f,0.8f,-0.9f,0.8f,0.8f),0.12f,0.46f,1.1f,0.8f),
        "country" to Genre(floatArrayOf(0.8f,0.2f,0.7f,1.0f,0.6f),0.16f,0.42f,0.5f,0.8f),
        "latin" to Genre(floatArrayOf(1.8f,0.7f,0.4f,0.8f,0.6f),0.18f,0.48f,0.8f,0.7f),
        "kpop" to Genre(floatArrayOf(1.0f,0.4f,0.5f,1.1f,1.0f),0.14f,0.46f,0.6f,0.9f),
        "indie" to Genre(floatArrayOf(0.9f,0.1f,0.8f,1.0f,0.7f),0.18f,0.52f,0.5f,0.8f),
        "punk" to Genre(floatArrayOf(1.4f,-0.2f,1.3f,1.5f,0.8f),0.08f,0.30f,0.6f,0.8f)
    )
    private val extraGenres: Map<String, Genre> = GenreCatalog.options
        .filterNot { it.key in baseGenres }
        .mapIndexed { index, option ->
            val archetype = when (option.group) {
                "Folk", "Folk & Country" -> Genre(floatArrayOf(0.7f, 0.2f, 0.6f, 1.0f, 0.7f), 0.18f, 0.54f, 0.62f, 0.78f)
                "Russian Scene", "Rock" -> Genre(floatArrayOf(1.1f, -0.2f, 1.0f, 1.7f, 0.9f), 0.13f, 0.42f, 0.58f, 0.88f)
                "Classical Vocal" -> Genre(floatArrayOf(0.1f, 0.4f, 0.35f, 0.5f, 0.25f), 0.27f, 0.76f, 0.24f, 0.46f)
                "World & Traditional", "Latin", "World & Dance" -> Genre(floatArrayOf(1.2f, 0.55f, 0.35f, 0.75f, 0.45f), 0.23f, 0.63f, 0.72f, 0.66f)
                "Heavy & Alternative" -> Genre(floatArrayOf(0.8f, -0.45f, 1.55f, 1.9f, 1.05f), 0.10f, 0.36f, 0.46f, 0.94f)
                "Electronic & Experimental", "Electronic", "Pop & Global" -> Genre(floatArrayOf(1.9f, 0.65f, -0.65f, 0.95f, 1.0f), 0.13f, 0.49f, 0.92f, 0.86f)
                "Dance & Roots" -> Genre(floatArrayOf(1.45f, 0.55f, 0.15f, 0.95f, 0.9f), 0.18f, 0.56f, 0.78f, 0.82f)
                else -> Genre(floatArrayOf(0.8f, 0.25f, 0.45f, 0.8f, 0.65f), 0.17f, 0.5f, 0.55f, 0.7f)
            }
            val lowWeight = 0.20f + index * 0.0095f
            val highWeight = 0.30f + ((index * 37) % 72) * 0.009f
            val eqOffset = ((index % 5) - 2) * 0.045f
            option.key to Genre(
                FloatArray(5) { band -> (archetype.eq[band] + if (band == 0) eqOffset else eqOffset * (if (band % 2 == 0) 0.65f else -0.45f)) },
                (archetype.wet + (index % 4) * 0.006f).coerceIn(0.06f, 0.42f),
                (archetype.room + (index % 6) * 0.008f).coerceIn(0.25f, 0.88f),
                lowWeight,
                highWeight
            )
        }.toMap()

    private val genres = baseGenres + extraGenres

    private val styles = mapOf(
        "original" to Style(1f,0f,0f,0f,floatArrayOf(0f,0f,0f,0f,0f)),
        "slowed_reverb" to Style(0.78f,-2f,0.16f,0.18f,floatArrayOf(0.2f,0.1f,0f,-0.1f,-0.2f)),
        "nightcore" to Style(1.25f,4f,-0.08f,-0.14f,floatArrayOf(-0.2f,-0.1f,0.2f,0.8f,1.0f)),
        "daycore" to Style(0.88f,-1.5f,0.02f,0.02f,floatArrayOf(0.2f,0.1f,0f,-0.2f,-0.5f)),
        "vaporwave" to Style(0.78f,-3f,0.20f,0.22f,floatArrayOf(0.4f,0.1f,-0.4f,-0.8f,-1.2f)),
        "dreamy_reverb" to Style(0.90f,-0.5f,0.28f,0.30f,floatArrayOf(0f,0f,0.2f,0.1f,-0.2f)),
        "dark_reverb" to Style(0.84f,-2.5f,0.10f,0.16f,floatArrayOf(1.0f,0.3f,-0.2f,-0.6f,-1.0f)),
        "ambient" to Style(0.96f,0f,0.34f,0.38f,floatArrayOf(0.2f,0.3f,0.1f,-0.3f,-0.8f)),
        "super_slowed" to Style(0.62f,-4.5f,0.24f,0.28f,floatArrayOf(0.5f,0.2f,0f,-0.2f,-0.4f)),
        "ultra_slowed" to Style(0.52f,-6f,0.30f,0.34f,floatArrayOf(0.7f,0.3f,-0.1f,-0.3f,-0.6f)),
        "slowed" to Style(0.88f,-1f,0.08f,0.08f,floatArrayOf(0.2f,0.1f,0f,0f,-0.1f)),
        "speed_up" to Style(1.12f,2f,-0.04f,-0.06f,floatArrayOf(-0.1f,0f,0.1f,0.3f,0.4f)),
        "chipmunk" to Style(1.38f,7f,-0.08f,-0.12f,floatArrayOf(-0.2f,-0.1f,0.2f,0.6f,0.8f)),
        "instrumental_clean" to Style(1.00f,0f,0.02f,0.02f,floatArrayOf(0.2f,0.1f,0.1f,0.2f,0.1f)),
        "instrumental_cinematic" to Style(0.94f,0f,0.30f,0.34f,floatArrayOf(0.4f,0.2f,0.1f,0.3f,0.2f)),
        "instrumental_wide" to Style(1.00f,0f,0.22f,0.24f,floatArrayOf(0.1f,0.1f,0.0f,0.2f,0.3f)),
        "instrumental_punch" to Style(1.00f,0f,-0.05f,-0.04f,floatArrayOf(0.6f,0.3f,-0.1f,0.3f,0.1f))
    )

    fun combine(genreKey: String, styleKey: String): Profile {
        val genre = genres[genreKey] ?: genres.getValue("hiphop")
        val style = styles[styleKey] ?: styles.getValue("slowed_reverb")
        val eq = FloatArray(5) { i ->
            val genreWeight = when (i) { 0,1 -> genre.lowWeight; 3,4 -> genre.highWeight; else -> 1f }
            (genre.eq[i] + style.eq[i] * genreWeight).coerceIn(-6f, 6f)
        }
        val wet = (genre.wet + style.wetAdd * (0.75f + genre.lowWeight * 0.15f)).coerceIn(0f, 0.65f)
        val room = (genre.room + style.roomAdd * (0.75f + genre.highWeight * 0.15f)).coerceIn(0f, 1f)
        return Profile(style.speed, style.pitch, wet, room, eq, "$genreKey + $styleKey")
    }

    fun genreKeys(): Set<String> = genres.keys
    fun styleKeys(): Set<String> = styles.keys
    fun allCombinations(): Int = genres.size * styles.size
    fun validateProfiles(): Boolean = genres.keys.all { g -> styles.keys.all { s ->
        val p = combine(g, s)
        p.speed in 0.5f..1.6f && p.pitchSemitones in -12f..12f && p.reverbWet in 0f..0.65f && p.roomSize in 0f..1f && p.eqGainsDb.size == 5 && p.eqGainsDb.all { it in -6f..6f }
    } }
}
