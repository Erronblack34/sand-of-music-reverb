from pathlib import Path
root = Path(__file__).resolve().parents[1]
pkg = root / 'app/src/main/java/com/sandofmusic/reverb'
profiles = (pkg / 'GenreStyleProfiles.kt').read_text(encoding='utf-8')
catalog = (pkg / 'GenreCatalog.kt').read_text(encoding='utf-8')
activity = (pkg / 'MainActivity.kt').read_text(encoding='utf-8')
worker = (pkg / 'AudioRenderWorker.kt').read_text(encoding='utf-8')
service = (pkg / 'PlaybackService.kt').read_text(encoding='utf-8')
gradle = (root / 'app/build.gradle.kts').read_text(encoding='utf-8')
for token in ['"euro_folk"', '"russian_rock"', '"aria"', '"bel_canto"', '"tuvan_throat_singing"', '"witch_house"']:
    assert token in catalog, token
for token in ['showExpandedPlayer()', 'seekPlaybackBy(-10_000L)', 'seekPlaybackBy(10_000L)', 'navigationStack', 'playRenderedFile(outputFile)']:
    assert token in activity, token
assert 'setAudioAttributes(audioAttributes, true)' in service
assert 'showCompletionNotification()' in worker
assert 'versionCode = 100' in gradle and 'versionName = "1.0.0"' in gradle
assert 'applicationId = "com.sandofmusic.reverb"' in gradle
print('v1.0.0 source feature smoke checks: PASS')
