from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
pkg = root / "app/src/main/java/com/sandofmusic/reverb"
activity = (pkg / "MainActivity.kt").read_text(encoding="utf-8")
visual = (pkg / "SpectrumVisualizerView.kt").read_text(encoding="utf-8")
profiles = (pkg / "GenreStyleProfiles.kt").read_text(encoding="utf-8")
catalog = (pkg / "GenreCatalog.kt").read_text(encoding="utf-8")
pipeline = (pkg / "MediaPipeline.kt").read_text(encoding="utf-8")
worker = (pkg / "AudioRenderWorker.kt").read_text(encoding="utf-8")
manifest = (root / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
gradle = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
for token in ["requestVisualizer()", "showVisualizerDialog()", "Visualizer.OnDataCaptureListener", "showCombinationActions()", "KEY_REVERSE"]:
    assert token in activity, token
assert "updateFft" in visual and "Color.HSVToColor" in visual
assert "(i + 1).toDouble() / bars" in visual
assert "(i + 1).toFloat() / bars" not in visual
for token in ["instrumental_clean", "instrumental_cinematic", "instrumental_wide", "instrumental_punch"]:
    assert token in profiles, token
assert "if (settings.reverse) filters += \"areverse\"" in pipeline
assert "reverse = inputData.getBoolean(KEY_REVERSE, false)" in worker
assert "android.permission.RECORD_AUDIO" in manifest
assert "versionCode = 122" in gradle and 'versionName = "1.2.2"' in gradle
assert 'applicationId = "com.sandofmusic.reverb"' in gradle
genres = len(re.findall(r"GenreOption\(", catalog)) - 1
styles = len(re.findall(r'"[a-z_]+" to Style\(', profiles))
assert genres == 95, genres
assert styles == 17, styles
assert genres * styles == 1615
print(f"v1.2.2 feature smoke checks: PASS ({genres} genres × {styles} styles = {genres * styles} combinations)")

source = (Path(__file__).resolve().parents[1] / "app/src/main/java/com/sandofmusic/reverb/MainActivity.kt").read_text()
assert "showSearchablePicker(" in source
assert "selectorField(" in source
assert "AutoCompleteTextView(this)" not in source
assert "adapter.filter.filter" in source
print("v1.2.2 searchable selector checks passed")
