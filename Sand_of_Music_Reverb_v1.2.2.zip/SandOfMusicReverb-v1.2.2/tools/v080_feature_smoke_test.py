from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
src = root / "app/src/main/java/com/sandofmusic/reverb"
main = (src / "MainActivity.kt").read_text(encoding="utf-8")
profiles = (src / "GenreStyleProfiles.kt").read_text(encoding="utf-8")
langs = (src / "LanguageCatalog.kt").read_text(encoding="utf-8")
assert 'applyGenreStylePreset(selectedGenreKey, selectedStyleKey)' in main
assert 'private fun applyGenreStylePreset' in main
assert 'fun allCombinations(): Int = genres.size * styles.size' in profiles
assert len(re.findall(r'\"(?:hiphop|rock|jazz|afrobeats|pop|rnb|edm|phonk|reggae|lofi)\" to Genre', profiles)) == 10
assert len(re.findall(r'\"(?:original|slowed_reverb|nightcore|daycore|vaporwave|dreamy_reverb|dark_reverb|ambient)\" to Style', profiles)) == 8
for code in ('ko','es','pt','hi','ar','fa','fr'):
    assert f'Language(\"{code}\"' in langs
    assert f'\"{code}\" to mapOf(' in langs
print('v0.9.0 feature smoke tests passed: 23 genres x 13 styles, 7 added languages.')
