from pathlib import Path
root = Path(__file__).resolve().parents[1]
profiles = (root / 'app/src/main/java/com/sandofmusic/reverb/GenreStyleProfiles.kt').read_text(encoding='utf-8')
activity = (root / 'app/src/main/java/com/sandofmusic/reverb/MainActivity.kt').read_text(encoding='utf-8')
assert '"reggaeton"' in profiles and '"drum_bass"' in profiles and '"ultra_slowed"' in profiles
assert 'GenreCatalog.options' in activity
assert 'trackSettingsKey' in activity and 'saveCurrentTrackSettings' in activity and 'loadTrackSettings' in activity
assert 'navigationStack' in activity and 'showExpandedPlayer()' in activity
build = (root / 'app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionCode = 100' in build and 'versionName = "1.0.0"' in build
print('v1.0.0 inherited-feature smoke checks: PASS')
