# Build status — Sand of Music Reverb 1.2.1

Patch release correcting a Kotlin Float/Double type mismatch in SpectrumVisualizerView.kt. The faulty exponent argument is now Double, matching java.lang.Math.pow(Double, Double). Feature smoke tests cover visualizer wiring, searchable genre/style pickers, instrumental profiles, reverse-render flag propagation, retained features, and the corrected numeric type.

The user's previous GitHub Actions run verified archive integrity and source smoke checks, then failed at Kotlin compilation on this exact type mismatch. The corrected source has passed the local Python source checks. A complete Android Gradle build has not been run in this preparation environment; confirm the APK build in GitHub Actions.

High-quality vocal/instrumental stem separation is intentionally not included; it requires a separate offline inference model and device-performance validation.
