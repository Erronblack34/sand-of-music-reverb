# Sand of Music Reverb 1.2.1 — technical plan

## Implemented in this source update
1. Live FFT spectrum visualizer with neon multicolor bars, a separate visualizer dialog, and runtime audio-capture permission request.
2. Searchable genre and processing-style selectors.
3. Four instrumental-oriented processing profiles: Clean, Cinematic, Wide Space, Punch.
4. Immediate post-combination action panel: preview, WAV export, MP3 export, continue editing.
5. Reverse Audio processing flag propagated from UI to WorkManager and FFmpeg `areverse`.
6. Existing player, library, queue, per-track settings, background render and genre catalog retained.

## Not included yet
True vocal/instrumental stem separation. A robust offline implementation requires a packaged and tested on-device ML model, Android inference runtime, memory/performance budgeting, and quality validation on the target device. Classical center/side cancellation is not an equivalent replacement.

## Validation
Source-level smoke tests are included. Full Gradle build and real-device tests must be confirmed by GitHub Actions and the target Android device.


## Patch 1.2.1
Corrected the FFT visualizer frequency-bin exponent argument to use Double, fixing the Kotlin compiler error reported by GitHub Actions. The patch increments versionCode to 121 and versionName to 1.2.1.
