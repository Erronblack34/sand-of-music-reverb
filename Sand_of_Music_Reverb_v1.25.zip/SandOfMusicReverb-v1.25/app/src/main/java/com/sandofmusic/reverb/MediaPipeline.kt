package com.sandofmusic.reverb

import android.content.Context
import android.net.Uri
import android.media.MediaMetadataRetriever
import android.provider.OpenableColumns
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt

/** Disk-backed FFmpeg pipeline with copy and encoder progress reporting. */
object MediaPipeline {
    enum class OutputFormat { WAV, MP3 }

    data class Settings(
        val speed: Float,
        val pitchSemitones: Float,
        val reverbWet: Float,
        val roomSize: Float,
        val eqGainsDb: FloatArray,
        val limiterEnabled: Boolean,
        val reverse: Boolean = false,
        val fadeInSeconds: Float = 0f,
        val fadeOutSeconds: Float = 0f,
        val compressorEnabled: Boolean = false,
        val compressorThresholdDb: Float = -18f,
        val compressorRatio: Float = 2f
    )

    fun render(
        context: Context,
        sourceUri: Uri,
        outputFile: File,
        settings: Settings,
        format: OutputFormat,
        mp3Bitrate: String = "320k",
        onProgress: (String, Int) -> Unit = { _, _ -> },
        shouldCancel: () -> Boolean = { false },
        trimStartMs: Long = 0L,
        trimEndMs: Long = -1L
    ) {
        val sourceFile = copySourceToCache(context, sourceUri, onProgress, shouldCancel)
        try {
            val sourceDuration = durationMs(sourceFile)
            val actualTrimDuration = (trimEndMs - trimStartMs).takeIf { trimEndMs > trimStartMs } ?: sourceDuration
            runFfmpeg(
                source = sourceFile,
                output = outputFile,
                filters = buildFilters(settings, trimDurationMs = actualTrimDuration),
                format = format,
                mp3Bitrate = mp3Bitrate,
                onProgress = onProgress,
                shouldCancel = shouldCancel,
                durationScale = settings.speed.coerceIn(0.5f, 1.6f),
                trimStartMs = trimStartMs.coerceAtLeast(0L),
                trimEndMs = trimEndMs
            )
        } finally {
            sourceFile.delete()
        }
    }

    fun makeOriginalPreview(
        context: Context,
        sourceUri: Uri,
        outputFile: File,
        onProgress: (String, Int) -> Unit = { _, _ -> },
        shouldCancel: () -> Boolean = { false }
    ) {
        val sourceFile = copySourceToCache(context, sourceUri, onProgress, shouldCancel)
        try {
            runFfmpeg(
                source = sourceFile,
                output = outputFile,
                filters = listOf("aresample=44100"),
                format = OutputFormat.MP3,
                mp3Bitrate = "192k",
                onProgress = onProgress,
                shouldCancel = shouldCancel,
                durationScale = 1f
            )
        } finally {
            sourceFile.delete()
        }
    }

    private fun copySourceToCache(
        context: Context,
        uri: Uri,
        onProgress: (String, Int) -> Unit,
        shouldCancel: () -> Boolean
    ): File {
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Android could not open the selected file.")
        val totalBytes = querySize(context, uri)
        val file = File(context.cacheDir, "sand_source_${System.nanoTime()}.media")
        try {
            input.use { stream ->
                file.outputStream().buffered().use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    var copied = 0L
                    var lastReported = -1
                    while (true) {
                        if (shouldCancel()) throw InterruptedException("Processing cancelled.")
                        val count = stream.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        copied += count
                        if (totalBytes != null && totalBytes > 0L) {
                            val percent = ((copied.toDouble() / totalBytes) * 10.0).roundToInt().coerceIn(1, 10)
                            if (percent != lastReported) {
                                onProgress("Копирование исходного файла", percent)
                                lastReported = percent
                            }
                        } else if (copied > 0 && lastReported < 5) {
                            onProgress("Копирование исходного файла", 5)
                            lastReported = 5
                        }
                    }
                }
            }
        } catch (error: Exception) {
            file.delete()
            throw error
        }
        if (!file.exists() || file.length() == 0L) {
            file.delete()
            throw IllegalArgumentException("The selected file is empty or could not be copied.")
        }
        onProgress("Файл подготовлен", 10)
        return file
    }

    private fun querySize(context: Context, uri: Uri): Long? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (index >= 0 && !cursor.isNull(index)) cursor.getLong(index) else null
            } else null
        }
    } catch (_: Exception) {
        null
    }

    private fun durationMs(file: File): Long? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
        } catch (_: Exception) {
            null
        } finally {
            try { retriever.release() } catch (_: Exception) { }
        }
    }

    private fun runFfmpeg(
        source: File,
        output: File,
        filters: List<String>,
        format: OutputFormat,
        mp3Bitrate: String,
        onProgress: (String, Int) -> Unit,
        shouldCancel: () -> Boolean,
        durationScale: Float,
        trimStartMs: Long = 0L,
        trimEndMs: Long = -1L
    ) {
        output.parentFile?.mkdirs()
        output.delete()
        // Use a small adaptive thread budget: faster than single-thread rendering
        // without allowing FFmpeg to occupy every CPU core on a mobile device.
        val cpuCount = Runtime.getRuntime().availableProcessors().coerceAtLeast(2)
        val renderThreads = (cpuCount / 2).coerceIn(2, 4)
        val filterThreads = renderThreads.coerceAtMost(2)
        val args = mutableListOf(
            "-hide_banner", "-loglevel", "error", "-y"
        )
        if (trimStartMs > 0L) args += listOf("-ss", decimalMs(trimStartMs))
        if (trimEndMs > trimStartMs) args += listOf("-t", decimalMs(trimEndMs - trimStartMs))
        args += listOf(
            "-i", source.absolutePath,
            "-map", "0:a:0", "-vn", "-sn", "-dn",
            "-af", filters.joinToString(","),
            "-ar", "44100", "-ac", "2",
            "-threads", renderThreads.toString(),
            "-filter_threads", filterThreads.toString(),
            "-filter_complex_threads", filterThreads.toString(),
            "-stats_period", "0.5"
        )
        when (format) {
            OutputFormat.WAV -> args += listOf("-c:a", "pcm_s16le", "-f", "wav")
            OutputFormat.MP3 -> args += listOf("-c:a", "libmp3lame", "-b:a", mp3Bitrate, "-f", "mp3")
        }
        args += output.absolutePath

        val sourceDuration = durationMs(source)
        val effectiveDuration = if (trimEndMs > trimStartMs) trimEndMs - trimStartMs else sourceDuration
        val expectedOutputDuration = effectiveDuration?.let { (it / durationScale.coerceIn(0.5f, 1.6f)).toLong().coerceAtLeast(1L) }
        val latch = CountDownLatch(1)
        var failureMessage: String? = null
        var lastProgressPercent = -1
        var lastProgressAt = 0L

        onProgress("Обработка аудио", 11)
        FFmpegKit.executeWithArgumentsAsync(
            args.toTypedArray(),
            { session ->
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    val details = session.failStackTrace ?: session.output ?: "FFmpeg could not decode this file."
                    failureMessage = readableFfmpegError(details)
                }
                latch.countDown()
            },
            { /* FFmpeg log output is intentionally not forwarded to the UI. */ },
            { statistics ->
                val currentTime = statistics.time.coerceAtLeast(0.0)
                val percent = if (expectedOutputDuration != null) {
                    (10 + (currentTime.toDouble() / expectedOutputDuration * 85.0).roundToInt()).coerceIn(11, 95)
                } else {
                    50
                }
                val now = System.nanoTime()
                // Avoid flooding WorkManager's progress database and notifications.
                if (percent != lastProgressPercent || now - lastProgressAt >= TimeUnit.SECONDS.toNanos(2)) {
                    lastProgressPercent = percent
                    lastProgressAt = now
                    onProgress("Обработка аудио · ${formatDuration(currentTime.toLong())}", percent)
                }
            }
        )

        try {
            while (!latch.await(350, TimeUnit.MILLISECONDS)) {
                if (shouldCancel()) {
                    FFmpegKit.cancel()
                    try { latch.await(10, TimeUnit.SECONDS) } catch (_: InterruptedException) { }
                    throw InterruptedException("Processing cancelled.")
                }
            }
        } catch (error: InterruptedException) {
            FFmpegKit.cancel()
            try { latch.await(10, TimeUnit.SECONDS) } catch (_: InterruptedException) { }
            output.delete()
            throw error
        }

        if (shouldCancel()) {
            output.delete()
            throw InterruptedException("Processing cancelled.")
        }
        failureMessage?.let {
            output.delete()
            throw IllegalArgumentException(it)
        }
        if (!output.exists() || output.length() <= 44L) {
            output.delete()
            throw IllegalStateException("FFmpeg finished without creating a usable audio file.")
        }
        onProgress("Финальная проверка файла", 98)
    }

    private fun readableFfmpegError(details: String): String = when {
        details.contains("matches no streams", ignoreCase = true) ->
            "Аудиодорожка не найдена. Выбери видеофайл, в котором есть звук."
        details.contains("Invalid data", ignoreCase = true) ->
            "Файл повреждён или его аудиоформат не поддерживается."
        details.contains("Unknown encoder", ignoreCase = true) ->
            "В этой сборке не найден аудиокодек для выбранного формата экспорта."
        else -> details.lineSequence().filter { it.isNotBlank() }.toList().takeLast(5).joinToString(" ").take(700)
    }

    private fun formatDuration(milliseconds: Long): String {
        val seconds = milliseconds / 1000
        return "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
    }

    private fun buildFilters(settings: Settings, trimDurationMs: Long? = null): List<String> {
        val filters = mutableListOf<String>()
        val pitchRatio = 2.0.pow(settings.pitchSemitones.coerceIn(-12f, 12f) / 12.0).toFloat()
        val speed = settings.speed.coerceIn(0.5f, 1.6f)

        filters += "aresample=44100"
        if (abs(pitchRatio - 1f) > 0.0005f) {
            filters += "asetrate=${decimal(44100f * pitchRatio)}"
            filters += "aresample=44100"
        }
        var tempo = speed / pitchRatio
        while (tempo < 0.5f) {
            filters += "atempo=0.5"
            tempo /= 0.5f
        }
        while (tempo > 2f) {
            filters += "atempo=2.0"
            tempo /= 2f
        }
        if (abs(tempo - 1f) > 0.0005f) filters += "atempo=${decimal(tempo)}"

        val wet = settings.reverbWet.coerceIn(0f, 0.65f)
        if (wet > 0.001f) {
            val room = settings.roomSize.coerceIn(0f, 1f)
            val delays = listOf(31, 47, 71, 89).joinToString("|") { (it * (0.78f + room * 0.52f)).toInt().toString() }
            val decays = listOf(0.32f, 0.24f, 0.17f, 0.11f).joinToString("|") { decimal(it * wet) }
            filters += "aecho=0.92:0.92:$delays:$decays"
        }

        val frequencies = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
        settings.eqGainsDb.take(10).forEachIndexed { index, gain ->
            if (abs(gain) >= 0.05f) {
                filters += "equalizer=f=${frequencies[index]}:t=q:w=1:g=${decimal(gain.coerceIn(-12f, 12f))}"
            }
        }
        if (settings.compressorEnabled) {
            val threshold = settings.compressorThresholdDb.coerceIn(-36f, -3f)
            val ratio = settings.compressorRatio.coerceIn(1f, 8f)
            filters += "acompressor=threshold=${decimal(dbToLinear(threshold))}:ratio=${decimal(ratio)}:attack=15:release=180:makeup=1"
        }
        val fadeIn = settings.fadeInSeconds.coerceIn(0f, 20f)
        val fadeOut = settings.fadeOutSeconds.coerceIn(0f, 20f)
        if (fadeIn > 0.01f) filters += "afade=t=in:st=0:d=${decimal(fadeIn)}:curve=qsin"
        if (fadeOut > 0.01f && trimDurationMs != null && trimDurationMs > 0L) {
            val outputDuration = trimDurationMs / 1000f / speed
            val fadeDuration = fadeOut.coerceAtMost(outputDuration)
            filters += "afade=t=out:st=${decimal((outputDuration - fadeDuration).coerceAtLeast(0f))}:d=${decimal(fadeDuration)}:curve=qsin"
        }
        if (settings.limiterEnabled) filters += "alimiter=limit=0.92:level=0"
        // Reverse is applied last so the complete processed result is played backwards.
        if (settings.reverse) filters += "areverse"
        return filters
    }

    private fun decimal(value: Float): String = String.format(Locale.US, "%.5f", value)
    private fun decimalMs(value: Long): String = String.format(Locale.US, "%.3f", value.coerceAtLeast(0L) / 1000.0)
    private fun dbToLinear(db: Float): Float = 10f.pow(db / 20f)

    /** Decode up to three minutes to mono float PCM and reduce it to a compact waveform envelope. */
    fun analyzeWaveform(context: Context, uri: Uri, bins: Int = 240): FloatArray {
        val source = copySourceToCache(context, uri, { _, _ -> }, { false })
        val raw = File(context.cacheDir, "sand_wave_${System.nanoTime()}.f32")
        try {
            val session = FFmpegKit.executeWithArguments(arrayOf(
                "-hide_banner", "-loglevel", "error", "-y", "-i", source.absolutePath,
                "-t", "1800", "-vn", "-ac", "1", "-ar", "1000", "-f", "f32le", "-acodec", "pcm_f32le", raw.absolutePath
            ))
            if (!ReturnCode.isSuccess(session.returnCode) || !raw.exists() || raw.length() < 4L) {
                throw IllegalStateException("Не удалось построить форму волны для этого файла.")
            }
            val bytes = raw.readBytes()
            val count = bytes.size / 4
            val envelope = FloatArray(bins.coerceIn(64, 600))
            val buffer = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            for (i in envelope.indices) {
                val start = i * count / envelope.size
                val end = ((i + 1) * count / envelope.size).coerceAtLeast(start + 1).coerceAtMost(count)
                var peak = 0f
                for (sample in start until end) peak = maxOf(peak, kotlin.math.abs(buffer.getFloat(sample * 4)))
                envelope[i] = peak.coerceIn(0f, 1f)
            }
            return envelope
        } finally {
            source.delete()
            raw.delete()
        }
    }

    /** Create approximate stereo center/side exports. This is NOT neural vocal separation. */
    fun splitCenterSide(source: File, centerOutput: File, sideOutput: File): Pair<File, File> {
        fun run(filter: String, output: File) {
            output.parentFile?.mkdirs()
            val session = FFmpegKit.executeWithArguments(arrayOf(
                "-hide_banner", "-loglevel", "error", "-y", "-i", source.absolutePath,
                "-vn", "-af", filter, "-ar", "44100", "-ac", "2", "-c:a", "libmp3lame", "-b:a", "256k", output.absolutePath
            ))
            if (!ReturnCode.isSuccess(session.returnCode) || !output.exists() || output.length() <= 128L) {
                output.delete()
                throw IllegalStateException(session.failStackTrace ?: session.output ?: "Stem export failed")
            }
        }
        run("pan=stereo|c0=0.5*c0+0.5*c1|c1=0.5*c0+0.5*c1", centerOutput)
        run("pan=stereo|c0=0.5*c0-0.5*c1|c1=0.5*c1-0.5*c0", sideOutput)
        return centerOutput to sideOutput
    }
}
