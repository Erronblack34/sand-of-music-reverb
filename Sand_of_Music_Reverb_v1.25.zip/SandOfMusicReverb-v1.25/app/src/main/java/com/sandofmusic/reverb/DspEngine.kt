package com.sandofmusic.reverb

import kotlin.math.*

/** User-facing processing parameters. Speed controls duration; pitch is independent. */
data class DspSettings(
    val speed: Float = 0.82f,
    val pitchSemitones: Float = -2f,
    val reverbWet: Float = 0.24f,
    val roomSize: Float = 0.52f,
    val eqGainsDb: FloatArray = FloatArray(10),
    val limiterEnabled: Boolean = true
)

/** Offline DSP pipeline shared by preview rendering and WAV export. */
object DspEngine {
    private val eqFrequencies = floatArrayOf(31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)
    private const val MAX_RENDER_SAMPLES = 30_000_000L

    fun process(input: FloatArray, sampleRate: Int, channels: Int, settings: DspSettings): FloatArray {
        require(channels in 1..2) { "Only mono and stereo audio are supported." }
        require(sampleRate in 8000..192000) { "Unsupported sample rate: $sampleRate" }
        require(input.isNotEmpty() && input.size % channels == 0) { "The audio stream is empty or malformed." }

        val speed = settings.speed.coerceIn(0.5f, 1.6f)
        val pitchRatio = 2.0.pow(settings.pitchSemitones.coerceIn(-12f, 12f) / 12.0).toFloat()
        val sourceFrames = input.size / channels
        val intermediateSamples = (sourceFrames / pitchRatio).roundToLong() * channels
        val finalSamples = (sourceFrames / speed).roundToLong() * channels
        val tailSeconds = if (settings.reverbWet > 0.001f) (0.30f + settings.roomSize.coerceIn(0f, 1f) * 0.85f) else 0f
        val totalSamples = finalSamples + (sampleRate * tailSeconds * channels).roundToLong()
        require(intermediateSamples <= MAX_RENDER_SAMPLES && totalSamples <= MAX_RENDER_SAMPLES) {
            "These settings would create a very large audio render. Shorten the track or use less extreme speed/pitch values."
        }

        var audio = input
        // Windowed-sinc interpolation reduces aliasing and graininess compared with cubic resampling.
        if (abs(pitchRatio - 1f) > 0.0005f) {
            audio = resampleForPitch(audio, channels, pitchRatio)
        }
        val stretchSpeed = speed / pitchRatio
        if (abs(stretchSpeed - 1f) > 0.015f) {
            audio = wsolaTimeStretch(audio, sampleRate, channels, stretchSpeed)
        } else if (audio === input) {
            audio = input.copyOf()
        }

        if (settings.reverbWet > 0.001f) {
            val tailFrames = (sampleRate * tailSeconds).roundToInt()
            if (tailFrames > 0) audio = audio.copyOf(audio.size + tailFrames * channels)
            applyReverb(
                audio,
                sampleRate,
                channels,
                settings.reverbWet.coerceIn(0f, 0.65f),
                settings.roomSize.coerceIn(0f, 1f)
            )
        }
        applyEqualizer(audio, sampleRate, channels, settings.eqGainsDb)
        applyEdgeFades(audio, channels, sampleRate)
        // Keep peaks below digital full scale without hard-clipping individual transients.
        applyPeakGuard(audio, if (settings.limiterEnabled) 0.92f else 0.985f)
        return audio
    }

    /** 12-tap windowed-sinc sample-rate conversion, applied identically per channel. */
    private fun resampleForPitch(input: FloatArray, channels: Int, ratio: Float): FloatArray {
        val inputFrames = input.size / channels
        val outputFrames = max(1, (inputFrames / ratio).roundToInt())
        val output = FloatArray(outputFrames * channels)
        val radius = 6
        val cutoff = min(1f, 1f / ratio) * 0.94f
        for (frame in 0 until outputFrames) {
            val position = frame * ratio
            val center = floor(position).toInt()
            for (channel in 0 until channels) {
                var weighted = 0.0
                var weightSum = 0.0
                for (tap in (center - radius + 1)..(center + radius)) {
                    val distance = position - tap
                    if (abs(distance) >= radius) continue
                    val scaled = distance * cutoff
                    val sinc = if (abs(scaled) < 1e-7f) 1.0 else sin(PI * scaled) / (PI * scaled)
                    val window = 0.5 + 0.5 * cos(PI * distance / radius)
                    val weight = sinc * window * cutoff
                    val safeIndex = tap.coerceIn(0, inputFrames - 1)
                    weighted += input[safeIndex * channels + channel] * weight
                    weightSum += weight
                }
                output[frame * channels + channel] = if (abs(weightSum) > 1e-9) (weighted / weightSum).toFloat() else 0f
            }
        }
        return output
    }

    /** WSOLA: changes duration while largely preserving the pitch of the source. */
    private fun wsolaTimeStretch(input: FloatArray, sampleRate: Int, channels: Int, speed: Float): FloatArray {
        val inputFrames = input.size / channels
        if (inputFrames < 2048 || abs(speed - 1f) < 0.015f) return input.copyOf()
        val outputFrames = max(1, (inputFrames / speed).roundToInt())
        val output = FloatArray(outputFrames * channels)
        val window = (sampleRate * 0.042f).roundToInt().coerceIn(512, 4096).let { it - (it % 2) }
        val overlap = window / 2
        val synthesisHop = window - overlap
        val searchRadius = (sampleRate * 0.004f).roundToInt().coerceIn(32, 384)
        val maxInputStart = max(0, inputFrames - window)

        val firstCount = min(window, min(inputFrames, outputFrames))
        input.copyInto(output, 0, 0, firstCount * channels)
        var outputPosition = synthesisHop
        var expectedInputPosition = (synthesisHop * speed).roundToInt()

        while (outputPosition < outputFrames) {
            val availableOverlap = min(overlap, outputFrames - outputPosition)
            val low = (expectedInputPosition - searchRadius).coerceIn(0, maxInputStart)
            val high = (expectedInputPosition + searchRadius).coerceIn(low, maxInputStart)
            val candidate = findBestOverlap(input, output, channels, outputPosition, availableOverlap, low, high)

            for (i in 0 until availableOverlap) {
                // Cosine crossfade is smoother at segment joins than a linear ramp.
                val blend = if (availableOverlap <= 1) 1f else
                    (0.5 - 0.5 * cos(PI * i / (availableOverlap - 1))).toFloat()
                for (channel in 0 until channels) {
                    val outIndex = (outputPosition + i) * channels + channel
                    val inIndex = (candidate + i) * channels + channel
                    output[outIndex] = output[outIndex] * (1f - blend) + input[inIndex] * blend
                }
            }
            val copyStart = outputPosition + availableOverlap
            val sourceStart = candidate + availableOverlap
            val copyFrames = min(window - availableOverlap, outputFrames - copyStart)
            if (copyFrames > 0 && sourceStart + copyFrames <= inputFrames) {
                input.copyInto(output, copyStart * channels, sourceStart * channels, (sourceStart + copyFrames) * channels)
            }
            outputPosition += synthesisHop
            expectedInputPosition += (synthesisHop * speed).roundToInt()
        }
        return output
    }

    private fun findBestOverlap(
        input: FloatArray,
        output: FloatArray,
        channels: Int,
        outputPosition: Int,
        overlapFrames: Int,
        low: Int,
        high: Int
    ): Int {
        if (low >= high || overlapFrames < 8) return low
        val stride = 8
        var best = low
        var bestScore = Double.NEGATIVE_INFINITY
        for (candidate in low..high step 4) {
            var cross = 0.0
            var refEnergy = 1e-9
            var candidateEnergy = 1e-9
            var frame = 0
            while (frame < overlapFrames) {
                for (channel in 0 until channels) {
                    val a = output[(outputPosition + frame) * channels + channel].toDouble()
                    val b = input[(candidate + frame) * channels + channel].toDouble()
                    cross += a * b
                    refEnergy += a * a
                    candidateEnergy += b * b
                }
                frame += stride
            }
            val score = cross / sqrt(refEnergy * candidateEnergy)
            if (score > bestScore) { bestScore = score; best = candidate }
        }
        return best
    }

    /** Four decorrelated feedback delays with damped feedback and a conservative wet mix. */
    private fun applyReverb(audio: FloatArray, sampleRate: Int, channels: Int, wet: Float, room: Float) {
        if (wet <= 0.001f) return
        val roomScale = 0.82f + room * 0.34f
        val baseMs = floatArrayOf(29.7f, 37.1f, 41.1f, 43.7f)
        val feedback = 0.50f + room * 0.22f
        val damping = 0.16f + (1f - room) * 0.34f
        val delayLines = Array(channels) { channel ->
            Array(4) { line ->
                val stereoOffset = if (channel == 0) 0f else 1.3f
                val size = max(1, ((baseMs[line] + stereoOffset) * roomScale * sampleRate / 1000f).roundToInt())
                FloatArray(size)
            }
        }
        val indices = Array(channels) { IntArray(4) }
        val damped = Array(channels) { FloatArray(4) }
        val allpassSizes = intArrayOf(5, 1).map { max(1, (it * sampleRate / 1000f).roundToInt()) }
        val allpasses = Array(channels) { Array(2) { line -> FloatArray(allpassSizes[line]) } }
        val allpassIndices = Array(channels) { IntArray(2) }
        val allpassGain = 0.48f
        val dryGain = 1f - wet * 0.24f
        val wetGain = wet * 0.52f

        for (frame in audio.indices step channels) {
            for (channel in 0 until channels) {
                val index = frame + channel
                val dry = audio[index]
                var sum = 0f
                for (line in 0..3) {
                    val buffer = delayLines[channel][line]
                    val position = indices[channel][line]
                    val delayed = buffer[position]
                    damped[channel][line] += (delayed - damped[channel][line]) * damping
                    buffer[position] = dry + damped[channel][line] * feedback
                    indices[channel][line] = (position + 1) % buffer.size
                    sum += delayed
                }
                var diffuse = sum * 0.25f
                for (line in 0..1) {
                    val buffer = allpasses[channel][line]
                    val position = allpassIndices[channel][line]
                    val delayed = buffer[position]
                    val y = -allpassGain * diffuse + delayed
                    buffer[position] = diffuse + allpassGain * y
                    allpassIndices[channel][line] = (position + 1) % buffer.size
                    diffuse = y
                }
                audio[index] = dry * dryGain + diffuse * wetGain
            }
        }
    }

    private fun applyEqualizer(audio: FloatArray, sampleRate: Int, channels: Int, gains: FloatArray) {
        for (band in eqFrequencies.indices) {
            val gain = gains.getOrElse(band) { 0f }.coerceIn(-12f, 12f)
            if (abs(gain) < 0.05f) continue
            val filter = PeakingFilter(sampleRate.toFloat(), eqFrequencies[band].coerceAtMost(sampleRate * 0.45f), gain, 1.15f)
            val state1 = FloatArray(channels)
            val state2 = FloatArray(channels)
            for (i in audio.indices) {
                val channel = i % channels
                val x = audio[i]
                val y = filter.b0 * x + state1[channel]
                state1[channel] = filter.b1 * x - filter.a1 * y + state2[channel]
                state2[channel] = filter.b2 * x - filter.a2 * y
                audio[i] = if (y.isFinite()) y else 0f
            }
        }
    }

    private fun applyEdgeFades(audio: FloatArray, channels: Int, sampleRate: Int) {
        val frames = audio.size / channels
        val fadeFrames = min(frames / 2, max(1, (sampleRate * 0.008f).roundToInt()))
        for (i in 0 until fadeFrames) {
            val gain = if (fadeFrames <= 1) 1f else (0.5 - 0.5 * cos(PI * i / fadeFrames)).toFloat()
            for (channel in 0 until channels) audio[i * channels + channel] *= gain
        }
        for (i in 0 until fadeFrames) {
            val frame = frames - fadeFrames + i
            val gain = if (fadeFrames <= 1) 0f else (0.5 + 0.5 * cos(PI * i / fadeFrames)).toFloat()
            for (channel in 0 until channels) audio[frame * channels + channel] *= gain
        }
    }

    /** Transparent global gain reduction; avoids harsh sample-by-sample clipping. */
    private fun applyPeakGuard(audio: FloatArray, ceiling: Float) {
        var peak = 0f
        for (sample in audio) if (abs(sample) > peak) peak = abs(sample)
        if (peak > ceiling && peak > 0f) {
            val gain = ceiling / peak
            for (i in audio.indices) audio[i] *= gain
        }
    }

    private class PeakingFilter(sampleRate: Float, frequency: Float, gainDb: Float, q: Float) {
        val b0: Float
        val b1: Float
        val b2: Float
        val a1: Float
        val a2: Float
        init {
            val a = 10.0.pow(gainDb / 40.0).toFloat()
            val omega = (2.0 * PI * frequency / sampleRate).toFloat()
            val alpha = sin(omega) / (2f * q)
            val cosine = cos(omega)
            val a0 = 1f + alpha / a
            b0 = (1f + alpha * a) / a0
            b1 = (-2f * cosine) / a0
            b2 = (1f - alpha * a) / a0
            a1 = (-2f * cosine) / a0
            a2 = (1f - alpha / a) / a0
        }
    }
}
