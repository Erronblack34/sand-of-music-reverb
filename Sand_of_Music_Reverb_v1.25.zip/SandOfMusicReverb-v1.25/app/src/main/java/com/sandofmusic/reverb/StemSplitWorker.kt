package com.sandofmusic.reverb

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.work.ForegroundInfo
import android.provider.MediaStore
import androidx.work.Data
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File

/** Offline stereo center/side splitter. It is an approximation, not an ML vocal remover. */
class StemSplitWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
    override fun doWork(): Result {
        val uri = inputData.getString(KEY_URI)?.let(Uri::parse) ?: return Result.failure()
        val label = inputData.getString(KEY_NAME) ?: "SandAudio"
        val tempSource = File(applicationContext.cacheDir, "stem_source_${id}.media")
        val center = File(applicationContext.cacheDir, "${id}_center.mp3")
        val side = File(applicationContext.cacheDir, "${id}_side.mp3")
        return try {
            setForegroundAsync(createForegroundInfo()).get()
            applicationContext.contentResolver.openInputStream(uri)?.use { input ->
                tempSource.outputStream().buffered().use { output -> input.copyTo(output) }
            } ?: return Result.failure()
            if (isStopped) return Result.failure()
            MediaPipeline.splitCenterSide(tempSource, center, side)
            if (isStopped) return Result.failure()
            val centerUri = publish(center, "${safe(label)}_center_approx.mp3")
            val sideUri = publish(side, "${safe(label)}_side_approx.mp3")
            Result.success(Data.Builder()
                .putString(KEY_CENTER_URI, centerUri.toString())
                .putString(KEY_SIDE_URI, sideUri.toString())
                .build())
        } catch (e: Exception) {
            Result.failure(Data.Builder().putString(KEY_ERROR, e.message ?: "Stem split failed").build())
        } finally {
            tempSource.delete(); center.delete(); side.delete()
        }
    }

    private fun createForegroundInfo(): ForegroundInfo {
        val channelId = "sand_stem_processing"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Stem processing", NotificationManager.IMPORTANCE_LOW)
            applicationContext.getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(applicationContext, channelId)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(applicationContext)
        }.setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Sand of Music Reverb")
            .setContentText("Создание CENTER / SIDE дорожек…")
            .setOngoing(true)
            .build()
        return ForegroundInfo(5127, notification)
    }

    private fun publish(file: File, name: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Sand of Music Reverb")
        }
        val uri = applicationContext.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create output media entry")
        try {
            applicationContext.contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
                ?: throw IllegalStateException("Could not open output media stream")
            return uri
        } catch (e: Exception) {
            applicationContext.contentResolver.delete(uri, null, null)
            throw e
        }
    }

    private fun safe(value: String) = value.substringBeforeLast('.').replace(Regex("[^A-Za-zА-Яа-я0-9_-]+"), "_").trim('_').ifBlank { "SandAudio" }.take(48)

    companion object {
        const val KEY_URI = "source_uri"
        const val KEY_NAME = "source_name"
        const val KEY_CENTER_URI = "center_uri"
        const val KEY_SIDE_URI = "side_uri"
        const val KEY_ERROR = "error"
    }
}
