package com.sandofmusic.reverb

import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.ContentValues
import android.content.ComponentName
import android.content.res.ColorStateList
import android.database.Cursor
import android.database.ContentObserver
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.media.MediaPlayer
import android.media.AudioManager
import android.media.AudioFocusRequest
import android.media.AudioAttributes as PlatformAudioAttributes
import android.media.MediaMetadataRetriever
import android.media.audiofx.Visualizer
import android.Manifest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.content.pm.PackageManager
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Toast
import android.widget.TextView
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.Executor
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.lifecycle.Observer
import androidx.lifecycle.LiveData
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) showMusicLibrary()
        else showMessage(t("Без доступа к аудиофайлам медиатека не сможет показать песни.", "Allow audio access to display your music library."))
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Notifications are optional; background rendering continues without them. */ }

    private val visualizerPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) showVisualizerDialog()
        else showMessage(t("Для визуализатора нужно разрешение на аудиозахват.", "Visualizer needs audio capture permission."))
    }

    private val batchPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (!uris.isNullOrEmpty()) {
            uris.forEach { uri -> runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
            showBatchFormatDialog(uris)
        }
    }

    private var selectedUri: Uri? = null
    private var sourceName = ""
    private var sourceDetails = ""
    private var speed = 0.82f
    private var pitch = -2f
    private var reverb = 0.24f
    private var roomSize = 0.52f
    private val eqGains = FloatArray(10)
    private var fadeInSeconds = 0f
    private var fadeOutSeconds = 0f
    private var compressorEnabled = false
    private var compressorThresholdDb = -18f
    private var compressorRatio = 2f
    private var limiterEnabled = true
    private var proMode = false
    private var languageCode = "ru"
    private var english = false
    private var busy = false
    private var activeWorkId: UUID? = null
    private var activeWorkObserver: Observer<WorkInfo?>? = null
    private var activeWorkLiveData: LiveData<WorkInfo?>? = null
    private var activeWorkAction: String = AudioRenderWorker.ACTION_RENDER
    private var activeWorkSourceName: String = "SandOfMusic"
    private var activeWorkProgress = 0
    private var activeWorkStage = ""
    private var workCompletionHandled = false
    private val albumArtExecutor = Executors.newFixedThreadPool(2)
    private val albumArtCache = object : LruCache<Long, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }
    private var player: MediaPlayer? = null
    private var mediaController: MediaController? = null
    private var controllerFuture: com.google.common.util.concurrent.ListenableFuture<MediaController>? = null
    private var playbackListener: Player.Listener? = null
    private var pendingLibraryQueue: List<LibraryTrack>? = null
    private var pendingLibraryQueueStart = 0
    private var playerPrepared = false
    private var previewCacheFile: File? = null
    private var pendingExport: File? = null
    private var isSeeking = false
    private var expandedPlayerDialog: Dialog? = null
    private var expandedPlayerTitle: TextView? = null
    private var expandedPlayerSubtitle: TextView? = null
    private var expandedPlayerTime: TextView? = null
    private var expandedPlayerSeek: SeekBar? = null
    private var expandedPlayerPlayButton: Button? = null
    private var isExpandedPlayerSeeking = false
    private var spectrumVisualizer: Visualizer? = null
    private var spectrumDialog: Dialog? = null
    private var spectrumView: SpectrumVisualizerView? = null
    private var stemWorkObserver: Observer<WorkInfo?>? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var resumeLocalAfterFocusGain = false
    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                resumeLocalAfterFocusGain = false
                try { player?.pause() } catch (_: Exception) { }
                updateTransportUi()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeLocalAfterFocusGain = try { player?.isPlaying == true } catch (_: Exception) { false }
                try { player?.pause() } catch (_: Exception) { }
                updateTransportUi()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                try { player?.setVolume(0.22f, 0.22f) } catch (_: Exception) { }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                try { player?.setVolume(1f, 1f) } catch (_: Exception) { }
                if (resumeLocalAfterFocusGain) {
                    try { player?.start() } catch (_: Exception) { }
                    resumeLocalAfterFocusGain = false
                }
                updateTransportUi()
            }
        }
        updateExpandedPlayerUi()
    }
    private var selectedGenreKey = "hiphop"
    private var selectedStyleKey = "slowed_reverb"
    private var reverseAudioEnabled = false

    private lateinit var content: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var cancelWorkButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var trackTitle: TextView
    private lateinit var trackDetails: TextView
    private lateinit var renderButton: Button
    private lateinit var mp3ExportButton: Button
    private lateinit var previewButton: Button
    private lateinit var sourcePreviewButton: Button
    private lateinit var playPauseButton: Button
    private lateinit var transportTitle: TextView
    private lateinit var transportTime: TextView
    private lateinit var transportSeek: SeekBar

    private val backgroundColor = Color.rgb(5, 12, 22)
    private val cardColor = Color.rgb(13, 27, 42)
    private val cardAlt = Color.rgb(17, 37, 53)
    private val cyan = Color.rgb(53, 224, 210)
    private val violet = Color.rgb(177, 113, 255)
    private val muted = Color.rgb(132, 161, 181)
    private val white = Color.rgb(233, 246, 255)
    private val handler = Handler(Looper.getMainLooper())

    private val progressTicker = object : Runnable {
        override fun run() {
            val controller = mediaController
            if (controller != null && controller.mediaItemCount > 0) {
                try {
                    val duration = controller.duration.takeIf { it > 0 && it != C.TIME_UNSET } ?: 0L
                    val position = controller.currentPosition.coerceAtLeast(0L)
                    if (!isSeeking && duration > 0L) transportSeek.progress = ((position * 1000L) / duration).toInt().coerceIn(0, 1000)
                    transportTime.text = "${formatTime(position.toInt())} / ${formatTime(duration.toInt())}"
                    updateExpandedPlayerUi()
                    handler.postDelayed(this, 350L)
                } catch (_: IllegalStateException) { updateTransportUi() }
            } else {
                val current = player
                if (current != null && playerPrepared) {
                    try {
                        val duration = current.duration.coerceAtLeast(1)
                        val position = current.currentPosition.coerceAtLeast(0)
                        if (!isSeeking) transportSeek.progress = ((position.toLong() * 1000L) / duration).toInt().coerceIn(0, 1000)
                        transportTime.text = "${formatTime(position)} / ${formatTime(duration)}"
                        updateExpandedPlayerUi()
                        handler.postDelayed(this, 250L)
                    } catch (_: IllegalStateException) { updateTransportUi() }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val preferences = getSharedPreferences("sand_settings", MODE_PRIVATE)
        languageCode = preferences.getString("language", if (preferences.getBoolean("english", false)) "en" else "ru") ?: "ru"
        if (LanguageCatalog.languages.none { it.code == languageCode }) languageCode = "ru"
        english = languageCode != "ru"
        proMode = preferences.getBoolean("pro", false)
        selectedGenreKey = preferences.getString("preset_genre", "hiphop") ?: "hiphop"
        selectedStyleKey = preferences.getString("preset_style", "slowed_reverb") ?: "slowed_reverb"
        reverseAudioEnabled = preferences.getBoolean("reverse_audio", false)
        fadeInSeconds = preferences.getFloat("fade_in_seconds", 0f)
        fadeOutSeconds = preferences.getFloat("fade_out_seconds", 0f)
        compressorEnabled = preferences.getBoolean("compressor_enabled", false)
        compressorThresholdDb = preferences.getFloat("compressor_threshold", -18f)
        compressorRatio = preferences.getFloat("compressor_ratio", 2f)
        window.statusBarColor = backgroundColor
        window.navigationBarColor = backgroundColor
        window.decorView.systemUiVisibility = 0
        activeWorkId = preferences.getString("active_work_id", null)?.let { runCatching { UUID.fromString(it) }.getOrNull() }
        activeWorkAction = preferences.getString("active_work_action", AudioRenderWorker.ACTION_RENDER) ?: AudioRenderWorker.ACTION_RENDER
        activeWorkSourceName = preferences.getString("active_work_source", "SandOfMusic") ?: "SandOfMusic"
        activeWorkAction = preferences.getString("pending_export_action", activeWorkAction) ?: activeWorkAction
        activeWorkSourceName = preferences.getString("pending_export_name", activeWorkSourceName) ?: activeWorkSourceName
        pendingExport = preferences.getString("pending_export_path", null)?.let { File(it).takeIf(File::exists) }
        buildUi()
        connectToPlaybackService()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch("android.permission.POST_NOTIFICATIONS")
        }
        activeWorkId?.let { observeWork(it) }
        if (activeWorkId == null && pendingExport != null) {
            handler.post { pendingExport?.let { launchExportSaveDialog(it, activeWorkSourceName, activeWorkAction) } }
        }
    }

    private fun t(ru: String, en: String) = LanguageCatalog.translate(languageCode, ru, en)

    private fun showLanguagePicker() {
        val labels = LanguageCatalog.languages.map { "${it.nativeName}  (${it.code.uppercase(Locale.ROOT)})" }.toTypedArray()
        val selected = LanguageCatalog.languages.indexOfFirst { it.code == languageCode }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(t("ЯЗЫК ПРИЛОЖЕНИЯ", "APP LANGUAGE"))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                languageCode = LanguageCatalog.languages[which].code
                english = languageCode != "ru"
                getSharedPreferences("sand_settings", MODE_PRIVATE).edit()
                    .putString("language", languageCode)
                    .putBoolean("english", english)
                    .apply()
                dialog.dismiss()
                buildUi()
                updateTransportUi()
            }
            .setNegativeButton(t("Закрыть", "Close"), null)
            .show()
    }

    private fun connectToPlaybackService() {
        if (mediaController != null || controllerFuture != null) return
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            if (isFinishing || isDestroyed) return@addListener
            try {
                val controller = future.get()
                mediaController = controller
                val listener = object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        runOnUiThread {
                            updateTransportUi()
                            if (isPlaying) {
                                handler.removeCallbacks(progressTicker)
                                handler.post(progressTicker)
                            } else handler.removeCallbacks(progressTicker)
                        }
                    }

                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        runOnUiThread {
                            val metadata = mediaItem?.mediaMetadata
                            val title = metadata?.title?.toString().orEmpty()
                            if (title.isNotBlank()) {
                                sourceName = title
                                if (::transportTitle.isInitialized) transportTitle.text = title
                                if (::trackTitle.isInitialized) trackTitle.text = title
                            }
                            val artist = metadata?.artist?.toString().orEmpty()
                            val album = metadata?.albumTitle?.toString().orEmpty()
                            sourceDetails = listOf(artist, album).filter { it.isNotBlank() }.joinToString(" · ")
                            if (::trackDetails.isInitialized) trackDetails.text = sourceDetails
                            updateTransportUi()
                        }
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        runOnUiThread { updateTransportUi() }
                    }
                }
                playbackListener = listener
                controller.addListener(listener)
                updateTransportUi()
                pendingLibraryQueue?.let { queue ->
                    val start = pendingLibraryQueueStart
                    pendingLibraryQueue = null
                    playLibraryQueue(queue, start)
                }
            } catch (error: Exception) {
                controllerFuture = null
                if (::statusText.isInitialized) statusText.text = t("Системный плеер пока недоступен: ${error.message}", "System player is unavailable: ${error.message}")
            }
        }, Executor { command -> command.run() })
    }

    private fun playLibraryQueue(tracks: List<LibraryTrack>, startIndex: Int) {
        if (tracks.isEmpty()) return
        val controller = mediaController
        if (controller == null) {
            pendingLibraryQueue = tracks
            pendingLibraryQueueStart = startIndex.coerceIn(0, tracks.lastIndex)
            connectToPlaybackService()
            showMessage(t("Подключаю системный плеер…", "Connecting to system player…"))
            return
        }
        stopLocalPreviewOnly()
        val items = tracks.map { track ->
            val metadata = MediaMetadata.Builder()
                .setTitle(track.title)
                .setArtist(track.artist)
                .setAlbumTitle(track.album)
                .apply {
                    if (track.albumId > 0L) setArtworkUri(Uri.parse("content://media/external/audio/albumart/${track.albumId}"))
                }
                .build()
            MediaItem.Builder()
                .setMediaId(track.uri.toString())
                .setUri(track.uri)
                .setMediaMetadata(metadata)
                .build()
        }
        try {
            controller.setMediaItems(items, startIndex.coerceIn(0, items.lastIndex), C.TIME_UNSET)
            controller.prepare()
            controller.play()
            transportTitle.text = tracks[startIndex.coerceIn(0, tracks.lastIndex)].title
            handler.removeCallbacks(progressTicker)
            handler.post(progressTicker)
            updateTransportUi()
        } catch (error: Exception) {
            showMessage(t("Не удалось запустить очередь: ${error.message}", "Could not start the playback queue: ${error.message}"))
        }
    }

    private fun stopLocalPreviewOnly() {
        handler.removeCallbacks(progressTicker)
        abandonLocalAudioFocus()
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        playerPrepared = false
        previewCacheFile?.let { file -> if (file != pendingExport) file.delete() }
        previewCacheFile = null
    }

    private fun requestLocalAudioFocus(): Boolean {
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        return if (Build.VERSION.SDK_INT >= 26) {
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    PlatformAudioAttributes.Builder()
                        .setUsage(PlatformAudioAttributes.USAGE_MEDIA)
                        .setContentType(PlatformAudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setOnAudioFocusChangeListener(audioFocusListener, handler)
                .setWillPauseWhenDucked(true)
                .build()
            audioFocusRequest = request
            audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(audioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
    }

    private fun abandonLocalAudioFocus() {
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= 26) {
            audioFocusRequest?.let { runCatching { audioManager.abandonAudioFocusRequest(it) } }
            audioFocusRequest = null
        } else {
            @Suppress("DEPRECATION")
            audioManager.abandonAudioFocus(audioFocusListener)
        }
        resumeLocalAfterFocusGain = false
    }

    private fun currentPlaybackPositionAndDuration(): Pair<Long, Long> {
        val controller = mediaController
        if (controller != null && controller.mediaItemCount > 0) {
            val duration = runCatching { controller.duration }.getOrDefault(C.TIME_UNSET)
            return controller.currentPosition.coerceAtLeast(0L) to duration.takeIf { it > 0 && it != C.TIME_UNSET }.orZero()
        }
        val local = player
        if (local != null && playerPrepared) {
            return runCatching { local.currentPosition.toLong() }.getOrDefault(0L) to runCatching { local.duration.toLong() }.getOrDefault(0L)
        }
        return 0L to 0L
    }

    private fun Long?.orZero(): Long = this ?: 0L

    private fun seekPlaybackTo(positionMs: Long) {
        val controller = mediaController
        if (controller != null && controller.mediaItemCount > 0) {
            val duration = runCatching { controller.duration }.getOrDefault(C.TIME_UNSET)
            val target = positionMs.coerceAtLeast(0L).let { value -> if (duration > 0 && duration != C.TIME_UNSET) value.coerceAtMost(duration) else value }
            controller.seekTo(target)
        } else if (playerPrepared) {
            val duration = runCatching { player?.duration?.toLong() ?: 0L }.getOrDefault(0L)
            val target = positionMs.coerceAtLeast(0L).let { value -> if (duration > 0L) value.coerceAtMost(duration) else value }
            player?.seekTo(target.toInt())
        }
        updateExpandedPlayerUi()
    }

    private fun seekPlaybackBy(deltaMs: Long) {
        val (position, duration) = currentPlaybackPositionAndDuration()
        if (duration <= 0L) return
        seekPlaybackTo((position + deltaMs).coerceIn(0L, duration))
        val label = if (deltaMs < 0L) "−10 сек" else "+10 сек"
        if (::statusText.isInitialized) statusText.text = label
        android.widget.Toast.makeText(this, label, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun requestVisualizer() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            visualizerPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            showVisualizerDialog()
        }
    }

    private fun showVisualizerDialog() {
        if (spectrumDialog?.isShowing == true) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
            setBackgroundColor(Color.rgb(4, 9, 20))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val heading = TextView(this).apply {
            text = "LIVE AUDIO VISUALIZER"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cyan)
        }
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(actionButton(t("Закрыть", "Close"), false) { spectrumDialog?.dismiss() }, params(dp(88), dp(38)))
        root.addView(header)
        addText(root, t("Спектр частот в реальном времени · цветные полосы реагируют на музыку", "Live frequency spectrum · colored bars react to the music"), 10, muted)
        val visual = SpectrumVisualizerView(this).apply {
            setBackgroundColor(Color.rgb(5, 13, 27))
        }
        spectrumView = visual
        root.addView(visual, params(-1, dp(260)).apply { topMargin = dp(16); bottomMargin = dp(12) })
        val visualModes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            SpectrumVisualizerView.Mode.BARS to t("Полосы", "Bars"),
            SpectrumVisualizerView.Mode.CIRCULAR to t("Круг", "Circular"),
            SpectrumVisualizerView.Mode.WAVE to t("Волна", "Wave")
        ).forEach { (mode, label) ->
            visualModes.addView(actionButton(label, mode == SpectrumVisualizerView.Mode.BARS) { spectrumView?.mode = mode },
                LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
        }
        root.addView(visualModes, params().apply { topMargin = dp(6) })
        addText(root, t("FFT-спектр реагирует на реальный звук. Если системный захват ограничен, визуализатор может быть доступен только для собственной сессии плеера.", "FFT spectrum follows live audio. If system capture is restricted, visualization may only work for the app's own playback session."), 10, muted)
        val dialog = Dialog(this)
        dialog.setContentView(root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), -2)
        dialog.setOnDismissListener {
            stopVisualizer()
            spectrumDialog = null
            spectrumView = null
        }
        spectrumDialog = dialog
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), -2)
        startVisualizer()
    }

    private fun startVisualizer() {
        stopVisualizer()
        try {
            // Session 0 requests the global output mix. Android may restrict it on some devices;
            // when local preview is active, bind directly to that player's audio session.
            val sessionId = player?.audioSessionId ?: 0
            val effect = Visualizer(sessionId)
            val range = Visualizer.getCaptureSizeRange()
            effect.captureSize = range[1]
            effect.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int) = Unit
                override fun onFftDataCapture(visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) runOnUiThread { spectrumView?.updateFft(fft) }
                }
            }, (Visualizer.getMaxCaptureRate() / 2).coerceAtLeast(1), false, true)
            effect.enabled = true
            spectrumVisualizer = effect
        } catch (error: Exception) {
            showMessage(t("Визуализатор недоступен на этом устройстве: ${error.message}", "Visualizer is unavailable on this device: ${error.message}"))
            android.widget.Toast.makeText(this, t("Не удалось подключить аудиоспектр", "Could not attach audio spectrum"), android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun stopVisualizer() {
        val effect = spectrumVisualizer
        spectrumVisualizer = null
        if (effect != null) {
            runCatching { effect.enabled = false }
            runCatching { effect.setDataCaptureListener(null, 0, false, false) }
            runCatching { effect.release() }
        }
    }

    private fun showExpandedPlayer() {
        if (expandedPlayerDialog?.isShowing == true) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(18), dp(22), dp(22))
            setBackgroundColor(backgroundColor)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val header = TextView(this).apply {
            text = t("СЕЙЧАС ИГРАЕТ", "NOW PLAYING")
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cyan)
        }
        top.addView(header, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(actionButton(t("Закрыть", "Close"), false) { expandedPlayerDialog?.dismiss() }, params(dp(92), dp(38)))
        root.addView(top)
        val art = TextView(this).apply {
            text = "♫"
            textSize = 82f
            gravity = Gravity.CENTER
            setTextColor(violet)
            background = roundedGradient(cardAlt, backgroundColor, dp(26), violet)
        }
        root.addView(art, params(dp(230), dp(230)).apply { topMargin = dp(34); bottomMargin = dp(26) })
        expandedPlayerTitle = TextView(this).apply {
            text = transportTitle.text?.toString().orEmpty().ifBlank { sourceName.ifBlank { t("Нет выбранного трека", "No track selected") } }
            textSize = 20f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
        }
        root.addView(expandedPlayerTitle, params())
        expandedPlayerSubtitle = TextView(this).apply {
            text = sourceDetails
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(muted)
        }
        root.addView(expandedPlayerSubtitle, params().apply { topMargin = dp(7) })
        expandedPlayerSeek = SeekBar(this).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(cyan)
            progressBackgroundTintList = ColorStateList.valueOf(0xff315165.toInt())
            thumbTintList = ColorStateList.valueOf(white)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        isExpandedPlayerSeeking = true
                        val duration = currentPlaybackPositionAndDuration().second
                        expandedPlayerTime?.text = "${formatTime((duration * progress / 1000L).toInt())} / ${formatTime(duration.toInt())}"
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) { isExpandedPlayerSeeking = true }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val duration = currentPlaybackPositionAndDuration().second
                    if (duration > 0L) seekPlaybackTo(duration * (seekBar?.progress ?: 0) / 1000L)
                    isExpandedPlayerSeeking = false
                }
            })
        }
        root.addView(expandedPlayerSeek, params().apply { topMargin = dp(18) })
        expandedPlayerTime = TextView(this).apply {
            text = "0:00 / 0:00"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(muted)
        }
        root.addView(expandedPlayerTime, params())
        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val previous = actionButton("|◀", false) { seekToPrevious() }.apply {
            textSize = 18f
            setOnLongClickListener { seekPlaybackBy(-10_000L); true }
        }
        controls.addView(previous, params(dp(64), dp(58)).apply { marginEnd = dp(12) })
        expandedPlayerPlayButton = actionButton("▶", true) { togglePlayback() }.apply { textSize = 22f }
        controls.addView(expandedPlayerPlayButton, params(dp(82), dp(66)))
        val next = actionButton("▶|", false) { seekToNext() }.apply {
            textSize = 18f
            setOnLongClickListener { seekPlaybackBy(10_000L); true }
        }
        controls.addView(next, params(dp(64), dp(58)).apply { marginStart = dp(12) })
        root.addView(controls)

        val dialog = Dialog(this)
        dialog.setContentView(root)
        dialog.setCancelable(true)
        dialog.setOnDismissListener {
            expandedPlayerDialog = null
            expandedPlayerTitle = null
            expandedPlayerSubtitle = null
            expandedPlayerTime = null
            expandedPlayerSeek = null
            expandedPlayerPlayButton = null
            isExpandedPlayerSeeking = false
        }
        expandedPlayerDialog = dialog
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(backgroundColor))
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        updateExpandedPlayerUi()
    }

    private fun updateExpandedPlayerUi() {
        val dialog = expandedPlayerDialog ?: return
        if (!dialog.isShowing) return
        val controller = mediaController
        val title = if (controller != null && controller.mediaItemCount > 0) {
            controller.currentMediaItem?.mediaMetadata?.title?.toString().orEmpty()
        } else ""
        expandedPlayerTitle?.text = title.ifBlank { transportTitle.text?.toString().orEmpty().ifBlank { sourceName } }
        expandedPlayerSubtitle?.text = sourceDetails
        val (position, duration) = currentPlaybackPositionAndDuration()
        if (!isExpandedPlayerSeeking && duration > 0L) {
            expandedPlayerSeek?.progress = ((position * 1000L) / duration).toInt().coerceIn(0, 1000)
        }
        expandedPlayerTime?.text = "${formatTime(position.toInt())} / ${formatTime(duration.toInt())}"
        val isPlaying = if (controller != null && controller.mediaItemCount > 0) controller.isPlaying else runCatching { player?.isPlaying == true }.getOrDefault(false)
        expandedPlayerPlayButton?.text = if (isPlaying) "Ⅱ" else "▶"
    }

    private fun seekToPrevious() {
        val controller = mediaController
        if (controller != null && controller.mediaItemCount > 0) controller.seekToPreviousMediaItem()
        else if (playerPrepared) player?.seekTo(0)
    }

    private fun seekToNext() {
        val controller = mediaController
        if (controller != null && controller.mediaItemCount > 0) controller.seekToNextMediaItem()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()
    private fun params(width: Int = ViewGroup.LayoutParams.MATCH_PARENT, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) = LinearLayout.LayoutParams(width, height)

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(backgroundColor)
            layoutDirection = if (languageCode == "ar" || languageCode == "fa") View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(backgroundColor)
            clipToPadding = false
            isFillViewport = true
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(16), dp(17), dp(22))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        buildTransportDock(root)
        setContentView(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.loki_emblem)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = t("Эмблема приложения", "Application emblem")
        }
        top.addView(actionButton("☰", false) { openMusicLibrary() }, params(dp(42), dp(42)).apply { marginEnd = dp(7) })
        top.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(10) })
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        addText(brand, "SAND / MUSIC", 23, white, true)
        addText(brand, "A U D I O   L A B   •   V 1.2", 10, cyan, true)
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(actionButton("🌐 ${languageCode.uppercase(Locale.ROOT)}", false) { showLanguagePicker() }, params(dp(72), dp(40)))
        content.addView(top)
        addSpace(content, 5)
        addText(content, t("СТУДИЯ ОБРАБОТКИ ЗВУКА", "OFFLINE AUDIO WORKSTATION"), 10, muted, true)
        addText(content, t("Формируй звук. Управляй атмосферой.", "Shape the sound. Control the atmosphere."), 13, cyan)
        addSpace(content, 15)

        val trackCard = card()
        addBadge(trackCard, t("SOURCE INPUT", "SOURCE INPUT"), cyan)
        trackTitle = addText(trackCard, if (sourceName.isBlank()) t("Трек ещё не выбран", "No track selected") else sourceName, 17, white, true)
        trackDetails = addText(trackCard, if (sourceDetails.isBlank()) t("Добавь аудио из медиатеки или файлов", "Add audio from your library or files") else sourceDetails, 11, muted)
        addSpace(trackCard, 9)
        trackCard.addView(actionButton(t("♫  Открыть медиатеку", "♫  Open music library"), true) { openMusicLibrary() }, params())
        trackCard.addView(actionButton(t("＋  Выбрать аудиофайл", "＋  Choose audio file"), false) { pickAudio() }, params().apply { topMargin = dp(7) })
        trackCard.addView(actionButton(t("✦  Открыть визуализатор", "✦  Open visualizer"), false) { requestVisualizer() }, params().apply { topMargin = dp(7) })
        content.addView(trackCard)
        addSpace(content, 15)

        val presetCard = card()
        addBadge(presetCard, t("GENRE + PROCESSING STYLE", "GENRE + PROCESSING STYLE"), violet)
        addText(presetCard, t("Сначала выбери жанр, затем способ обработки. Профили объединяются в отдельную комбинацию.", "Choose a genre first, then a processing style. Both profiles are combined into one sound preset."), 11, muted)

        val genreNames = GenreCatalog.options.map { option ->
            option.key to "${option.group} · ${option.label}"
        }
        val styleNames = listOf(
            "original" to "Original / Genre EQ", "slowed_reverb" to "Slowed + Reverb",
            "nightcore" to "Nightcore", "daycore" to "Daycore", "vaporwave" to "Vaporwave",
            "dreamy_reverb" to "Dreamy Reverb", "dark_reverb" to "Dark Reverb", "ambient" to "Ambient",
            "super_slowed" to "Super Slowed", "ultra_slowed" to "Ultra Slowed", "slowed" to "Slowed",
            "speed_up" to "Speed Up", "chipmunk" to "Chipmunk",
            "instrumental_clean" to "Instrumental · Clean", "instrumental_cinematic" to "Instrumental · Cinematic",
            "instrumental_wide" to "Instrumental · Wide Space", "instrumental_punch" to "Instrumental · Punch"
        )
        addSpace(presetCard, 7)
        addBadge(presetCard, t("1. МУЗЫКАЛЬНЫЙ ЖАНР", "1. MUSIC GENRE"), cyan)
        lateinit var genreSelector: TextView
        genreSelector = selectorField(genreNames.firstOrNull { it.first == selectedGenreKey }?.second ?: genreNames.first().second) {
            showSearchablePicker(
                t("ВЫБОР МУЗЫКАЛЬНОГО ЖАНРА", "SELECT MUSIC GENRE"),
                genreNames,
                selectedGenreKey
            ) { key, label ->
                selectedGenreKey = key
                getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putString("preset_genre", key).apply()
                genreSelectorTextUpdate(genreSelector, label)
            }
        }
        presetCard.addView(genreSelector, params(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))
        addSpace(presetCard, 8)
        addBadge(presetCard, t("2. СТИЛЬ ОБРАБОТКИ", "2. PROCESSING STYLE"), cyan)
        lateinit var styleSelector: TextView
        styleSelector = selectorField(styleNames.firstOrNull { it.first == selectedStyleKey }?.second ?: "Slowed + Reverb") {
            showSearchablePicker(
                t("ВЫБОР СТИЛЯ ОБРАБОТКИ", "SELECT PROCESSING STYLE"),
                styleNames,
                selectedStyleKey
            ) { key, label ->
                selectedStyleKey = key
                getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putString("preset_style", key).apply()
                genreSelectorTextUpdate(styleSelector, label)
            }
        }
        presetCard.addView(styleSelector, params(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))
        addSpace(presetCard, 9)
        presetCard.addView(actionButton(t("Применить комбинацию", "Apply combined preset"), true) {
            applyGenreStylePreset(selectedGenreKey, selectedStyleKey)
            handler.post { showCombinationActions() }
        }, params())
        addText(presetCard, t("После применения все параметры можно изменить вручную в регуляторах ниже.", "After applying, every parameter remains editable in the controls below."), 10, muted)
        content.addView(presetCard)
        addSpace(content, 15)

        val modeCard = card()
        addBadge(modeCard, t("WORKSPACE MODE", "WORKSPACE MODE"), cyan)
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modes.addView(actionButton(t("ПРОСТОЙ", "ESSENTIAL"), !proMode) {
            proMode = false
            getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putBoolean("pro", false).apply()
            buildUi()
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
        modes.addView(actionButton("PRO LAB", proMode) {
            proMode = true
            getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putBoolean("pro", true).apply()
            buildUi()
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) })
        modeCard.addView(modes)
        content.addView(modeCard)
        addSpace(content, 15)

        val controlCard = card()
        addBadge(controlCard, t("SOUND ENGINE / TOUCH DIALS", "SOUND ENGINE / TOUCH DIALS"), cyan)
        addText(controlCard, t("Коснись шкалы и поверни регулятор по дуге.", "Touch a dial and rotate along its arc."), 10, muted)
        val dialRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val speedDial = RotaryKnobView(this, t("Скорость", "SPEED"), 0.5f, 1.6f, speed, cyan) { "${fmt(it)}×" }
        speedDial.onValueChanged = { speed = it }
        val pitchDial = RotaryKnobView(this, t("Тон", "PITCH"), -12f, 12f, pitch, violet) { "${if (it > 0) "+" else ""}${it.roundToInt()} st" }
        pitchDial.onValueChanged = { pitch = it }
        val reverbDial = RotaryKnobView(this, t("Реверб", "REVERB"), 0f, 0.65f, reverb, cyan) { "${(it * 100).roundToInt()}%" }
        reverbDial.onValueChanged = { reverb = it }
        dialRow.addView(speedDial, LinearLayout.LayoutParams(0, dp(132), 1f))
        dialRow.addView(pitchDial, LinearLayout.LayoutParams(0, dp(132), 1f))
        dialRow.addView(reverbDial, LinearLayout.LayoutParams(0, dp(132), 1f))
        controlCard.addView(dialRow, params())

        if (proMode) {
            addSpace(controlCard, 6)
            addSlider(controlCard, t("Размер комнаты", "Room size"), 0, 100, (roomSize * 100).roundToInt(), { (it / 100f).also { v -> roomSize = v } }, { "$it%" })
            addSpace(controlCard, 4)
            addBadge(controlCard, t("ДЕСЯТИПОЛОСНЫЙ ЭКВАЛАЙЗЕР", "10-BAND EQUALIZER"), violet)
            val frequencies = listOf("31 Hz", "62 Hz", "125 Hz", "250 Hz", "500 Hz", "1 kHz", "2 kHz", "4 kHz", "8 kHz", "16 kHz")
            frequencies.forEachIndexed { index, name ->
                addSlider(controlCard, name, -12, 12, eqGains[index].roundToInt(), { eqGains[index] = it.toFloat() }, { "${if (it > 0) "+" else ""}$it dB" })
            }
            val limiter = CheckBox(this).apply {
                text = t("Защита пиков", "Peak protection")
                setTextColor(white)
                buttonTintList = ColorStateList.valueOf(cyan)
                isChecked = limiterEnabled
                setOnCheckedChangeListener { _, checked -> limiterEnabled = checked }
            }
            controlCard.addView(limiter)
            addText(controlCard, t("Защита снижает общий уровень только при необходимости, чтобы избежать жёсткого цифрового клиппинга.", "Peak protection lowers overall gain only when needed to avoid hard digital clipping."), 10, muted)
        }
        content.addView(controlCard)
        addSpace(content, 15)

        val actionsCard = card()
        addBadge(actionsCard, t("RENDER / MONITOR", "RENDER / MONITOR"), violet)
        val reverseToggle = CheckBox(this).apply {
            text = t("Reverse Audio — обработать трек задом наперёд", "Reverse Audio — render track backwards")
            setTextColor(white)
            buttonTintList = ColorStateList.valueOf(violet)
            isChecked = reverseAudioEnabled
            setOnCheckedChangeListener { _, checked ->
                reverseAudioEnabled = checked
                getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putBoolean("reverse_audio", checked).apply()
            }
        }
        actionsCard.addView(reverseToggle, params())
        sourcePreviewButton = actionButton(t("▶  Оригинал", "▶  Original"), false) { previewOriginal() }
        actionsCard.addView(sourcePreviewButton, params())
        previewButton = actionButton(t("♫  Создать предпрослушивание", "♫  Render preview"), false) { render(exportFormat = null) }
        actionsCard.addView(previewButton, params().apply { topMargin = dp(7) })
        renderButton = actionButton(t("↓  Экспортировать WAV", "↓  Export WAV"), true) {
            render(exportFormat = MediaPipeline.OutputFormat.WAV)
        }
        actionsCard.addView(renderButton, params().apply { topMargin = dp(7) })
        mp3ExportButton = actionButton(t("♫  Экспортировать MP3", "♫  Export MP3"), false) {
            render(exportFormat = MediaPipeline.OutputFormat.MP3)
        }
        actionsCard.addView(mp3ExportButton, params().apply { topMargin = dp(7) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            isIndeterminate = false
            visibility = View.GONE
            progressTintList = ColorStateList.valueOf(cyan)
            progressBackgroundTintList = ColorStateList.valueOf(0xff294254.toInt())
        }
        actionsCard.addView(progressBar, params(-1, dp(6)).apply { topMargin = dp(10) })
        statusText = addText(actionsCard, t("Готов к работе. Выбери трек или пресет.", "Ready. Select a track or preset."), 11, muted)
        cancelWorkButton = actionButton(t("Остановить обработку", "Cancel processing"), false) {
            activeWorkId?.let { WorkManager.getInstance(applicationContext).cancelWorkById(it) }
        }.apply { visibility = View.GONE }
        actionsCard.addView(cancelWorkButton, params().apply { topMargin = dp(5) })
        content.addView(actionsCard)
        addSpace(content, 14)

        val studioCard = card()
        addBadge(studioCard, t("MOBILE AUDIO STUDIO", "MOBILE AUDIO STUDIO"), violet)
        addText(studioCard, t("Инструменты редактирования, сравнения, пакетной обработки и пользовательских пресетов.", "Editing, comparison, batch-processing and custom-preset tools."), 10, muted)
        studioCard.addView(actionButton(t("〰 Waveform Editor · обрезка и Fade", "〰 Waveform Editor · trim and fade"), false) {
            showWaveformEditorDialog()
        }, params().apply { topMargin = dp(7) })
        studioCard.addView(actionButton(t("A/B Preview · оригинал / ремикс", "A/B Preview · original / remix"), false) {
            showAbPreviewDialog()
        }, params().apply { topMargin = dp(7) })
        studioCard.addView(actionButton(t("10-band Equalizer", "10-band Equalizer"), false) {
            showEqualizerDialog()
        }, params().apply { topMargin = dp(7) })
        studioCard.addView(actionButton(t("Сохранить / открыть пресеты", "Save / open custom presets"), false) {
            showCustomPresetsDialog()
        }, params().apply { topMargin = dp(7) })
        studioCard.addView(actionButton(t("Audio Mastering · компрессор", "Audio Mastering · compressor"), false) {
            showMasteringDialog()
        }, params().apply { topMargin = dp(7) })
        studioCard.addView(actionButton(t("Batch Processing · несколько треков", "Batch Processing · multiple tracks"), false) {
            batchPicker.launch(arrayOf("audio/*"))
        }, params().apply { topMargin = dp(7) })
        studioCard.addView(actionButton(t("STEM Split · центр / стороны (экспериментально)", "STEM Split · center / side (experimental)"), false) {
            showStemSplitDialog()
        }, params().apply { topMargin = dp(7) })
        if (proMode) {
            addSpace(studioCard, 8)
            addBadge(studioCard, t("FADE НА ВСЁМ ТРЕКЕ", "TRACK-WIDE FADES"), cyan)
            addSlider(studioCard, t("Fade In", "Fade In"), 0, 100, (fadeInSeconds * 10).roundToInt(), { fadeInSeconds = it / 10f }, { "${it / 10f}s" })
            addSlider(studioCard, t("Fade Out", "Fade Out"), 0, 100, (fadeOutSeconds * 10).roundToInt(), { fadeOutSeconds = it / 10f }, { "${it / 10f}s" })
        }
        content.addView(studioCard)

        addSpace(content, 17)
        addText(content, "SAND AUDIO ENGINE  •  LOCAL DSP  •  WAV / MP3", 9, muted, true).gravity = Gravity.CENTER
        addText(content, "v1.25 · Mobile Audio Studio", 9, muted).gravity = Gravity.CENTER
        updateBusyState(busy)
        updateTransportUi()
        if (activeWorkId != null && busy) updateWorkUi()
    }

    private fun buildTransportDock(root: LinearLayout) {
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(9), dp(14), dp(8))
            background = roundedGradient(cardAlt, cardColor, dp(18), cyan)
            elevation = dp(10).toFloat()
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titleBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        addText(titleBlock, "NOW PLAYING", 9, cyan, true)
        transportTitle = addText(titleBlock, t("Плеер готов к запуску", "Player ready"), 12, white, true)
        header.addView(titleBlock, LinearLayout.LayoutParams(0, -2, 1f))
        titleBlock.isClickable = true
        titleBlock.isFocusable = true
        titleBlock.setOnClickListener { showExpandedPlayer() }
        transportTitle.setOnClickListener { showExpandedPlayer() }
        val previousButton = actionButton("|◀", false) { seekToPrevious() }.apply {
            textSize = 12f
            setOnLongClickListener { seekPlaybackBy(-10_000L); true }
        }
        header.addView(previousButton, params(dp(38), dp(42)).apply { marginEnd = dp(4) })
        playPauseButton = actionButton("▶", true) { togglePlayback() }.apply { textSize = 17f }
        header.addView(playPauseButton, params(dp(48), dp(42)))
        val nextButton = actionButton("▶|", false) { seekToNext() }.apply {
            textSize = 12f
            setOnLongClickListener { seekPlaybackBy(10_000L); true }
        }
        header.addView(nextButton, params(dp(38), dp(42)).apply { marginStart = dp(4) })
        val stopButton = actionButton("■", false) { stopPlayback(); updateTransportUi() }.apply { textSize = 15f }
        header.addView(stopButton, params(dp(48), dp(42)).apply { marginStart = dp(7) })
        dock.addView(header)

        transportSeek = SeekBar(this).apply {
            max = 1000
            progress = 0
            progressTintList = ColorStateList.valueOf(cyan)
            progressBackgroundTintList = ColorStateList.valueOf(0xff315165.toInt())
            thumbTintList = ColorStateList.valueOf(white)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        isSeeking = true
                        val duration = try { mediaController?.duration?.takeIf { it > 0 && it != C.TIME_UNSET }?.toInt() ?: (player?.duration ?: 0) } catch (_: Exception) { 0 }
                        transportTime.text = "${formatTime(duration * progress / 1000)} / ${formatTime(duration)}"
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) { isSeeking = true }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val controller = mediaController
                    val duration = try { controller?.duration?.takeIf { it > 0 && it != C.TIME_UNSET }?.toInt() ?: (player?.duration ?: 0) } catch (_: Exception) { 0 }
                    if (duration > 0) {
                        val target = (duration.toLong() * (seekBar?.progress ?: 0) / 1000L).toLong()
                        try {
                            if (controller != null && controller.mediaItemCount > 0) controller.seekTo(target)
                            else if (playerPrepared) player?.seekTo(target.toInt())
                        } catch (_: Exception) { }
                    }
                    isSeeking = false
                }
            })
        }
        dock.addView(transportSeek, params().apply { topMargin = dp(-3) })
        transportTime = addText(dock, "0:00 / 0:00", 9, muted)
        root.addView(dock, params().apply { leftMargin = dp(12); rightMargin = dp(12); bottomMargin = dp(8) })
        updateTransportUi()
    }

    private fun selectorField(value: String, onOpen: () -> Unit): TextView = TextView(this).apply {
        text = "$value    ▾"
        textSize = 17f
        setTextColor(white)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = rounded(Color.rgb(17, 42, 59), dp(3), Color.rgb(35, 73, 94))
        isFocusable = true
        isClickable = true
        setOnClickListener { onOpen() }
    }

    private fun genreSelectorTextUpdate(view: TextView, label: String) {
        view.text = "$label    ▾"
    }

    private fun showSearchablePicker(
        title: String,
        options: List<Pair<String, String>>,
        selectedKey: String,
        onSelected: (String, String) -> Unit
    ) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(8))
        }
        val search = EditText(this).apply {
            hint = t("Поиск по списку…", "Search this list…")
            textSize = 15f
            setSingleLine(true)
            setTextColor(white)
            setHintTextColor(muted)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            background = rounded(cardAlt, dp(10), Color.rgb(48, 89, 112))
        }
        panel.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        addSpace(panel, 8)
        val list = ListView(this).apply {
            divider = android.graphics.drawable.ColorDrawable(Color.rgb(35, 58, 75))
            dividerHeight = dp(1)
            cacheColorHint = Color.TRANSPARENT
            isFastScrollEnabled = true
        }
        val labels = options.map { it.second }.toMutableList()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        list.adapter = adapter
        panel.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(340)))
        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(panel)
            .setNegativeButton(t("Закрыть", "Close"), null)
            .create()
        list.setOnItemClickListener { _, _, position, _ ->
            val label = adapter.getItem(position) ?: return@setOnItemClickListener
            val option = options.firstOrNull { it.second == label } ?: return@setOnItemClickListener
            onSelected(option.first, option.second)
            dialog.dismiss()
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter.filter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        dialog.show()
        dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        // Keep the current selection visible when the picker opens.
        val currentLabel = options.firstOrNull { it.first == selectedKey }?.second
        if (!currentLabel.isNullOrBlank()) {
            val index = labels.indexOf(currentLabel)
            if (index >= 0) list.setSelection(index)
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = roundedGradient(cardColor, Color.rgb(9, 20, 33), dp(18), Color.rgb(35, 73, 94))
        elevation = dp(2).toFloat()
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius.toFloat()
        stroke?.let { setStroke(dp(1), it) }
    }

    private fun roundedGradient(top: Int, bottom: Int, radius: Int, stroke: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(top, bottom)).apply {
            cornerRadius = radius.toFloat()
            setStroke(dp(1), stroke)
        }

    private fun addBadge(parent: LinearLayout, label: String, color: Int) {
        val badge = TextView(this).apply {
            text = "◈  $label"
            textSize = 9f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(color)
            letterSpacing = 0.06f
            setPadding(0, 0, 0, dp(7))
        }
        parent.addView(badge, params())
    }

    private fun addText(parent: LinearLayout, value: String, size: Int, color: Int, bold: Boolean = false): TextView {
        val view = TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
            isSingleLine = false
        }
        parent.addView(view, params())
        return view
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun actionButton(value: String, primary: Boolean, action: () -> Unit): Button = Button(this).apply {
        text = value
        setAllCaps(false)
        textSize = 11.5f
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setTextColor(if (primary) Color.rgb(4, 20, 28) else white)
        background = if (primary) roundedGradient(cyan, Color.rgb(35, 174, 178), dp(13), cyan)
            else rounded(Color.rgb(17, 42, 59), dp(13), Color.rgb(48, 89, 112))
        setPadding(dp(8), dp(3), dp(8), dp(3))
        minHeight = dp(40)
        stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun addSlider(
        parent: LinearLayout,
        title: String,
        minimum: Int,
        maximum: Int,
        initial: Int,
        changed: (Int) -> Unit,
        valueText: (Int) -> String
    ) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val label = TextView(this).apply { text = title; textSize = 11f; setTextColor(white) }
        val value = TextView(this).apply { text = valueText(initial); textSize = 10f; setTextColor(cyan); gravity = Gravity.END }
        row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(value, params(dp(84), -2))
        parent.addView(row, params())
        val seek = SeekBar(this).apply {
            max = maximum - minimum
            progress = (initial - minimum).coerceIn(0, max)
            progressTintList = ColorStateList.valueOf(violet)
            progressBackgroundTintList = ColorStateList.valueOf(0xff2b465b.toInt())
            thumbTintList = ColorStateList.valueOf(cyan)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + minimum
                value.text = valueText(v)
                changed(v)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        parent.addView(seek, params())
        addSpace(parent, 4)
    }

    private fun fmt(value: Float) = String.format(Locale.US, "%.2f", value)

    private fun trackSettingsKey(uri: Uri): String = "track_${uri.toString().hashCode()}"

    private fun saveCurrentTrackSettings() {
        getSharedPreferences("sand_settings", MODE_PRIVATE).edit()
            .putFloat("fade_in_seconds", fadeInSeconds)
            .putFloat("fade_out_seconds", fadeOutSeconds)
            .putBoolean("compressor_enabled", compressorEnabled)
            .putFloat("compressor_threshold", compressorThresholdDb)
            .putFloat("compressor_ratio", compressorRatio)
            .apply()
        val uri = selectedUri ?: return
        getSharedPreferences("sand_track_settings", MODE_PRIVATE).edit()
            .putFloat("${trackSettingsKey(uri)}_speed", speed)
            .putFloat("${trackSettingsKey(uri)}_pitch", pitch)
            .putFloat("${trackSettingsKey(uri)}_reverb", reverb)
            .putFloat("${trackSettingsKey(uri)}_room", roomSize)
            .putString("${trackSettingsKey(uri)}_eq", eqGains.joinToString(","))
            .putFloat("${trackSettingsKey(uri)}_fade_in", fadeInSeconds)
            .putFloat("${trackSettingsKey(uri)}_fade_out", fadeOutSeconds)
            .putBoolean("${trackSettingsKey(uri)}_compressor", compressorEnabled)
            .putFloat("${trackSettingsKey(uri)}_compressor_threshold", compressorThresholdDb)
            .putFloat("${trackSettingsKey(uri)}_compressor_ratio", compressorRatio)
            .putString("${trackSettingsKey(uri)}_genre", selectedGenreKey)
            .putString("${trackSettingsKey(uri)}_style", selectedStyleKey)
            .apply()
    }

    private fun loadTrackSettings(uri: Uri): Boolean {
        val prefs = getSharedPreferences("sand_track_settings", MODE_PRIVATE)
        val key = trackSettingsKey(uri)
        if (!prefs.contains("${key}_speed")) return false
        speed = prefs.getFloat("${key}_speed", speed)
        pitch = prefs.getFloat("${key}_pitch", pitch)
        reverb = prefs.getFloat("${key}_reverb", reverb)
        roomSize = prefs.getFloat("${key}_room", roomSize)
        eqGains.fill(0f)
        prefs.getString("${key}_eq", null)?.split(",")?.mapNotNull { it.toFloatOrNull() }?.take(10)?.forEachIndexed { i, v -> eqGains[i] = v }
        fadeInSeconds = prefs.getFloat("${key}_fade_in", fadeInSeconds)
        fadeOutSeconds = prefs.getFloat("${key}_fade_out", fadeOutSeconds)
        compressorEnabled = prefs.getBoolean("${key}_compressor", compressorEnabled)
        compressorThresholdDb = prefs.getFloat("${key}_compressor_threshold", compressorThresholdDb)
        compressorRatio = prefs.getFloat("${key}_compressor_ratio", compressorRatio)
        selectedGenreKey = prefs.getString("${key}_genre", selectedGenreKey) ?: selectedGenreKey
        selectedStyleKey = prefs.getString("${key}_style", selectedStyleKey) ?: selectedStyleKey
        return true
    }

    private fun showAbPreviewDialog() {
        val options = arrayOf(
            t("A · Прослушать оригинал", "A · Play original"),
            t("B · Прослушать обработанную версию", "B · Play processed version"),
            t("Закрыть", "Close")
        )
        AlertDialog.Builder(this)
            .setTitle(t("A/B PREVIEW", "A/B PREVIEW"))
            .setMessage(t("Сравнивай исходный и обработанный звук. Переключение повторно запускает нужный предпросмотр.", "Compare the source and processed sound. Each choice renders or opens the selected preview."))
            .setItems(options) { _, which ->
                when (which) {
                    0 -> previewOriginal()
                    1 -> render(exportFormat = null)
                }
            }.show()
    }

    private fun showEqualizerDialog() {
        val labels = listOf("31 Hz", "62 Hz", "125 Hz", "250 Hz", "500 Hz", "1 kHz", "2 kHz", "4 kHz", "8 kHz", "16 kHz")
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(8)) }
        labels.forEachIndexed { index, label ->
            addSlider(panel, label, -12, 12, eqGains[index].roundToInt(), { eqGains[index] = it.toFloat() }, { "${if (it > 0) "+" else ""}$it dB" })
        }
        AlertDialog.Builder(this).setTitle(t("ADVANCED EQUALIZER", "ADVANCED EQUALIZER"))
            .setView(ScrollView(this).apply { addView(panel) })
            .setNeutralButton(t("Сбросить", "Reset")) { _, _ -> eqGains.fill(0f); saveCurrentTrackSettings(); buildUi() }
            .setPositiveButton(t("Готово", "Done")) { _, _ -> saveCurrentTrackSettings(); buildUi() }
            .show()
    }

    private fun showMasteringDialog() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(10), dp(18), dp(4)) }
        val compressor = CheckBox(this).apply {
            text = t("Включить компрессор", "Enable compressor")
            setTextColor(white); buttonTintList = ColorStateList.valueOf(cyan); isChecked = compressorEnabled
            setOnCheckedChangeListener { _, checked -> compressorEnabled = checked }
        }
        panel.addView(compressor)
        addSlider(panel, t("Порог", "Threshold"), -36, -3, compressorThresholdDb.roundToInt(), { compressorThresholdDb = it.toFloat() }, { "$it dB" })
        addSlider(panel, t("Соотношение", "Ratio"), 1, 8, compressorRatio.roundToInt(), { compressorRatio = it.toFloat() }, { "${it}:1" })
        val limiter = CheckBox(this).apply {
            text = t("Защита пиков (limiter)", "Peak protection (limiter)")
            setTextColor(white); buttonTintList = ColorStateList.valueOf(cyan); isChecked = limiterEnabled
            setOnCheckedChangeListener { _, checked -> limiterEnabled = checked }
        }
        panel.addView(limiter)
        AlertDialog.Builder(this).setTitle(t("AUDIO MASTERING", "AUDIO MASTERING"))
            .setView(panel)
            .setPositiveButton(t("Применить", "Apply")) { _, _ -> saveCurrentTrackSettings(); buildUi() }
            .setNegativeButton(t("Отмена", "Cancel"), null).show()
    }

    private fun showCustomPresetsDialog() {
        val prefs = getSharedPreferences("sand_custom_presets", MODE_PRIVATE)
        val options = arrayOf(
            t("＋ Сохранить текущие настройки как пресет", "＋ Save current settings as preset"),
            t("Открыть сохранённый пресет", "Load saved preset"),
            t("Удалить пресет", "Delete preset")
        )
        AlertDialog.Builder(this).setTitle(t("CUSTOM PRESETS", "CUSTOM PRESETS"))
            .setItems(options) { _, which ->
                when (which) {
                    0 -> saveCustomPreset(prefs)
                    1 -> loadCustomPreset(prefs)
                    2 -> deleteCustomPreset(prefs)
                }
            }.show()
    }

    private fun saveCustomPreset(prefs: android.content.SharedPreferences) {
        val input = EditText(this).apply { hint = t("Название пресета", "Preset name") }
        AlertDialog.Builder(this).setTitle(t("Сохранить пресет", "Save preset")).setView(input)
            .setPositiveButton(t("Сохранить", "Save")) { _, _ ->
                val name = input.text.toString().trim().take(40)
                if (name.isBlank()) return@setPositiveButton
                val data = listOf(speed, pitch, reverb, roomSize, fadeInSeconds, fadeOutSeconds, compressorThresholdDb, compressorRatio).joinToString(";") +
                    ";" + eqGains.joinToString(",") + ";" + listOf(limiterEnabled, compressorEnabled, reverseAudioEnabled).joinToString(",") +
                    ";" + selectedGenreKey + ";" + selectedStyleKey
                val updated = (prefs.getStringSet("names", emptySet()) ?: emptySet()).toMutableSet().apply { add(name) }
                prefs.edit().putString("preset_$name", data).putStringSet("names", updated).apply()
                Toast.makeText(this, t("Пресет сохранён", "Preset saved"), Toast.LENGTH_SHORT).show()
            }.setNegativeButton(t("Отмена", "Cancel"), null).show()
    }

    private fun loadCustomPreset(prefs: android.content.SharedPreferences) {
        val names = prefs.getStringSet("names", emptySet())?.toList()?.sorted().orEmpty()
        if (names.isEmpty()) {
            showMessage(t("Пока нет сохранённых пресетов.", "No saved presets yet."))
            return
        }
        AlertDialog.Builder(this).setTitle(t("ОТКРЫТЬ ПРЕСЕТ", "LOAD PRESET")).setItems(names.toTypedArray()) { _, index ->
            val parts = prefs.getString("preset_${names[index]}", null)?.split(';')
            if (parts == null || parts.size < 10) {
                showMessage(t("Файл пресета повреждён.", "Preset data is invalid."))
                return@setItems
            }
            runCatching {
                speed = parts[0].toFloat(); pitch = parts[1].toFloat(); reverb = parts[2].toFloat(); roomSize = parts[3].toFloat()
                fadeInSeconds = parts[4].toFloat(); fadeOutSeconds = parts[5].toFloat(); compressorThresholdDb = parts[6].toFloat(); compressorRatio = parts[7].toFloat()
                eqGains.fill(0f)
                parts[8].split(',').mapNotNull { it.toFloatOrNull() }.take(10).forEachIndexed { i, v -> eqGains[i] = v }
                val flags = parts[9].split(',')
                limiterEnabled = flags.getOrNull(0) == "true"
                compressorEnabled = flags.getOrNull(1) == "true"
                reverseAudioEnabled = flags.getOrNull(2) == "true"
                selectedGenreKey = parts.getOrNull(10) ?: selectedGenreKey
                selectedStyleKey = parts.getOrNull(11) ?: selectedStyleKey
                saveCurrentTrackSettings()
                buildUi()
                showMessage(t("Пресет применён.", "Preset applied."))
            }.onFailure { showMessage(t("Не удалось загрузить пресет: ${it.message}", "Could not load preset: ${it.message}")) }
        }.show()
    }

    private fun deleteCustomPreset(prefs: android.content.SharedPreferences) {
        val names = prefs.getStringSet("names", emptySet())?.toList()?.sorted().orEmpty()
        if (names.isEmpty()) {
            showMessage(t("Нет пресетов для удаления.", "No presets to delete."))
            return
        }
        AlertDialog.Builder(this).setTitle(t("УДАЛИТЬ ПРЕСЕТ", "DELETE PRESET")).setItems(names.toTypedArray()) { _, index ->
            val updated = names.toMutableSet().apply { remove(names[index]) }
            prefs.edit().remove("preset_${names[index]}").putStringSet("names", updated).apply()
            Toast.makeText(this, t("Пресет удалён", "Preset deleted"), Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun showWaveformEditorDialog() {
        val uri = selectedUri ?: return showMessage(t("Сначала выбери аудиофайл.", "Choose an audio file first."))
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(10)) }
        val info = addText(root, t("Подготавливаю waveform…", "Building waveform…"), 11, muted)
        val waveform = WaveformView(this)
        root.addView(waveform, params(-1, dp(142)).apply { topMargin = dp(10); bottomMargin = dp(8) })
        val rangeLabel = addText(root, "0:00 — …", 11, cyan, true)
        addBadge(root, t("FADE ДЛЯ ВЫДЕЛЕННОГО ФРАГМЕНТА", "FADES FOR SELECTED REGION"), violet)
        addSlider(root, t("Fade In", "Fade In"), 0, 100, (fadeInSeconds * 10).roundToInt(), { fadeInSeconds = it / 10f }, { "${it / 10f}s" })
        addSlider(root, t("Fade Out", "Fade Out"), 0, 100, (fadeOutSeconds * 10).roundToInt(), { fadeOutSeconds = it / 10f }, { "${it / 10f}s" })
        val durationMs = runCatching {
            MediaMetadataRetriever().let { retriever ->
                try { retriever.setDataSource(this, uri); retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L }
                finally { retriever.release() }
            }
        }.getOrDefault(0L).coerceAtLeast(1L)
        fun updateRange(start: Float, end: Float) {
            val a = (durationMs * start).toLong(); val b = (durationMs * end).toLong()
            rangeLabel.text = "${formatTime(a.toInt())} — ${formatTime(b.toInt())}"
        }
        waveform.onSelectionChanged = { a, b -> updateRange(a, b) }
        val dialog = AlertDialog.Builder(this).setTitle(t("WAVEFORM EDITOR", "WAVEFORM EDITOR"))
            .setView(ScrollView(this).apply { addView(root) })
            .setNegativeButton(t("Закрыть", "Close"), null)
            .setNeutralButton(t("Предпрослушать", "Preview selection"), null)
            .setPositiveButton(t("Экспорт WAV", "Export WAV"), null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val a = (durationMs * waveform.selectionStart).toLong(); val b = (durationMs * waveform.selectionEnd).toLong()
                startAudioWork(AudioRenderWorker.ACTION_PREVIEW, a, b)
                dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val a = (durationMs * waveform.selectionStart).toLong(); val b = (durationMs * waveform.selectionEnd).toLong()
                if (b - a < 500L) { showMessage(t("Выдели фрагмент длиннее 0,5 секунды.", "Select a region longer than 0.5 seconds.")); return@setOnClickListener }
                startAudioWork(AudioRenderWorker.ACTION_RENDER, a, b); dialog.dismiss()
            }
        }
        dialog.show()
        Executors.newSingleThreadExecutor().execute {
            try {
                val peaks = MediaPipeline.analyzeWaveform(applicationContext, uri, 260)
                runOnUiThread { waveform.amplitudes = peaks; info.text = t("Перетаскивай левую и правую границы, чтобы выделить фрагмент.", "Drag the left and right handles to select a region."); updateRange(0f, 1f) }
            } catch (e: Exception) {
                runOnUiThread { info.text = t("Не удалось построить waveform: ${e.message}", "Waveform analysis failed: ${e.message}") }
            }
        }
    }

    private fun showBatchFormatDialog(uris: List<Uri>) {
        AlertDialog.Builder(this)
            .setTitle(t("BATCH EXPORT FORMAT", "BATCH EXPORT FORMAT"))
            .setItems(arrayOf("MP3 · 320 kbps", "WAV · PCM")) { _, which ->
                enqueueBatchProcessing(uris, if (which == 1) AudioRenderWorker.ACTION_RENDER else AudioRenderWorker.ACTION_MP3)
            }.setNegativeButton(t("Отмена", "Cancel"), null).show()
    }

    private fun enqueueBatchProcessing(uris: List<Uri>, action: String) {
        if (uris.isEmpty()) return
        if (uris.size > 30) return showMessage(t("За один пакет можно выбрать не более 30 треков.", "Select up to 30 tracks per batch."))
        val manager = WorkManager.getInstance(applicationContext)
        val requests = uris.map { uri ->
            val title = resolveDisplayName(uri)
            val data = androidx.work.Data.Builder()
                .putString(AudioRenderWorker.KEY_ACTION, action)
                .putString(AudioRenderWorker.KEY_URI, uri.toString())
                .putString(AudioRenderWorker.KEY_SOURCE_NAME, title)
                .putFloat(AudioRenderWorker.KEY_SPEED, speed).putFloat(AudioRenderWorker.KEY_PITCH, pitch)
                .putFloat(AudioRenderWorker.KEY_REVERB, reverb).putFloat(AudioRenderWorker.KEY_ROOM, roomSize)
                .putString(AudioRenderWorker.KEY_EQ, eqGains.joinToString(","))
                .putBoolean(AudioRenderWorker.KEY_LIMITER, limiterEnabled).putBoolean(AudioRenderWorker.KEY_REVERSE, reverseAudioEnabled)
                .putFloat(AudioRenderWorker.KEY_FADE_IN, fadeInSeconds).putFloat(AudioRenderWorker.KEY_FADE_OUT, fadeOutSeconds)
                .putBoolean(AudioRenderWorker.KEY_COMPRESSOR, compressorEnabled).putFloat(AudioRenderWorker.KEY_COMPRESSOR_THRESHOLD, compressorThresholdDb)
                .putFloat(AudioRenderWorker.KEY_COMPRESSOR_RATIO, compressorRatio)
                .putBoolean(AudioRenderWorker.KEY_AUTO_SAVE, true).putBoolean(AudioRenderWorker.KEY_BATCH_MODE, true)
                .putBoolean(AudioRenderWorker.KEY_ENGLISH, english)
                .putString(AudioRenderWorker.KEY_LANGUAGE, languageCode).build()
            OneTimeWorkRequestBuilder<AudioRenderWorker>().setInputData(data).addTag("sand-audio-batch").build()
        }
        var continuation = manager.beginUniqueWork("sand-audio-batch", ExistingWorkPolicy.REPLACE, requests.first())
        requests.drop(1).forEach { continuation = continuation.then(it) }
        continuation.enqueue()
        val formatName = if (action == AudioRenderWorker.ACTION_RENDER) "WAV" else "MP3"
        showMessage(t("Пакет поставлен в очередь: ${requests.size} треков · $formatName. Результаты появятся в Music/Sand of Music Reverb.", "Batch queued: ${requests.size} tracks · $formatName. Results will appear in Music/Sand of Music Reverb."))
    }

    private fun resolveDisplayName(uri: Uri): String {
        return runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()?.substringBeforeLast('.')?.take(48) ?: "SandAudio"
    }

    private fun showStemSplitDialog() {
        val uri = selectedUri ?: return showMessage(t("Сначала выбери аудиофайл.", "Choose an audio file first."))
        AlertDialog.Builder(this).setTitle(t("STEM SPLIT · ЭКСПЕРИМЕНТАЛЬНО", "STEM SPLIT · EXPERIMENTAL"))
            .setMessage(t("Сейчас доступно офлайн-разделение стереосигнала на CENTER (центральная составляющая, где часто находится вокал) и SIDE (боковая составляющая). Это НЕ нейросетевое разделение: инструменты в центре могут попасть в CENTER, а реверберация вокала — в SIDE. Для полноценного разделения нужна отдельная локальная ML-модель.", "This offline experimental mode separates stereo CENTER and SIDE components. It is NOT neural source separation: centered instruments may remain in CENTER and vocal reverb may leak into SIDE. True vocal/instrumental stems require a dedicated local ML model."))
            .setPositiveButton(t("Создать две дорожки", "Create two tracks")) { _, _ ->
                val request = OneTimeWorkRequestBuilder<StemSplitWorker>()
                    .setInputData(androidx.work.Data.Builder().putString(StemSplitWorker.KEY_URI, uri.toString()).putString(StemSplitWorker.KEY_NAME, sourceName).build())
                    .addTag("sand-stem-split").build()
                val manager = WorkManager.getInstance(applicationContext)
                manager.enqueueUniqueWork("sand-stem-split", ExistingWorkPolicy.REPLACE, request)
                manager.getWorkInfoByIdLiveData(request.id).observe(this) { info ->
                    if (info == null || !info.state.isFinished) return@observe
                    if (info.state == WorkInfo.State.SUCCEEDED) showMessage(t("Дорожки CENTER и SIDE сохранены в Music/Sand of Music Reverb. Это экспериментальное стерео-разделение.", "CENTER and SIDE tracks saved to Music/Sand of Music Reverb. This is experimental stereo separation."))
                    else showMessage(t("Ошибка разделения: ${info.outputData.getString(StemSplitWorker.KEY_ERROR) ?: "неизвестная ошибка"}", "Stem split failed: ${info.outputData.getString(StemSplitWorker.KEY_ERROR) ?: "unknown error"}"))
                }
            }.setNegativeButton(t("Отмена", "Cancel"), null).show()
    }

    private fun showCombinationActions() {
        val options = arrayOf(
            t("▶ Прослушать обработанный вариант", "▶ Preview processed version"),
            t("↓ Экспортировать WAV", "↓ Export WAV"),
            t("♫ Экспортировать MP3", "♫ Export MP3"),
            t("⚙ Продолжить ручную настройку", "⚙ Continue fine-tuning")
        )
        AlertDialog.Builder(this)
            .setTitle(t("КОМБИНАЦИЯ ПРИМЕНЕНА", "COMBINATION READY"))
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> render(exportFormat = null)
                    1 -> render(exportFormat = MediaPipeline.OutputFormat.WAV)
                    2 -> render(exportFormat = MediaPipeline.OutputFormat.MP3)
                    else -> dialog.dismiss()
                }
            }
            .setNegativeButton(t("Закрыть", "Close"), null)
            .show()
    }

    private fun applyGenreStylePreset(genreKey: String, styleKey: String) {
        val profile = GenreStyleProfiles.combine(genreKey, styleKey)
        speed = profile.speed
        pitch = profile.pitchSemitones
        reverb = profile.reverbWet
        roomSize = profile.roomSize
        eqGains.fill(0f)
        profile.eqGainsDb.copyInto(eqGains, endIndex = minOf(profile.eqGainsDb.size, eqGains.size))
        getSharedPreferences("sand_settings", MODE_PRIVATE).edit()
            .putString("preset_genre", genreKey)
            .putString("preset_style", styleKey)
            .apply()
        buildUi()
        if (busy) updateWorkUi() else statusText.text = t(
            "Применён профиль: ${profile.displayName}. Регуляторы можно менять вручную.",
            "Applied profile: ${profile.displayName}. You can fine-tune every control.")
    }

    private fun applyPreset(name: String) {
        // Legacy one-tap moods remain available for compatibility with existing UI actions.
        when (name) {
            "slowed" -> { speed = 0.78f; pitch = -2f; reverb = 0.24f; roomSize = 0.56f; eqGains.fill(0f) }
            "nightcore" -> { applyGenreStylePreset(selectedGenreKey, "nightcore"); return }
            "dreamy" -> { applyGenreStylePreset(selectedGenreKey, "dreamy_reverb"); return }
            "dark" -> { applyGenreStylePreset(selectedGenreKey, "dark_reverb"); return }
            "hyper" -> { speed = 1.38f; pitch = 5f; reverb = 0.03f; roomSize = 0.24f; eqGains.fill(0f); eqGains[3] = 2f; eqGains[4] = 2f }
            "daycore" -> { applyGenreStylePreset(selectedGenreKey, "daycore"); return }
            "vaporwave" -> { applyGenreStylePreset(selectedGenreKey, "vaporwave"); return }
            "ambient" -> { applyGenreStylePreset(selectedGenreKey, "ambient"); return }
            else -> { applyGenreStylePreset(name, selectedStyleKey); return }
        }
        buildUi()
        if (busy) updateWorkUi() else statusText.text = t("Пресет применён. Можно точно настроить регуляторы.", "Preset applied. Fine-tune the controls as needed.")
    }

    private data class LibraryTrack(
        val uri: Uri,
        val title: String,
        val artist: String,
        val album: String,
        val duration: Long,
        val albumId: Long,
        val folder: String = "",
        val genre: String = ""
    )

    private fun audioPermission(): String = if (Build.VERSION.SDK_INT >= 33) "android.permission.READ_MEDIA_AUDIO" else "android.permission.READ_EXTERNAL_STORAGE"

    private fun openMusicLibrary() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(audioPermission()) != PackageManager.PERMISSION_GRANTED) {
            audioPermissionLauncher.launch(audioPermission())
            return
        }
        showMusicLibrary()
    }


    private fun loadLibraryTracks(): List<LibraryTrack> {
        val tracks = mutableListOf<LibraryTrack>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: t("Без названия", "Untitled")
                val artist = cursor.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: t("Неизвестный исполнитель", "Unknown artist")
                val album = cursor.getString(albumCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: ""
                @Suppress("DEPRECATION")
                val path = if (dataCol >= 0) cursor.getString(dataCol).orEmpty() else ""
                val folder = path.takeIf { it.isNotBlank() }?.let { File(it).parentFile?.name }.orEmpty()
                tracks.add(
                    LibraryTrack(
                        uri = Uri.withAppendedPath(collection, id.toString()),
                        title = title,
                        artist = artist,
                        album = album,
                        duration = cursor.getLong(durationCol),
                        albumId = cursor.getLong(albumIdCol),
                        folder = folder
                    )
                )
            }
        }
        val genreByAudioId = mutableMapOf<Long, String>()
        try {
            contentResolver.query(MediaStore.Audio.Genres.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Audio.Genres._ID, MediaStore.Audio.Genres.NAME), null, null, null)?.use { genresCursor ->
                val genreIdCol = genresCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres._ID)
                val genreNameCol = genresCursor.getColumnIndexOrThrow(MediaStore.Audio.Genres.NAME)
                while (genresCursor.moveToNext()) {
                    val genreId = genresCursor.getLong(genreIdCol)
                    val genreName = genresCursor.getString(genreNameCol).orEmpty()
                    val membersUri = MediaStore.Audio.Genres.Members.getContentUri("external", genreId)
                    contentResolver.query(membersUri, arrayOf(MediaStore.Audio.Genres.Members.AUDIO_ID), null, null, null)?.use { members ->
                        val audioIdCol = members.getColumnIndexOrThrow(MediaStore.Audio.Genres.Members.AUDIO_ID)
                        while (members.moveToNext()) genreByAudioId[members.getLong(audioIdCol)] = genreName
                    }
                }
            }
        } catch (_: Exception) { }
        return tracks.map { track ->
            val audioId = track.uri.lastPathSegment?.toLongOrNull()
            track.copy(genre = audioId?.let { genreByAudioId[it] }.orEmpty())
        }
    }

    private inner class LibraryTrackAdapter(private var rows: List<LibraryTrack>) : BaseAdapter() {
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): LibraryTrack = rows[position]
        override fun getItemId(position: Int): Long = rows[position].uri.lastPathSegment?.toLongOrNull() ?: position.toLong()

        fun replace(newRows: List<LibraryTrack>) {
            rows = newRows
            notifyDataSetChanged()
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val track = getItem(position)
            val row: LinearLayout
            val artwork: ImageView
            val title: TextView
            val subtitle: TextView
            val duration: TextView
            if (convertView == null) {
                row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(9), dp(8), dp(10), dp(8))
                    background = roundedGradient(cardAlt, cardColor, dp(14), Color.rgb(39, 74, 94))
                }
                val coverFrame = FrameLayout(this@MainActivity).apply {
                    background = rounded(Color.rgb(25, 54, 72), dp(10), Color.rgb(47, 98, 117))
                }
                artwork = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                coverFrame.addView(artwork, FrameLayout.LayoutParams(-1, -1))
                val glyph = TextView(this@MainActivity).apply {
                    text = "♫"
                    textSize = 22f
                    gravity = Gravity.CENTER
                    setTextColor(cyan)
                    tag = "placeholder"
                }
                coverFrame.addView(glyph, FrameLayout.LayoutParams(-1, -1))
                row.addView(coverFrame, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginEnd = dp(11) })

                val textBlock = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                title = TextView(this@MainActivity).apply {
                    textSize = 13f
                    setTextColor(white)
                    typeface = Typeface.create("sans-serif", Typeface.BOLD)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                subtitle = TextView(this@MainActivity).apply {
                    textSize = 10f
                    setTextColor(muted)
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                textBlock.addView(title)
                textBlock.addView(subtitle)
                row.addView(textBlock, LinearLayout.LayoutParams(0, -2, 1f))
                duration = TextView(this@MainActivity).apply {
                    textSize = 10f
                    setTextColor(cyan)
                    gravity = Gravity.CENTER
                    setPadding(dp(5), 0, 0, 0)
                }
                row.addView(duration, params(dp(48), -2))
                row.tag = TrackHolder(artwork, title, subtitle, duration, glyph)
            } else {
                row = convertView as LinearLayout
                val holder = row.tag as TrackHolder
                artwork = holder.artwork
                title = holder.title
                subtitle = holder.subtitle
                duration = holder.duration
            }
            val holder = row.tag as TrackHolder
            title.text = track.title
            subtitle.text = listOf(track.artist, track.album).filter { it.isNotBlank() }.distinct().joinToString(" · ")
            duration.text = formatTime(track.duration.toInt())
            artwork.tag = track.albumId
            holder.glyph.visibility = View.VISIBLE
            artwork.setImageDrawable(null)
            val cached = albumArtCache.get(track.albumId)
            if (cached != null) {
                artwork.setImageBitmap(cached)
                holder.glyph.visibility = View.GONE
            } else if (track.albumId > 0L) {
                loadAlbumArt(track.albumId, artwork, holder.glyph)
            }
            return row
        }
    }

    private data class TrackHolder(
        val artwork: ImageView,
        val title: TextView,
        val subtitle: TextView,
        val duration: TextView,
        val glyph: TextView
    )

    private fun loadAlbumArt(albumId: Long, target: ImageView, placeholder: TextView) {
        albumArtExecutor.execute {
            try {
                val artUri = Uri.parse("content://media/external/audio/albumart/$albumId")
                val bitmap = contentResolver.openInputStream(artUri)?.use { input ->
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    input.mark(1024)
                    BitmapFactory.decodeStream(input, null, bounds)
                    val scale = if (bounds.outWidth > 256 || bounds.outHeight > 256) 4 else 1
                    val options = BitmapFactory.Options().apply { inSampleSize = scale.coerceAtLeast(1) }
                    contentResolver.openInputStream(artUri)?.use { BitmapFactory.decodeStream(it, null, options) }
                }
                if (bitmap != null) {
                    albumArtCache.put(albumId, bitmap)
                    handler.post {
                        if (target.tag == albumId) {
                            target.setImageBitmap(bitmap)
                            placeholder.visibility = View.GONE
                        }
                    }
                }
            } catch (_: Exception) { }
        }
    }

    private fun showMusicLibrary() {
        val loading = AlertDialog.Builder(this)
            .setTitle(t("МЕДИАТЕКА", "MUSIC LIBRARY"))
            .setMessage(t("Сканирую музыкальную коллекцию…", "Scanning your music collection…"))
            .setNegativeButton(t("Отмена", "Cancel"), null)
            .create()
        loading.show()
        Thread({
            val result = runCatching { loadLibraryTracks() }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                loading.dismiss()
                result.onSuccess { tracks ->
                    if (tracks.isEmpty()) showMessage(t("В медиатеке пока не найдено музыкальных файлов.", "No music files were found in the media library."))
                    else showMusicLibraryDialog(tracks)
                }.onFailure { error ->
                    showMessage(t("Не удалось открыть медиатеку: ${error.message}", "Could not open music library: ${error.message}"))
                }
            }
        }, "SandLibraryScan").start()
    }

    private fun showMusicLibraryDialog(allTracks: List<LibraryTrack>) {
        try {
            val dialogView = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(10), dp(14), dp(8))
                setBackgroundColor(backgroundColor)
            }
            val heading = TextView(this).apply {
                text = t("ТВОЯ МУЗЫКАЛЬНАЯ КОЛЛЕКЦИЯ", "YOUR MUSIC COLLECTION")
                textSize = 10f
                letterSpacing = 0.08f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(cyan)
                setPadding(0, 0, 0, dp(7))
            }
            var onNavigateBack: (() -> Unit)? = null
            val headingRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            headingRow.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
            val navBackButton = actionButton(t("← Назад", "← Back"), false) { onNavigateBack?.invoke() }
            navBackButton.visibility = View.GONE
            headingRow.addView(navBackButton, params(dp(96), dp(34)))
            dialogView.addView(headingRow)

            data class LibraryNavigationState(
                val section: String,
                val scopedRows: List<LibraryTrack>?,
                val firstVisiblePosition: Int,
                val firstChildTop: Int,
                val query: String
            )
            val navigationStack = mutableListOf<LibraryNavigationState>()
            var section = "tracks"
            var scopedRows: List<LibraryTrack>? = null
            var sortByArtist = false
            var displayedRows: List<LibraryTrack> = allTracks
            val tabs = listOf(
                "tracks" to t("ТРЕКИ", "TRACKS"),
                "albums" to t("АЛЬБОМЫ", "ALBUMS"),
                "artists" to t("ИСПОЛНИТЕЛИ", "ARTISTS"),
                "folders" to t("ПАПКИ", "FOLDERS"),
                "genres" to t("ЖАНРЫ", "GENRES"),
                "playlists" to t("ПЛЕЙЛИСТЫ", "PLAYLISTS"),
                "favorites" to t("ИЗБРАННОЕ", "FAVORITES")
            )
            val tabScroller = android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
            }
            val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            tabScroller.addView(tabRow)
            dialogView.addView(tabScroller, params().apply { bottomMargin = dp(8) })

            val search = EditText(this).apply {
                hint = t("Найди трек, исполнителя или альбом…", "Search track, artist or album…")
                setSingleLine(true)
                inputType = android.text.InputType.TYPE_CLASS_TEXT
                setTextColor(white)
                setHintTextColor(muted)
                textSize = 13f
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = rounded(cardAlt, dp(12), Color.rgb(44, 83, 104))
            }
            dialogView.addView(search, params().apply { bottomMargin = dp(7) })

            val toolbar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val countLabel = TextView(this).apply { textSize = 10f; setTextColor(muted) }
            toolbar.addView(countLabel, LinearLayout.LayoutParams(0, -2, 1f))
            val sortButton = actionButton(t("А–Я  Название", "A–Z  Title"), false) { }
            toolbar.addView(sortButton, params(dp(130), dp(36)))
            dialogView.addView(toolbar)

            val list = ListView(this).apply {
                divider = null
                dividerHeight = dp(6)
                cacheColorHint = Color.TRANSPARENT
                setSelector(android.R.color.transparent)
                setPadding(0, dp(8), 0, dp(4))
                clipToPadding = false
            }
            dialogView.addView(list, LinearLayout.LayoutParams(-1, dp(430)))
            val adapter = LibraryTrackAdapter(emptyList())
            list.adapter = adapter

            fun idOf(track: LibraryTrack): String = track.uri.lastPathSegment ?: track.uri.toString()
            fun savedIds(key: String): MutableSet<String> = getSharedPreferences("sand_library", MODE_PRIVATE)
                .getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
            lateinit var applyFilter: () -> Unit

            fun updateTabs() {
                tabRow.removeAllViews()
                tabs.forEach { (key, label) ->
                    tabRow.addView(actionButton(label, section == key && scopedRows == null) {
                        navigationStack.clear()
                        section = key
                        scopedRows = null
                        search.setText("")
                        updateTabs()
                        applyFilter()
                        navBackButton.visibility = View.GONE
                    }, LinearLayout.LayoutParams(-2, dp(36)).apply { marginEnd = dp(5) })
                }
            }

            fun rowsForSection(): List<LibraryTrack> {
                if (scopedRows != null) return scopedRows.orEmpty()
                return when (section) {
                    "albums" -> allTracks.groupBy { it.album.ifBlank { t("Без альбома", "Unknown album") } }
                        .toSortedMap(String.CASE_INSENSITIVE_ORDER)
                        .map { (name, members) -> members.first().copy(title = name, artist = "${members.size} ${t("треков", "tracks")}", album = name, duration = members.sumOf { it.duration }) }
                    "artists" -> allTracks.groupBy { it.artist.ifBlank { t("Неизвестный исполнитель", "Unknown artist") } }
                        .toSortedMap(String.CASE_INSENSITIVE_ORDER)
                        .map { (name, members) -> members.first().copy(title = name, artist = "${members.size} ${t("треков", "tracks")}", album = "", duration = members.sumOf { it.duration }) }
                    "folders" -> allTracks.groupBy { it.folder.ifBlank { t("Неизвестная папка", "Unknown folder") } }
                        .toSortedMap(String.CASE_INSENSITIVE_ORDER)
                        .map { (name, members) -> members.first().copy(title = name, artist = "${members.size} ${t("треков", "tracks")}", album = "", folder = name, duration = members.sumOf { it.duration }) }
                    "genres" -> allTracks.groupBy { it.genre.ifBlank { t("Неизвестный жанр", "Unknown genre") } }
                        .toSortedMap(String.CASE_INSENSITIVE_ORDER)
                        .map { (name, members) -> members.first().copy(title = name, artist = "${members.size} ${t("треков", "tracks")}", album = "", genre = name, duration = members.sumOf { it.duration }) }
                    "favorites" -> {
                        val ids = savedIds("favorite_ids")
                        allTracks.filter { idOf(it) in ids }
                    }
                    "playlists" -> {
                        val ids = savedIds("playlist_ids")
                        allTracks.filter { idOf(it) in ids }
                    }
                    else -> allTracks
                }
            }

            applyFilter = {
                val query = search.text?.toString()?.trim()?.lowercase(Locale.ROOT).orEmpty()
                var filtered = rowsForSection().filter {
                    it.title.lowercase(Locale.ROOT).contains(query) ||
                        it.artist.lowercase(Locale.ROOT).contains(query) ||
                        it.album.lowercase(Locale.ROOT).contains(query) ||
                        it.folder.lowercase(Locale.ROOT).contains(query)
                }
                filtered = if (sortByArtist) {
                    filtered.sortedWith(compareBy<LibraryTrack> { it.artist.lowercase(Locale.ROOT) }.thenBy { it.title.lowercase(Locale.ROOT) })
                } else filtered.sortedBy { it.title.lowercase(Locale.ROOT) }
                displayedRows = filtered
                adapter.replace(filtered)
                countLabel.text = when (section) {
                    "albums" -> t("${filtered.size} альбомов", "${filtered.size} albums")
                    "artists" -> t("${filtered.size} исполнителей", "${filtered.size} artists")
                    "folders" -> t("${filtered.size} папок", "${filtered.size} folders")
                    "favorites" -> t("${filtered.size} избранных треков", "${filtered.size} favorite tracks")
                    "playlists" -> t("${filtered.size} треков в плейлисте", "${filtered.size} playlist tracks")
                    else -> t("${filtered.size} треков", "${filtered.size} tracks")
                }
                sortButton.text = if (sortByArtist) t("А–Я  Исполнитель", "A–Z  Artist") else t("А–Я  Название", "A–Z  Title")
            }

            onNavigateBack = {
                if (navigationStack.isNotEmpty()) {
                    val previous = navigationStack.removeAt(navigationStack.lastIndex)
                    section = previous.section
                    scopedRows = previous.scopedRows
                    updateTabs()
                    search.setText(previous.query)
                    applyFilter()
                    navBackButton.visibility = if (navigationStack.isEmpty()) View.GONE else View.VISIBLE
                    list.post { list.setSelectionFromTop(previous.firstVisiblePosition, previous.firstChildTop) }
                }
            }
            updateTabs()
            sortButton.setOnClickListener { sortByArtist = !sortByArtist; applyFilter() }
            search.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { applyFilter() }
                override fun afterTextChanged(s: Editable?) {}
            })
            applyFilter()

            val dialog = AlertDialog.Builder(this)
                .setTitle(t("МЕДИАТЕКА", "MUSIC LIBRARY"))
                .setView(dialogView)
                .setNegativeButton(t("Закрыть", "Close"), null)
                .create()
            dialog.setOnKeyListener { _, keyCode, event ->
                if (keyCode == android.view.KeyEvent.KEYCODE_BACK && event.action == android.view.KeyEvent.ACTION_UP && navigationStack.isNotEmpty()) {
                    onNavigateBack?.invoke()
                    true
                } else false
            }
            dialog.setOnShowListener {
                dialog.window?.setBackgroundDrawable(rounded(backgroundColor, dp(20), Color.rgb(50, 94, 116)))
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(cyan)
            }
            list.setOnItemClickListener { _, _, position, _ ->
                val track = displayedRows.getOrNull(position) ?: return@setOnItemClickListener
                if (scopedRows == null && section in listOf("albums", "artists", "folders", "genres")) {
                    navigationStack.add(
                        LibraryNavigationState(
                            section,
                            scopedRows,
                            list.firstVisiblePosition,
                            list.getChildAt(0)?.top ?: 0,
                            search.text?.toString().orEmpty()
                        )
                    )
                    scopedRows = when (section) {
                        "albums" -> allTracks.filter { it.album.ifBlank { t("Без альбома", "Unknown album") } == track.title }
                        "artists" -> allTracks.filter { it.artist == track.title }
                        "genres" -> allTracks.filter { it.genre.ifBlank { t("Неизвестный жанр", "Unknown genre") } == track.title }
                        else -> allTracks.filter { it.folder.ifBlank { t("Неизвестная папка", "Unknown folder") } == track.title }
                    }
                    section = "tracks"
                    updateTabs()
                    applyFilter()
                    navBackButton.visibility = View.VISIBLE
                    return@setOnItemClickListener
                }
                saveCurrentTrackSettings()
                selectedUri = track.uri
                if (!loadTrackSettings(track.uri)) applyGenreStylePreset(selectedGenreKey, selectedStyleKey)
                sourceName = track.title
                sourceDetails = listOf(track.artist, track.album.ifBlank { null }, formatTime(track.duration.toInt()))
                    .filterNotNull().joinToString(" · ")
                trackTitle.text = sourceName
                trackDetails.text = sourceDetails
                transportTitle.text = sourceName
                val queue = displayedRows.toList()
                playLibraryQueue(queue, position)
                if (busy) updateWorkUi() else statusText.text = t("Воспроизведение из медиатеки.", "Playing from your library.")
                dialog.dismiss()
            }
            list.setOnItemLongClickListener { _, _, position, _ ->
                if (section in listOf("albums", "artists", "folders", "genres")) return@setOnItemLongClickListener true
                val track = displayedRows.getOrNull(position) ?: return@setOnItemLongClickListener true
                AlertDialog.Builder(this)
                    .setTitle(track.title)
                    .setItems(arrayOf(t("Добавить / убрать из избранного", "Toggle favorite"), t("Добавить / убрать в плейлисте", "Toggle My Playlist"))) { _, which ->
                        val key = if (which == 0) "favorite_ids" else "playlist_ids"
                        val ids = savedIds(key)
                        val id = idOf(track)
                        if (!ids.add(id)) ids.remove(id)
                        getSharedPreferences("sand_library", MODE_PRIVATE).edit().putStringSet(key, ids).apply()
                        applyFilter()
                        showMessage(if (which == 0) t("Избранное обновлено.", "Favorites updated.") else t("Мой плейлист обновлён.", "My Playlist updated."))
                    }
                    .show()
                true
            }
            dialog.show()
        } catch (error: Exception) {
            showMessage(t("Не удалось открыть медиатеку: ${error.message}", "Could not open music library: ${error.message}"))
        }
    }

    private fun pickAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            // Accept audio-only files and video containers that may contain an audio track.
            // FFmpeg probes the actual container/codec, so the filename extension is not trusted.
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*", "application/octet-stream"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_PICK_AUDIO)
    }

    @Deprecated("Legacy activity result is used to keep this project dependency-light.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) {
            if (requestCode == REQUEST_CREATE_EXPORT && pendingExport?.exists() == true) {
                val savedFile = pendingExport!!
                statusText.text = t("Результат сохранён внутри приложения. Его можно выгрузить позже.", "The render is kept inside the app. You can export it later.")
                AlertDialog.Builder(this)
                    .setTitle(t("Файл пока не сохранён", "File not exported yet"))
                    .setMessage(t("Готовый файл не удалён. Повторить выбор места сохранения?", "The completed render was not deleted. Choose a save location now?"))
                    .setPositiveButton(t("Повторить", "Retry")) { _, _ ->
                        launchExportSaveDialog(savedFile, activeWorkSourceName, activeWorkAction)
                    }
                    .setNegativeButton(t("Позже", "Later"), null)
                    .show()
            }
            return
        }
        val uri = data.data!!
        when (requestCode) {
            REQUEST_PICK_AUDIO -> {
                selectedUri = uri
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                val fallbackName = uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
                    ?: t("Читаю медиафайл…", "Reading media file…")
                sourceName = fallbackName
                sourceDetails = t("Читаю сведения о файле…", "Reading file information…")
                trackTitle.text = sourceName
                trackDetails.text = sourceDetails
                transportTitle.text = sourceName
                if (busy) updateWorkUi() else statusText.text = t("Файл выбран. Читаю метаданные…", "File selected. Reading metadata…")
                Thread({
                    val meta = readAudioInfo(uri)
                    runOnUiThread {
                        if (isFinishing || isDestroyed || selectedUri != uri) return@runOnUiThread
                        sourceName = meta.first
                        sourceDetails = meta.second
                        trackTitle.text = sourceName
                        trackDetails.text = sourceDetails
                        transportTitle.text = sourceName
                        if (!busy) statusText.text = t("Файл выбран. Можно включить оригинал или создать ремикс.", "Track loaded. Play the original or render a remix.")
                    }
                }, "SandReadMetadata").start()
            }
            REQUEST_CREATE_EXPORT -> {
                val source = pendingExport
                if (source != null) saveExportInBackground(source, uri)
            }
        }
    }

    private fun saveExportInBackground(source: File, destination: Uri) {
        statusText.text = t("Сохраняю файл…", "Saving file…")
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = true
        Thread({
            var saveError: String? = null
            try {
                val output = applicationContext.contentResolver.openOutputStream(destination, "w")
                    ?: throw IllegalStateException("Не удалось открыть выбранное место сохранения.")
                output.buffered().use { target ->
                    source.inputStream().buffered().use { input ->
                        val buffer = ByteArray(1024 * 1024)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            target.write(buffer, 0, count)
                        }
                        target.flush()
                    }
                }
            } catch (error: Exception) {
                saveError = error.message ?: error.javaClass.simpleName
            }

            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                progressBar.isIndeterminate = false
                progressBar.visibility = View.GONE
                if (saveError == null) {
                    if (previewCacheFile != source) source.delete()
                    pendingExport = null
                    getSharedPreferences("sand_settings", MODE_PRIVATE).edit()
                        .remove("pending_export_path")
                        .remove("pending_export_action")
                        .remove("pending_export_name")
                        .apply()
                    val formatLabel = if (source.extension.equals("mp3", true)) "MP3" else "WAV"
                    statusText.text = t("Экспорт завершён — $formatLabel сохранён.", "Export complete — $formatLabel saved.")
                } else {
                    pendingExport = source
                    statusText.text = t("Не удалось сохранить файл: $saveError. Результат оставлен в приложении.", "Could not save file: $saveError. The render is kept in the app.")
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(t("Сохранение не завершено", "Save did not finish"))
                        .setMessage(t("Готовый файл не удалён. Выбери другое место и повтори сохранение.", "The completed render was not deleted. Choose another destination and retry."))
                        .setPositiveButton(t("Повторить", "Retry")) { _, _ ->
                            launchExportSaveDialog(source, activeWorkSourceName, activeWorkAction)
                        }
                        .setNegativeButton(t("Позже", "Later"), null)
                        .show()
                }
            }
        }, "SandExportSave").start()
    }

    private fun readAudioInfo(uri: Uri): Pair<String, String> {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: t("Медиафайл", "Media file")
        var size: Long? = null
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            if (cursor?.moveToFirst() == true) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        } catch (_: Exception) { } finally { cursor?.close() }
        var durationText = ""
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            if (durationMs != null) durationText = " · ${formatTime(durationMs.toInt())}"
        } catch (_: Exception) { } finally { try { retriever.release() } catch (_: Exception) { } }
        val sizeText = size?.let { " · ${String.format(Locale.US, "%.1f MB", it / (1024f * 1024f))}" } ?: ""
        return name to (t("Медиафайл", "Media file") + durationText + sizeText)
    }

    private fun previewOriginal() {
        startAudioWork(AudioRenderWorker.ACTION_ORIGINAL)
    }

    private fun togglePlayback() {
        val controller = mediaController
        if (controller != null && controller.mediaItemCount > 0) {
            if (controller.isPlaying) {
                controller.pause()
                statusText.text = t("Пауза.", "Paused.")
            } else {
                controller.play()
                statusText.text = t("Воспроизведение продолжается.", "Playback resumed.")
                handler.removeCallbacks(progressTicker)
                handler.post(progressTicker)
            }
            updateTransportUi()
            return
        }
        val current = player
        if (current == null || !playerPrepared) {
            showMessage(t("Сначала запусти оригинал или создай предпрослушивание.", "Start the original or render a preview first."))
            return
        }
        try {
            if (current.isPlaying) {
                current.pause()
                abandonLocalAudioFocus()
                statusText.text = t("Пауза.", "Paused.")
            } else {
                if (!requestLocalAudioFocus()) return
                current.start()
                statusText.text = t("Воспроизведение продолжается.", "Playback resumed.")
                handler.removeCallbacks(progressTicker)
                handler.post(progressTicker)
            }
            updateTransportUi()
        } catch (error: Exception) {
            showMessage(t("Не удалось изменить воспроизведение: ${error.message}", "Playback control failed: ${error.message}"))
        }
    }

    private fun stopPlayback() {
        handler.removeCallbacks(progressTicker)
        try { mediaController?.pause(); mediaController?.clearMediaItems() } catch (_: Exception) { }
        stopLocalPreviewOnly()
        isSeeking = false
        if (::transportSeek.isInitialized) transportSeek.progress = 0
        if (::transportTime.isInitialized) transportTime.text = "0:00 / 0:00"
        updateTransportUi()
    }

    private fun finishPlayback(message: String) {
        handler.removeCallbacks(progressTicker)
        abandonLocalAudioFocus()
        try { player?.release() } catch (_: Exception) { }
        player = null
        playerPrepared = false
        previewCacheFile?.let { file -> if (file != pendingExport) file.delete() }
        previewCacheFile = null
        if (::transportSeek.isInitialized) transportSeek.progress = 0
        if (::transportTime.isInitialized) transportTime.text = "0:00 / 0:00"
        if (::statusText.isInitialized) statusText.text = message
        updateTransportUi()
    }

    private fun updateTransportUi() {
        if (!::playPauseButton.isInitialized) return
        val controller = mediaController
        val serviceActive = controller != null && controller.mediaItemCount > 0
        val localActive = player != null && playerPrepared
        val active = serviceActive || localActive
        val playing = if (serviceActive) controller?.isPlaying == true else try { player?.isPlaying == true } catch (_: Exception) { false }
        playPauseButton.text = if (playing) "Ⅱ" else "▶"
        playPauseButton.isEnabled = active
        playPauseButton.alpha = if (active) 1f else 0.55f
        if (!active && ::transportTitle.isInitialized && transportTitle.text.isNullOrBlank()) {
            transportTitle.text = t("Плеер готов к запуску", "Player ready")
        }
        updateExpandedPlayerUi()
    }

    private fun formatTime(milliseconds: Int): String {
        val seconds = (milliseconds.coerceAtLeast(0) / 1000)
        return "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
    }

    private fun render(exportFormat: MediaPipeline.OutputFormat?) {
        val action = when (exportFormat) {
            MediaPipeline.OutputFormat.WAV -> AudioRenderWorker.ACTION_RENDER
            MediaPipeline.OutputFormat.MP3 -> AudioRenderWorker.ACTION_MP3
            null -> AudioRenderWorker.ACTION_PREVIEW
        }
        saveCurrentTrackSettings()
        startAudioWork(action)
    }

    private fun startAudioWork(action: String, trimStartMs: Long = 0L, trimEndMs: Long = -1L) {
        val uri = selectedUri ?: return showMessage(t("Сначала выбери аудиофайл.", "Choose a media file first."))
        if (busy) return
        saveCurrentTrackSettings()
        stopPlayback()

        activeWorkAction = action
        activeWorkSourceName = sourceName.ifBlank { "SandOfMusic" }
        activeWorkProgress = 0
        activeWorkStage = t("Подготовка задачи…", "Preparing task…")
        workCompletionHandled = false

        val dataBuilder = androidx.work.Data.Builder()
            .putString(AudioRenderWorker.KEY_ACTION, action)
            .putString(AudioRenderWorker.KEY_URI, uri.toString())
            .putString(AudioRenderWorker.KEY_SOURCE_NAME, activeWorkSourceName)
            .putFloat(AudioRenderWorker.KEY_SPEED, speed)
            .putFloat(AudioRenderWorker.KEY_PITCH, pitch)
            .putFloat(AudioRenderWorker.KEY_REVERB, reverb)
            .putFloat(AudioRenderWorker.KEY_ROOM, roomSize)
            .putString(AudioRenderWorker.KEY_EQ, eqGains.joinToString(",") { it.toString() })
            .putBoolean(AudioRenderWorker.KEY_LIMITER, limiterEnabled)
            .putBoolean(AudioRenderWorker.KEY_REVERSE, reverseAudioEnabled)
            .putFloat(AudioRenderWorker.KEY_FADE_IN, fadeInSeconds)
            .putFloat(AudioRenderWorker.KEY_FADE_OUT, fadeOutSeconds)
            .putBoolean(AudioRenderWorker.KEY_COMPRESSOR, compressorEnabled)
            .putFloat(AudioRenderWorker.KEY_COMPRESSOR_THRESHOLD, compressorThresholdDb)
            .putFloat(AudioRenderWorker.KEY_COMPRESSOR_RATIO, compressorRatio)
            .putLong(AudioRenderWorker.KEY_TRIM_START_MS, trimStartMs)
            .putLong(AudioRenderWorker.KEY_TRIM_END_MS, trimEndMs)
            .putBoolean(AudioRenderWorker.KEY_ENGLISH, english)
            .putString(AudioRenderWorker.KEY_LANGUAGE, languageCode)

        val request = OneTimeWorkRequestBuilder<AudioRenderWorker>()
            .setInputData(dataBuilder.build())
            .addTag("sand-audio-render")
            .build()

        activeWorkId = request.id
        getSharedPreferences("sand_settings", MODE_PRIVATE).edit()
            .putString("active_work_id", request.id.toString())
            .putString("active_work_action", action)
            .putString("active_work_source", activeWorkSourceName)
            .apply()

        updateBusyState(true)
        updateWorkUi()
        WorkManager.getInstance(applicationContext).enqueueUniqueWork(
            UNIQUE_WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            request
        )
        observeWork(request.id)
    }

    private fun observeWork(id: UUID) {
        val manager = WorkManager.getInstance(applicationContext)
        activeWorkObserver?.let { observer -> activeWorkLiveData?.removeObserver(observer) }
        val liveData = manager.getWorkInfoByIdLiveData(id)
        val observer = Observer<WorkInfo?> { info ->
            if (info != null && activeWorkId == info.id) onWorkInfoChanged(info)
        }
        activeWorkLiveData = liveData
        activeWorkObserver = observer
        liveData.observe(this, observer)
    }

    private fun onWorkInfoChanged(info: WorkInfo) {
        activeWorkProgress = info.progress.getInt(AudioRenderWorker.KEY_PROGRESS, activeWorkProgress)
        activeWorkStage = info.progress.getString(AudioRenderWorker.KEY_STAGE)
            ?: when (info.state) {
                WorkInfo.State.ENQUEUED -> t("Задача в очереди…", "Task queued…")
                WorkInfo.State.BLOCKED -> t("Ожидание…", "Waiting…")
                WorkInfo.State.RUNNING -> t("Обработка аудио…", "Processing audio…")
                else -> activeWorkStage
            }
        if (!info.state.isFinished) {
            updateBusyState(true)
            updateWorkUi()
        } else {
            handleFinishedWork(info)
        }
    }

    private fun updateWorkUi() {
        if (!::statusText.isInitialized || !::progressBar.isInitialized) return
        progressBar.isIndeterminate = false
        progressBar.progress = activeWorkProgress.coerceIn(0, 100)
        progressBar.visibility = View.VISIBLE
        statusText.text = "${localizedWorkStage(activeWorkStage.ifBlank { t("Обработка аудио…", "Processing audio…") })}  ${activeWorkProgress.coerceIn(0, 100)}%"
        if (::cancelWorkButton.isInitialized) cancelWorkButton.visibility = View.VISIBLE
    }

    private fun localizedWorkStage(value: String): String {
        if (languageCode == "ru") return value
        val pairs = listOf(
            "Копирование исходного файла" to "Copying source file",
            "Файл подготовлен" to "Source file ready",
            "Обработка аудио" to "Processing audio",
            "Финальная проверка файла" to "Final file check",
            "Подготовка файла" to "Preparing file…",
            "Подготовка задачи" to "Preparing task…",
            "Готово" to "Complete"
        )
        val pair = pairs.firstOrNull { value.startsWith(it.first) } ?: return value
        return LanguageCatalog.translate(languageCode, pair.first, pair.second) + value.removePrefix(pair.first)
    }

    private fun handleFinishedWork(info: WorkInfo) {
        if (workCompletionHandled) return
        workCompletionHandled = true
        val action = info.outputData.getString(AudioRenderWorker.KEY_ACTION) ?: activeWorkAction
        val name = info.outputData.getString(AudioRenderWorker.KEY_SOURCE_NAME) ?: activeWorkSourceName
        val outputPath = info.outputData.getString(AudioRenderWorker.KEY_OUTPUT_FILE)
        val error = info.outputData.getString(AudioRenderWorker.KEY_ERROR)
        val outputFile = outputPath?.let(::File)

        activeWorkObserver?.let { activeWorkLiveData?.removeObserver(it) }
        activeWorkLiveData = null
        activeWorkObserver = null
        activeWorkId = null
        getSharedPreferences("sand_settings", MODE_PRIVATE).edit()
            .remove("active_work_id")
            .remove("active_work_action")
            .remove("active_work_source")
            .apply()
        updateBusyState(false)
        progressBar.progress = if (info.state == WorkInfo.State.SUCCEEDED) 100 else 0

        when (info.state) {
            WorkInfo.State.SUCCEEDED -> {
                if (outputFile == null || !outputFile.exists() || outputFile.length() == 0L) {
                    statusText.text = t("Задача завершилась, но файл результата не найден.", "The task finished, but its output file is missing.")
                    return
                }
                activeWorkProgress = 100
                when (action) {
                    AudioRenderWorker.ACTION_RENDER, AudioRenderWorker.ACTION_MP3 -> {
                        pendingExport = outputFile
                        getSharedPreferences("sand_settings", MODE_PRIVATE).edit()
                            .putString("pending_export_path", outputFile.absolutePath)
                            .putString("pending_export_action", action)
                            .putString("pending_export_name", name)
                            .apply()
                        playRenderedFile(outputFile)
                        launchExportSaveDialog(outputFile, name, action)
                    }
                    AudioRenderWorker.ACTION_ORIGINAL -> {
                        statusText.text = t("Оригинальная дорожка готова.", "Original audio is ready.")
                        playRenderedFile(outputFile, isOriginal = true)
                    }
                    else -> {
                        statusText.text = t("Предпрослушивание готово.", "Preview is ready.")
                        playRenderedFile(outputFile)
                    }
                }
            }
            WorkInfo.State.CANCELLED -> {
                statusText.text = t("Обработка остановлена. Исходный файл не изменён.", "Processing cancelled. The source file was not changed.")
                outputFile?.delete()
            }
            WorkInfo.State.FAILED -> {
                statusText.text = t("Ошибка обработки: ${error ?: "неизвестная ошибка"}", "Processing failed: ${error ?: "unknown error"}")
                outputFile?.delete()
            }
            else -> statusText.text = t("Обработка завершилась.", "Processing finished.")
        }
    }

    private fun launchExportSaveDialog(file: File, originalName: String, action: String) {
        val mp3 = action == AudioRenderWorker.ACTION_MP3
        val extension = if (mp3) "mp3" else "wav"
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = if (mp3) "audio/mpeg" else "audio/wav"
            putExtra(Intent.EXTRA_TITLE, safeFileName(originalName) + "_remix.$extension")
        }
        statusText.text = t("Обработка завершена. Выбери место сохранения ${extension.uppercase(Locale.ROOT)}.", "Processing complete. Choose where to save the ${extension.uppercase(Locale.ROOT)} file.")
        startActivityForResult(intent, REQUEST_CREATE_EXPORT)
    }

    private fun playRenderedFile(file: File, isOriginal: Boolean = false) {
        stopPlayback()
        previewCacheFile = file
        try {
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnPreparedListener { media ->
                    playerPrepared = true
                    val hasFocus = requestLocalAudioFocus()
                    if (hasFocus) media.start()
                    transportTitle.text = if (isOriginal) t("Оригинал", "Original") else t("Обработанный ремикс", "Processed remix")
                    statusText.text = when {
                        !hasFocus -> t("Ожидаю освобождения аудиоканала.", "Waiting for audio focus.")
                        isOriginal -> t("Прослушивается оригинальная дорожка.", "Playing the original audio track.")
                        else -> t("Прослушивается обработанный ремикс.", "Playing processed remix.")
                    }
                    updateTransportUi()
                    handler.removeCallbacks(progressTicker)
                    handler.post(progressTicker)
                }
                setOnCompletionListener { finishPlayback(t("Предпрослушивание завершено.", "Preview finished.")) }
                setOnErrorListener { _, what, extra ->
                    showMessage("Playback error ($what/$extra)")
                    finishPlayback(t("Ошибка предпрослушивания.", "Preview playback error."))
                    true
                }
                prepareAsync()
            }
            transportTitle.text = t("Загрузка предпрослушивания…", "Loading preview…")
        } catch (error: Exception) {
            finishPlayback(t("Ошибка предпрослушивания: ${error.message}", "Preview error: ${error.message}"))
        }
    }

    private fun safeFileName(value: String): String {
        val noExtension = value.substringBeforeLast('.', value).trim()
        val cleaned = noExtension.replace(Regex("[^A-Za-zА-Яа-я0-9_-]+"), "_").trim('_')
        return cleaned.ifBlank { "SandOfMusic" }.take(48)
    }

    private fun updateBusyState(isBusy: Boolean) {
        busy = isBusy
        if (::progressBar.isInitialized) progressBar.visibility = if (isBusy) View.VISIBLE else View.GONE
        if (::renderButton.isInitialized) { renderButton.isEnabled = !isBusy; renderButton.alpha = if (isBusy) 0.55f else 1f }
        if (::mp3ExportButton.isInitialized) { mp3ExportButton.isEnabled = !isBusy; mp3ExportButton.alpha = if (isBusy) 0.55f else 1f }
        if (::previewButton.isInitialized) { previewButton.isEnabled = !isBusy; previewButton.alpha = if (isBusy) 0.55f else 1f }
        if (::sourcePreviewButton.isInitialized) { sourcePreviewButton.isEnabled = !isBusy; sourcePreviewButton.alpha = if (isBusy) 0.55f else 1f }
        if (::cancelWorkButton.isInitialized) cancelWorkButton.visibility = if (isBusy) View.VISIBLE else View.GONE
    }

    private fun showMessage(message: String) {
        if (::statusText.isInitialized) statusText.text = message
    }

    override fun onPause() {
        saveCurrentTrackSettings()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(progressTicker)
        activeWorkObserver?.let { activeWorkLiveData?.removeObserver(it) }
        activeWorkObserver = null
        activeWorkLiveData = null
        expandedPlayerDialog?.dismiss()
        spectrumDialog?.dismiss()
        stopVisualizer()
        stopLocalPreviewOnly()
        playbackListener?.let { listener -> mediaController?.removeListener(listener) }
        controllerFuture?.let { MediaController.releaseFuture(it) }
        mediaController = null
        controllerFuture = null
        albumArtExecutor.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_PICK_AUDIO = 410
        private const val REQUEST_CREATE_EXPORT = 411
        private const val REQUEST_LIBRARY_PERMISSION = 412
        private const val REQUEST_NOTIFICATION_PERMISSION = 413
        private const val UNIQUE_WORK_NAME = "sand_audio_processing_unique"
    }
}
