package com.sandofmusic.reverb

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.ln
import kotlin.math.sqrt

/** Lightweight neon FFT spectrum view driven by Android's Visualizer audio-effect API. */
class SpectrumVisualizerView(context: Context) : View(context) {
    enum class Mode { BARS, CIRCULAR, WAVE }
    var mode: Mode = Mode.BARS
        set(value) { field = value; invalidate() }
    private val bars = 52
    private val levels = FloatArray(bars)
    private val peaks = FloatArray(bars)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val density = resources.displayMetrics.density

    fun updateFft(fft: ByteArray) {
        if (fft.size < 8) return
        val half = fft.size / 2
        for (i in 0 until bars) {
            val ratio = i.toFloat() / bars
            val start = (2.0 * Math.pow((half / 2.0), ratio.toDouble())).toInt().coerceIn(1, half - 1)
            val end = (2.0 * Math.pow((half / 2.0), (i + 1).toDouble() / bars)).toInt().coerceIn(start + 1, half)
            var magnitude = 0.0
            for (bin in start until end) {
                val real = fft[bin * 2].toInt()
                val imaginary = fft[bin * 2 + 1].toInt()
                magnitude = maxOf(magnitude, sqrt((real * real + imaginary * imaginary).toDouble()))
            }
            val normalized = (ln(1.0 + magnitude) / ln(128.0)).toFloat().coerceIn(0f, 1f)
            levels[i] = maxOf(levels[i] * 0.62f, normalized)
            peaks[i] = maxOf(peaks[i] * 0.985f, levels[i])
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(5, 13, 27)
        canvas.drawRoundRect(0f, 0f, w, h, 18f * density, 18f * density, paint)
        paint.color = Color.argb(35, 110, 190, 220)
        for (line in 1..4) {
            val y = h * line / 5f
            canvas.drawLine(12f * density, y, w - 12f * density, y, paint)
        }
        if (mode == Mode.CIRCULAR) {
            val cx = w / 2f; val cy = h / 2f
            val inner = minOf(w, h) * 0.19f
            val outer = minOf(w, h) * 0.43f
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f * density
            paint.color = Color.argb(90, 65, 205, 220)
            canvas.drawCircle(cx, cy, inner, paint)
            canvas.drawCircle(cx, cy, outer, paint)
            paint.style = Paint.Style.FILL
            for (i in 0 until bars) {
                levels[i] *= 0.965f
                peaks[i] = maxOf(levels[i], peaks[i] - 0.0035f)
                val angle = (i.toDouble() / bars * Math.PI * 2.0 - Math.PI / 2.0).toFloat()
                val length = (outer - inner) * levels[i].coerceIn(0f, 1f)
                val r1 = inner
                val r2 = inner + maxOf(length, 2f * density)
                val x1 = cx + kotlin.math.cos(angle) * r1
                val y1 = cy + kotlin.math.sin(angle) * r1
                val x2 = cx + kotlin.math.cos(angle) * r2
                val y2 = cy + kotlin.math.sin(angle) * r2
                val hue = (188f + i.toFloat() / bars * 160f) % 360f
                paint.color = Color.HSVToColor(240, floatArrayOf(hue, 0.9f, 1f))
                paint.strokeWidth = (w / bars * 0.56f).coerceAtLeast(2f * density)
                paint.strokeCap = Paint.Cap.ROUND
                canvas.drawLine(x1, y1, x2, y2, paint)
                paint.color = Color.WHITE
                canvas.drawCircle(cx + kotlin.math.cos(angle) * (inner + (outer - inner) * peaks[i]), cy + kotlin.math.sin(angle) * (inner + (outer - inner) * peaks[i]), 1.4f * density, paint)
            }
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(53, 224, 210)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = 10f * density
            canvas.drawText("SAND AUDIO", cx, cy + 4f * density, paint)
            postInvalidateDelayed(33L)
            return
        }
        val side = 12f * density
        val gap = 3f * density
        val usable = w - side * 2
        val barWidth = (usable - gap * (bars - 1)) / bars
        val baseY = h * 0.84f
        for (i in 0 until bars) {
            levels[i] *= 0.965f
            peaks[i] = maxOf(levels[i], peaks[i] - 0.0035f)
            val barHeight = (h * 0.68f * levels[i]).coerceAtLeast(3f * density)
            val left = side + i * (barWidth + gap)
            val hue = (190f + (i.toFloat() / bars) * 145f) % 360f
            paint.color = Color.HSVToColor(235, floatArrayOf(hue, 0.86f, 1f))
            rect.set(left, baseY - barHeight, left + barWidth, baseY)
            canvas.drawRoundRect(rect, barWidth / 2f, barWidth / 2f, paint)
            val peakY = baseY - h * 0.68f * peaks[i]
            paint.color = Color.WHITE
            canvas.drawRoundRect(left, peakY - 2f * density, left + barWidth, peakY + 1f * density, barWidth, barWidth, paint)
        }
        if (mode == Mode.WAVE) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.2f * density
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = Color.rgb(53, 224, 210)
            val path = android.graphics.Path()
            for (i in 0 until bars) {
                val x = side + i * usable / (bars - 1f)
                val y = h * 0.5f - (levels[i] - 0.18f) * h * 0.72f
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
            paint.style = Paint.Style.FILL
        }
        if ((levels.maxOrNull() ?: 0f) < 0.015f) {
            paint.color = Color.argb(150, 180, 210, 230)
            paint.textSize = 11f * density
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("WAITING FOR AUDIO", w / 2f, h * 0.48f, paint)
        }
        postInvalidateDelayed(33L)
    }
}
