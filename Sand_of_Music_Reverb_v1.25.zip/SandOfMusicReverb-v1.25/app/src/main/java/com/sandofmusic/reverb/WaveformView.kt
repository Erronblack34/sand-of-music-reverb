package com.sandofmusic.reverb

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Compact waveform envelope with draggable start/end range handles. */
class WaveformView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val density = resources.displayMetrics.density
    var amplitudes: FloatArray = FloatArray(0)
        set(value) { field = value; invalidate() }
    var selectionStart: Float = 0f
        private set
    var selectionEnd: Float = 1f
        private set
    var onSelectionChanged: ((Float, Float) -> Unit)? = null
    private var draggingStart = false
    private var draggingEnd = false

    fun setSelection(start: Float, end: Float) {
        selectionStart = start.coerceIn(0f, 0.98f)
        selectionEnd = end.coerceIn(selectionStart + 0.02f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        paint.color = Color.rgb(7, 18, 31)
        canvas.drawRoundRect(0f, 0f, w, h, 14f * density, 14f * density, paint)
        val left = w * selectionStart; val right = w * selectionEnd
        paint.color = Color.argb(42, 60, 220, 210)
        canvas.drawRect(left, 0f, right, h, paint)
        if (amplitudes.isEmpty()) {
            paint.color = Color.LTGRAY; paint.textAlign = Paint.Align.CENTER; paint.textSize = 12f * density
            canvas.drawText("Waveform", w / 2f, h / 2f, paint)
            return
        }
        val step = w / amplitudes.size
        for (i in amplitudes.indices) {
            val amp = amplitudes[i].coerceIn(0f, 1f)
            val barH = max(2f * density, amp * h * 0.82f)
            val x = (i + 0.5f) * step
            paint.color = if (x in left..right) Color.rgb(53, 224, 210) else Color.rgb(91, 132, 157)
            rect.set(x - max(1f, step * 0.28f), (h - barH) / 2f, x + max(1f, step * 0.28f), (h + barH) / 2f)
            canvas.drawRoundRect(rect, 2f * density, 2f * density, paint)
        }
        paint.color = Color.WHITE
        canvas.drawRect(left - density, 0f, left + density, h, paint)
        canvas.drawRect(right - density, 0f, right + density, h, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = (event.x / width.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                draggingStart = kotlin.math.abs(x - selectionStart) <= kotlin.math.abs(x - selectionEnd)
                draggingEnd = !draggingStart
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (draggingStart) selectionStart = min(x, selectionEnd - 0.02f).coerceAtLeast(0f)
                if (draggingEnd) selectionEnd = max(x, selectionStart + 0.02f).coerceAtMost(1f)
                onSelectionChanged?.invoke(selectionStart, selectionEnd)
                invalidate(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                draggingStart = false; draggingEnd = false
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick(); return true
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
