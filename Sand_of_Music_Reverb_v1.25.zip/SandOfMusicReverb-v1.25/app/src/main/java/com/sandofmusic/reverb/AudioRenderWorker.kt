package com.sandofmusic.reverb

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.ContentValues
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.work.Data
import androidx.work.ForegroundInfo
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Persistent foreground worker for long audio jobs.
 * It keeps the UI thread free and lets Android continue processing while the app is
 * in the background. Progress is emitted by the FFmpeg statistics callback.
 */
class AudioRenderWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : Worker(appContext, workerParams) {

    override fun doWork(): Result {
        val action = inputData.getString(KEY_ACTION) ?: ACTION_RENDER
        val english = inputData.getBoolean(KEY_ENGLISH, false)
        val languageCode = inputData.getString(KEY_LANGUAGE) ?: if (english) "en" else "ru"
        val uriText = inputData.getString(KEY_URI)
            ?: return failure("Не передан исходный файл.")
        val sourceUri = Uri.parse(uriText)
        val outputDir = File(applicationContext.filesDir, "renders").apply { mkdirs() }
        val extension = when (action) {
            ACTION_ORIGINAL, ACTION_PREVIEW, ACTION_MP3 -> "mp3"
            else -> "wav"
        }
        val output = File(outputDir, "sand_${id}.$extension")

        return try {
            setForegroundAsync(createForegroundInfo(localized("Подготовка файла…", languageCode), 0)).get(20, TimeUnit.SECONDS)
            publishProgress("Подготовка файла…", 1)

            val progress: (String, Int) -> Unit = { stage, percent ->
                if (!isStopped) publishProgress(stage, percent)
            }
            val cancelled = { isStopped }

            when (action) {
                ACTION_ORIGINAL -> MediaPipeline.makeOriginalPreview(
                    applicationContext, sourceUri, output, progress, cancelled
                )
                else -> {
                    val settings = MediaPipeline.Settings(
                        speed = inputData.getFloat(KEY_SPEED, 1f),
                        pitchSemitones = inputData.getFloat(KEY_PITCH, 0f),
                        reverbWet = inputData.getFloat(KEY_REVERB, 0f),
                        roomSize = inputData.getFloat(KEY_ROOM, 0.5f),
                        eqGainsDb = (inputData.getString(KEY_EQ) ?: "0,0,0,0,0,0,0,0,0,0")
                            .split(',').mapNotNull { it.toFloatOrNull() }.toFloatArray().let { values ->
                                FloatArray(10) { index -> values.getOrElse(index) { 0f } }
                            },
                        limiterEnabled = inputData.getBoolean(KEY_LIMITER, true),
                        reverse = inputData.getBoolean(KEY_REVERSE, false),
                        fadeInSeconds = inputData.getFloat(KEY_FADE_IN, 0f),
                        fadeOutSeconds = inputData.getFloat(KEY_FADE_OUT, 0f),
                        compressorEnabled = inputData.getBoolean(KEY_COMPRESSOR, false),
                        compressorThresholdDb = inputData.getFloat(KEY_COMPRESSOR_THRESHOLD, -18f),
                        compressorRatio = inputData.getFloat(KEY_COMPRESSOR_RATIO, 2f)
                    )
                    val format = if (action == ACTION_MP3 || action == ACTION_PREVIEW) {
                        MediaPipeline.OutputFormat.MP3
                    } else {
                        MediaPipeline.OutputFormat.WAV
                    }
                    MediaPipeline.render(
                        context = applicationContext,
                        sourceUri = sourceUri,
                        outputFile = output,
                        settings = settings,
                        format = format,
                        mp3Bitrate = if (action == ACTION_PREVIEW) "192k" else "320k",
                        onProgress = progress,
                        shouldCancel = cancelled,
                        trimStartMs = inputData.getLong(KEY_TRIM_START_MS, 0L),
                        trimEndMs = inputData.getLong(KEY_TRIM_END_MS, -1L)
                    )
                }
            }

            if (isStopped) {
                output.delete()
                Result.failure()
            } else {
                publishProgress("Готово", 100)
                val sourceName = inputData.getString(KEY_SOURCE_NAME) ?: "SandOfMusic"
                val resultDataBuilder = Data.Builder()
                    .putString(KEY_OUTPUT_FILE, output.absolutePath)
                    .putString(KEY_ACTION, action)
                    .putString(KEY_SOURCE_NAME, sourceName)
                if (inputData.getBoolean(KEY_AUTO_SAVE, false)) {
                    val savedUri = publishBatchOutput(output, sourceName, action)
                    resultDataBuilder.putString(KEY_SAVED_URI, savedUri.toString())
                    output.delete()
                }
                val resultData = resultDataBuilder.build()
                showCompletionNotification()
                Result.success(resultData)
            }
        } catch (error: InterruptedException) {
            output.delete()
            Thread.currentThread().interrupt()
            Result.failure()
        } catch (error: Exception) {
            output.delete()
            if (inputData.getBoolean(KEY_BATCH_MODE, false)) {
                // A bad item must not cancel the remaining requests in the batch chain.
                Result.success(Data.Builder()
                    .putBoolean(KEY_BATCH_SKIPPED, true)
                    .putString(KEY_ERROR, (error.message ?: error.javaClass.simpleName).take(500))
                    .build())
            } else {
                failure(error.message ?: error.javaClass.simpleName)
            }
        }
    }

    private fun localized(stage: String, languageCode: String): String {
        if (languageCode == "ru") return stage
        val pairs = listOf(
            "Копирование исходного файла" to "Copying source file",
            "Файл подготовлен" to "Source file ready",
            "Обработка аудио" to "Processing audio",
            "Финальная проверка файла" to "Final file check",
            "Подготовка файла" to "Preparing file…",
            "Подготовка задачи" to "Preparing task…",
            "Готово" to "Complete"
        )
        val pair = pairs.firstOrNull { stage.startsWith(it.first) } ?: return stage
        val translated = LanguageCatalog.translate(languageCode, pair.first, pair.second)
        return translated + stage.removePrefix(pair.first)
    }

    private fun publishBatchOutput(file: File, sourceName: String, action: String): Uri {
        val isWav = action == ACTION_RENDER
        val extension = if (isWav) "wav" else "mp3"
        val mimeType = if (isWav) "audio/wav" else "audio/mpeg"
        val safeName = sourceName.substringBeforeLast('.').replace(Regex("[^A-Za-zА-Яа-я0-9_-]+"), "_").trim('_').ifBlank { "SandAudio" }.take(48)
        val displayName = "${safeName}_remix_${id.toString().take(8)}.$extension"
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Audio.Media.MIME_TYPE, mimeType)
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Sand of Music Reverb")
        }
        val uri = applicationContext.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Could not create media library item")
        try {
            applicationContext.contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
                ?: throw IllegalStateException("Could not write media library item")
            return uri
        } catch (error: Exception) {
            applicationContext.contentResolver.delete(uri, null, null)
            throw error
        }
    }

    private fun failure(message: String): Result = Result.failure(
        Data.Builder().putString(KEY_ERROR, message.take(700)).build()
    )

    private fun publishProgress(stage: String, percent: Int) {
        val safe = percent.coerceIn(0, 100)
        val shownStage = localized(stage, inputData.getString(KEY_LANGUAGE) ?: if (inputData.getBoolean(KEY_ENGLISH, false)) "en" else "ru")
        setProgressAsync(
            Data.Builder()
                .putInt(KEY_PROGRESS, safe)
                .putString(KEY_STAGE, stage)
                .build()
        )
        val notification = buildNotification(shownStage, safe)
        applicationContext.getSystemService(NotificationManager::class.java)
            ?.notify(NOTIFICATION_ID, notification)
    }

    private fun createForegroundInfo(stage: String, percent: Int): ForegroundInfo {
        createNotificationChannel()
        val notification = buildNotification(stage, percent)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Обработка аудио",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Длительная обработка и экспорт аудиофайлов" }
            applicationContext.getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(channel)
        }
    }

    private fun showCompletionNotification() {
        createNotificationChannel()
        val launchIntent = applicationContext.packageManager.getLaunchIntentForPackage(applicationContext.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val contentIntent = launchIntent?.let {
            PendingIntent.getActivity(applicationContext, 5106, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        val english = inputData.getBoolean(KEY_ENGLISH, false)
        val title = "Sand of Music Reverb"
        val text = if (english) "Audio render complete — tap to open" else "Обработка завершена — нажми, чтобы открыть"
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(applicationContext, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(applicationContext)
        }
        val notification = builder
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .build()
        applicationContext.getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID + 1, notification)
    }

    private fun buildNotification(stage: String, percent: Int): Notification {
        val cancelIntent = WorkManager.getInstance(applicationContext).createCancelPendingIntent(id)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(applicationContext, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(applicationContext)
        }
        val cancelLabel = if (inputData.getBoolean(KEY_ENGLISH, false)) "Cancel" else "Отменить"
        builder
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Sand of Music Reverb")
            .setContentText("$stage · $percent%")
            .setProgress(100, percent.coerceIn(0, 100), false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, cancelLabel, cancelIntent).build())
        return builder.build()
    }

    companion object {
        const val KEY_ACTION = "action"
        const val KEY_URI = "source_uri"
        const val KEY_SOURCE_NAME = "source_name"
        const val KEY_SPEED = "speed"
        const val KEY_PITCH = "pitch"
        const val KEY_REVERB = "reverb"
        const val KEY_ROOM = "room"
        const val KEY_EQ = "eq"
        const val KEY_LIMITER = "limiter"
        const val KEY_REVERSE = "reverse_audio"
        const val KEY_FADE_IN = "fade_in_seconds"
        const val KEY_FADE_OUT = "fade_out_seconds"
        const val KEY_COMPRESSOR = "compressor_enabled"
        const val KEY_COMPRESSOR_THRESHOLD = "compressor_threshold"
        const val KEY_COMPRESSOR_RATIO = "compressor_ratio"
        const val KEY_TRIM_START_MS = "trim_start_ms"
        const val KEY_TRIM_END_MS = "trim_end_ms"
        const val KEY_ENGLISH = "english"
        const val KEY_LANGUAGE = "language_code"
        const val KEY_PROGRESS = "progress"
        const val KEY_STAGE = "stage"
        const val KEY_OUTPUT_FILE = "output_file"
        const val KEY_ERROR = "error"
        const val KEY_AUTO_SAVE = "auto_save_to_music"
        const val KEY_SAVED_URI = "saved_media_uri"
        const val KEY_BATCH_MODE = "batch_mode"
        const val KEY_BATCH_SKIPPED = "batch_skipped"

        const val ACTION_RENDER = "render_wav"
        const val ACTION_MP3 = "render_mp3"
        const val ACTION_PREVIEW = "render_preview"
        const val ACTION_ORIGINAL = "original_preview"

        private const val CHANNEL_ID = "sand_audio_processing"
        private const val NOTIFICATION_ID = 5105
    }
}
