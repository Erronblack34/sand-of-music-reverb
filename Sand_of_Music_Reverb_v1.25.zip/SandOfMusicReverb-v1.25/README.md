# Sand of Music Reverb 1.25

Android player and mobile audio-editing workspace. This release expands the v1.2.2 baseline with an offline waveform envelope and trim editor, ten-band EQ, fade controls, compressor/limiter mastering controls, custom presets, A/B preview actions, sequential batch rendering, and multiple FFT visualizer modes.

## v1.25 features

- **Waveform Editor:** decodes up to 30 minutes to a compact mono peak envelope, lets the user select a range, preview it, or export the selected range as WAV. Trim uses FFmpeg input seeking; fade-in and fade-out are processed by FFmpeg `afade`.
- **Ten-band EQ:** 31 Hz through 16 kHz, with per-band gain carried through background render jobs.
- **Fade In / Fade Out:** adjustable duration for the full render or selected waveform region.
- **A/B Preview:** action sheet to render/play the original (A) or processed result (B). This first implementation restarts the selected preview rather than switching two streams at the same timestamp.
- **Custom Presets:** save, load, and delete user profiles locally, including speed, pitch, reverb, EQ, fades, mastering parameters, reverse and selected genre/style.
- **Audio Mastering:** optional FFmpeg compressor, configurable threshold/ratio, and peak limiter.
- **Batch Processing:** select up to 30 audio files; they are processed sequentially with the current settings and saved to `Music/Sand of Music Reverb`. A failed item is skipped so later items can continue.
- **Visualizer 2.0:** live FFT bars, circular spectrum, and spectrum-wave presentation. The Android Visualizer API may be restricted by device/OS policy.
- **Experimental stereo component export:** creates CENTER and SIDE approximations locally. It is explicitly **not neural vocal/instrumental separation**. A true two-stem splitter still requires a validated on-device ML model and is not claimed in this release.

## Retained functionality

The release retains the existing genre/style profiles, searchable pickers, player and Media3 service, background rendering, reverse audio, FFmpeg export and per-track settings. The application ID remains `com.sandofmusic.reverb`.

## Engineering notes

- `versionCode = 125`, `versionName = 1.25`.
- New render settings are passed through WorkManager `Data`.
- Batch jobs are chained sequentially to avoid multiple FFmpeg jobs competing for memory/CPU.
- The waveform analysis is capped at 30 minutes and uses 1 kHz mono PCM before peak reduction to keep memory use bounded.
- A/B currently selects between two render/play actions and is not sample-synchronous.
- Center/side output may not isolate vocals: centered instruments remain in CENTER, while stereo vocal reverb can remain in SIDE.

## Build

Upload `Sand_of_Music_Reverb_v1.25.zip` to the repository root. The workflow checks that exact name and extracts folder `SandOfMusicReverb-v1.25`. Replace `.github/workflows/build-apk.yml` with `build-apk-v1.25.yml`. The output artifact is `SandOfMusicReverb_v1.25.apk`.
