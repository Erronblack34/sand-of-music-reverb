# Sand of Music Reverb 1.25 — Technical Plan and Implemented Scope

## Baseline

Use the user-supplied `Sand_of_Music_Reverb_v1.2.2.zip` as the starting point. Preserve package ID, Media3 player/service, existing genre catalog, current processing profiles, reverse processing, visualizer permission path, WorkManager renderer, and export flow.

## Implemented in this source package

### Audio Editor
- Waveform envelope analysis through local FFmpeg decode to mono float PCM, bounded to 30 minutes and reduced to 260 peak bins.
- Draggable start/end selection markers.
- Preview selected range or export selection to WAV.
- Start/end trim values are passed to `AudioRenderWorker` and then FFmpeg input seeking.
- Fade In and Fade Out durations (0–10 seconds in UI) are passed through WorkManager and rendered using `afade`.

### EQ and mastering
- Expand EQ storage and render serialization from five to ten bands.
- Bands: 31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000 Hz.
- Gains: -12 dB to +12 dB.
- Optional `acompressor` with adjustable threshold and ratio.
- Existing limiter retained.

### Remix / presets
- A/B action dialog launches original or processed preview. The selected branch is re-rendered/played and starts from the beginning; synchronized same-position switching is a future refinement.
- Custom Presets save/load/delete locally in SharedPreferences.
- Saved values include speed, pitch, reverb, room, EQ, fades, compressor, limiter, reverse, genre and style.

### Batch processing
- Android multi-document picker, maximum 30 tracks per batch.
- Sequential WorkManager chain with the current processing settings.
- Results are published to `Music/Sand of Music Reverb`.
- Failed batch items return a successful skip result so the remaining chain can continue.

### Visualizer 2.0
- Retain live FFT capture.
- Add circular spectral bars and spectrum-wave display modes.
- Availability remains device/Android-policy dependent because the Android Visualizer API does not guarantee capture of every output stream.

### Stem tool limitation
- Include an offline stereo CENTER/SIDE component export as an experimental tool.
- Do not label it as accurate vocal/instrumental separation.
- True stem separation is deferred until a compatible local inference model (e.g. Demucs-derived ONNX/TFLite) can be packaged or imported, with memory, CPU, license, and device benchmarking validated.

## Acceptance criteria

1. Existing player, library, reverse render, searchable pickers and original genre profiles remain intact.
2. Waveform is generated from decoded audio, not a decorative placeholder.
3. Range selection affects actual FFmpeg trim start/duration.
4. Fade, ten-band EQ, compressor and limiter values are passed to the worker.
5. Preset data persists after app restart.
6. Batch processes in order and saves results into Music; a failed item does not cancel subsequent requests.
7. Visualizer mode changes redraw using live FFT magnitudes.
8. Stereo split is clearly described as approximate, not model-based.
9. GitHub Actions verifies archive name, extracted project folder, source smoke checks, and `assembleDebug`.

## Explicit non-claims

- A/B is not yet sample-accurate/same-timestamp switching.
- CENTER/SIDE is not real AI stem separation.
- A green source smoke test does not replace Android Gradle build and on-device QA.
