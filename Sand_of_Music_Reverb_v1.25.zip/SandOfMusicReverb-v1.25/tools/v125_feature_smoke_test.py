from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
pkg = root / "app/src/main/java/com/sandofmusic/reverb"
main = (pkg / "MainActivity.kt").read_text(encoding="utf-8")
pipe = (pkg / "MediaPipeline.kt").read_text(encoding="utf-8")
worker = (pkg / "AudioRenderWorker.kt").read_text(encoding="utf-8")
stem = (pkg / "StemSplitWorker.kt").read_text(encoding="utf-8")
wave = (pkg / "WaveformView.kt").read_text(encoding="utf-8")
visual = (pkg / "SpectrumVisualizerView.kt").read_text(encoding="utf-8")
dsp = (pkg / "DspEngine.kt").read_text(encoding="utf-8")
gradle = (root / "app/build.gradle.kts").read_text(encoding="utf-8")

assert "versionCode = 125" in gradle and 'versionName = "1.25"' in gradle
assert 'applicationId = "com.sandofmusic.reverb"' in gradle
assert "private val eqGains = FloatArray(10)" in main
assert "10-BAND EQUALIZER" in main and '"16 kHz"' in main
assert all(str(freq) in pipe for freq in [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000])
assert "private val eqFrequencies = floatArrayOf(31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)" in dsp

# Waveform is decoded from audio data, shown with draggable selection, then rendered via trim arguments.
assert "fun analyzeWaveform(" in pipe and '"pcm_f32le"' in pipe
assert "class WaveformView" in wave and "onSelectionChanged" in wave
assert "showWaveformEditorDialog()" in main
assert "KEY_TRIM_START_MS" in main and "KEY_TRIM_END_MS" in main and "trimStartMs = inputData.getLong" in worker
assert "afade=t=in" in pipe and "afade=t=out" in pipe

# Mastering controls are real FFmpeg filters and are transported to the background worker.
assert "acompressor=" in pipe and "compressorEnabled" in pipe
assert "KEY_COMPRESSOR" in worker and "KEY_COMPRESSOR_THRESHOLD" in worker and "KEY_COMPRESSOR_RATIO" in worker
assert "showMasteringDialog()" in main

# Presets, batch queue, and A/B preview are wired into the existing activity.
for token in ["showAbPreviewDialog()", "saveCustomPreset(", "loadCustomPreset(", "deleteCustomPreset(", "enqueueBatchProcessing("]:
    assert token in main, token
assert "beginUniqueWork(\"sand-audio-batch\"" in main
assert "KEY_AUTO_SAVE" in main and "publishBatchOutput" in worker and "KEY_BATCH_MODE" in worker

# Stem function is honestly labeled as stereo center/side approximation, not ML separation.
assert "splitCenterSide" in pipe and "StemSplitWorker" in main
assert "NOT neural source separation" in main or "не нейросетевое разделение" in main
assert "CENTER" in stem and "SIDE" in stem

# Visualizer modes consume the live FFT and have three render modes.
for token in ["Mode { BARS, CIRCULAR, WAVE }", "Mode.CIRCULAR", "Mode.WAVE"]:
    assert token in visual or token in main, token
assert "updateFft" in visual and "Visualizer.OnDataCaptureListener" in main

# Preserve existing audio features and package identity.
assert 'if (settings.reverse) filters += "areverse"' in pipe
assert "Media3" in (root / "README.md").read_text(encoding="utf-8") or "MediaSessionService" in main
assert (pkg / "PlaybackService.kt").exists()

print("v1.25 feature smoke checks: PASS")
