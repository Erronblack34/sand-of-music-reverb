package com.sandofmusic.reverb

fun main() {
    val genres = GenreCatalog.options.map { it.key }
    val styles = GenreStyleProfiles.styleKeys().toList()
    check(genres.size == 95) { "Expected 95 genres, got ${genres.size}" }
    check(styles.size == 17) { "Expected 17 styles, got ${styles.size}" }
    check(GenreStyleProfiles.genreKeys().size == genres.size)
    check(GenreStyleProfiles.allCombinations() == 1615)
    check(GenreStyleProfiles.validateProfiles())
    val profiles = genres.flatMap { genre -> styles.map { style -> GenreStyleProfiles.combine(genre, style) } }
    check(profiles.size == 1615) { "Expected 1615 genre/style combinations, got ${profiles.size}" }
    check(profiles.all { it.eqGainsDb.size == 5 })
    check(profiles.all { it.speed in 0.5f..1.6f && it.pitchSemitones in -12f..12f })
    check(profiles.all { it.reverbWet in 0f..0.65f && it.roomSize in 0f..1f })
    val signatures = profiles.map { profile ->
        listOf(profile.speed, profile.pitchSemitones, profile.reverbWet, profile.roomSize) + profile.eqGainsDb.toList()
    }.toSet()
    check(signatures.size == profiles.size) { "Expected distinct genre/style profiles, got ${signatures.size}" }
    println("PASS: ${profiles.size} distinct genre/style profiles across ${genres.size} genres and ${styles.size} styles")
}
