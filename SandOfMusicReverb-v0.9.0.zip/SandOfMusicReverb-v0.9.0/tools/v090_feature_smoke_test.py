from pathlib import Path
root = Path(__file__).resolve().parents[1]
profiles = (root / 'app/src/main/java/com/sandofmusic/reverb/GenreStyleProfiles.kt').read_text()
activity = (root / 'app/src/main/java/com/sandofmusic/reverb/MainActivity.kt').read_text()
for token in ['reggaeton', 'drum_bass', 'dubstep', 'kpop', 'super_slowed', 'ultra_slowed', 'chipmunk']:
    assert f'"{token}"' in profiles, token
for token in ['"genres" to', 'trackSettingsKey', 'saveCurrentTrackSettings', 'loadTrackSettings', 'MediaStore.Audio.Genres']:
    assert token in activity, token
build = (root / 'app/build.gradle.kts').read_text()
assert 'versionCode = 90' in build and 'versionName = "0.9.0"' in build
print('v0.9.0 feature smoke checks: PASS')
