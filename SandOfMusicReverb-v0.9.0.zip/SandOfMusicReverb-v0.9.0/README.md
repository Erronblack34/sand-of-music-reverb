# Sand of Music Reverb 0.9.0

Android audio editor with genre-aware processing, per-track settings, media-library browsing, and continuous queue playback.

## v0.9.0 changes
- Expanded genre profiles: Reggaeton, Trap, Metal, Classical, Soul, Disco, Drum & Bass, Dubstep, Country, Latin, K-Pop, Indie, Punk, plus the previous genres.
- Expanded processing styles: Super Slowed, Ultra Slowed, Slowed, Speed Up, and Chipmunk.
- Genre tab in the media library, using Android MediaStore genre metadata.
- Per-track processing values are saved locally and restored when that track is selected again.
- Library is queried from MediaStore each time it opens, so newly indexed audio downloads appear without manually adding each file.
- Queue playback continues through the displayed track list using the existing Media3 session.

## Build
Use the repository's GitHub Actions workflow `build-apk-v0.9.0.yml`, or run `gradle assembleDebug` from this directory with Android SDK installed.
