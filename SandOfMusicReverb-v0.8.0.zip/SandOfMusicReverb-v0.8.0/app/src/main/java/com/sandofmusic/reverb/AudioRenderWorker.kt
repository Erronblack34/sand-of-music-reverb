package com.sandofmusic.reverb

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import androidx.work.Data
import androidx.work.ForegroundInfo
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Persistent foreground worker for long audio jobs.
 * It keeps the UI thread free and lets Android continue processing while the app is
 * in the background. Progress is emitted by the FFmpeg statistics callback.
 */
class AudioRenderWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : Worker(appContext, workerParams) {

    override fun doWork(): Result {
        val action = inputData.getString(KEY_ACTION) ?: ACTION_RENDER
        val english = inputData.getBoolean(KEY_ENGLISH, false)
        val languageCode = inputData.getString(KEY_LANGUAGE) ?: if (english) "en" else "ru"
        val uriText = inputData.getString(KEY_URI)
            ?: return failure("Не передан исходный файл.")
        val sourceUri = Uri.parse(uriText)
        val outputDir = File(applicationContext.filesDir, "renders").apply { mkdirs() }
        val extension = when (action) {
            ACTION_ORIGINAL, ACTION_PREVIEW, ACTION_MP3 -> "mp3"
            else -> "wav"
        }
        val output = File(outputDir, "sand_${id}.$extension")

        return try {
            setForegroundAsync(createForegroundInfo(localized("Подготовка файла…", languageCode), 0)).get(20, TimeUnit.SECONDS)
            publishProgress("Подготовка файла…", 1)

            val progress: (String, Int) -> Unit = { stage, percent ->
                if (!isStopped) publishProgress(stage, percent)
            }
            val cancelled = { isStopped }

            when (action) {
                ACTION_ORIGINAL -> MediaPipeline.makeOriginalPreview(
                    applicationContext, sourceUri, output, progress, cancelled
                )
                else -> {
                    val settings = MediaPipeline.Settings(
                        speed = inputData.getFloat(KEY_SPEED, 1f),
                        pitchSemitones = inputData.getFloat(KEY_PITCH, 0f),
                        reverbWet = inputData.getFloat(KEY_REVERB, 0f),
                        roomSize = inputData.getFloat(KEY_ROOM, 0.5f),
                        eqGainsDb = (inputData.getString(KEY_EQ) ?: "0,0,0,0,0")
                            .split(',').mapNotNull { it.toFloatOrNull() }.toFloatArray().let { values ->
                                FloatArray(5) { index -> values.getOrElse(index) { 0f } }
                            },
                        limiterEnabled = inputData.getBoolean(KEY_LIMITER, true)
                    )
                    val format = if (action == ACTION_MP3 || action == ACTION_PREVIEW) {
                        MediaPipeline.OutputFormat.MP3
                    } else {
                        MediaPipeline.OutputFormat.WAV
                    }
                    MediaPipeline.render(
                        context = applicationContext,
                        sourceUri = sourceUri,
                        outputFile = output,
                        settings = settings,
                        format = format,
                        mp3Bitrate = if (action == ACTION_PREVIEW) "192k" else "320k",
                        onProgress = progress,
                        shouldCancel = cancelled
                    )
                }
            }

            if (isStopped) {
                output.delete()
                Result.failure()
            } else {
                publishProgress("Готово", 100)
                Result.success(
                    Data.Builder()
                        .putString(KEY_OUTPUT_FILE, output.absolutePath)
                        .putString(KEY_ACTION, action)
                        .putString(KEY_SOURCE_NAME, inputData.getString(KEY_SOURCE_NAME) ?: "SandOfMusic")
                        .build()
                )
            }
        } catch (error: InterruptedException) {
            output.delete()
            Thread.currentThread().interrupt()
            Result.failure()
        } catch (error: Exception) {
            output.delete()
            failure(error.message ?: error.javaClass.simpleName)
        }
    }

    private fun localized(stage: String, languageCode: String): String {
        if (languageCode == "ru") return stage
        val pairs = listOf(
            "Копирование исходного файла" to "Copying source file",
            "Файл подготовлен" to "Source file ready",
            "Обработка аудио" to "Processing audio",
            "Финальная проверка файла" to "Final file check",
            "Подготовка файла" to "Preparing file…",
            "Подготовка задачи" to "Preparing task…",
            "Готово" to "Complete"
        )
        val pair = pairs.firstOrNull { stage.startsWith(it.first) } ?: return stage
        val translated = LanguageCatalog.translate(languageCode, pair.first, pair.second)
        return translated + stage.removePrefix(pair.first)
    }

    private fun failure(message: String): Result = Result.failure(
        Data.Builder().putString(KEY_ERROR, message.take(700)).build()
    )

    private fun publishProgress(stage: String, percent: Int) {
        val safe = percent.coerceIn(0, 100)
        val shownStage = localized(stage, inputData.getString(KEY_LANGUAGE) ?: if (inputData.getBoolean(KEY_ENGLISH, false)) "en" else "ru")
        setProgressAsync(
            Data.Builder()
                .putInt(KEY_PROGRESS, safe)
                .putString(KEY_STAGE, stage)
                .build()
        )
        val notification = buildNotification(shownStage, safe)
        applicationContext.getSystemService(NotificationManager::class.java)
            ?.notify(NOTIFICATION_ID, notification)
    }

    private fun createForegroundInfo(stage: String, percent: Int): ForegroundInfo {
        createNotificationChannel()
        val notification = buildNotification(stage, percent)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Обработка аудио",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Длительная обработка и экспорт аудиофайлов" }
            applicationContext.getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(stage: String, percent: Int): Notification {
        val cancelIntent = WorkManager.getInstance(applicationContext).createCancelPendingIntent(id)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(applicationContext, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(applicationContext)
        }
        val cancelLabel = if (inputData.getBoolean(KEY_ENGLISH, false)) "Cancel" else "Отменить"
        builder
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Sand of Music Reverb")
            .setContentText("$stage · $percent%")
            .setProgress(100, percent.coerceIn(0, 100), false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, cancelLabel, cancelIntent).build())
        return builder.build()
    }

    companion object {
        const val KEY_ACTION = "action"
        const val KEY_URI = "source_uri"
        const val KEY_SOURCE_NAME = "source_name"
        const val KEY_SPEED = "speed"
        const val KEY_PITCH = "pitch"
        const val KEY_REVERB = "reverb"
        const val KEY_ROOM = "room"
        const val KEY_EQ = "eq"
        const val KEY_LIMITER = "limiter"
        const val KEY_ENGLISH = "english"
        const val KEY_LANGUAGE = "language_code"
        const val KEY_PROGRESS = "progress"
        const val KEY_STAGE = "stage"
        const val KEY_OUTPUT_FILE = "output_file"
        const val KEY_ERROR = "error"

        const val ACTION_RENDER = "render_wav"
        const val ACTION_MP3 = "render_mp3"
        const val ACTION_PREVIEW = "render_preview"
        const val ACTION_ORIGINAL = "original_preview"

        private const val CHANNEL_ID = "sand_audio_processing"
        private const val NOTIFICATION_ID = 5105
    }
}
