# Build status — v0.8.0

Static checks: ZIP structure, Kotlin source structure, XML manifest and workflow syntax checks are run before delivery.
Android APK compilation must be confirmed by GitHub Actions; this environment does not have Android SDK/Gradle installed.
