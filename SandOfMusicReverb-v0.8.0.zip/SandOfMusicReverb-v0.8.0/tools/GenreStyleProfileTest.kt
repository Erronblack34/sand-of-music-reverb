package com.sandofmusic.reverb

fun main() {
    val genres = listOf("hiphop", "rock", "jazz", "afrobeats", "pop", "rnb", "edm", "phonk", "reggae", "lofi")
    val styles = listOf("original", "slowed_reverb", "nightcore", "daycore", "vaporwave", "dreamy_reverb", "dark_reverb", "ambient")
    check(GenreStyleProfiles.validateProfiles())
    val profiles = genres.flatMap { g -> styles.map { s -> GenreStyleProfiles.combine(g, s) } }
    check(profiles.size == 80)
    check(profiles.all { it.eqGainsDb.size == 5 })
    check(profiles.all { it.speed in 0.5f..1.6f && it.pitchSemitones in -12f..12f })
    check(profiles.all { it.reverbWet in 0f..0.65f && it.roomSize in 0f..1f })
    val signatures = profiles.map { p -> listOf(p.speed, p.pitchSemitones, p.reverbWet, p.roomSize) + p.eqGainsDb.toList() }.toSet()
    check(signatures.size == 80) { "Expected 80 distinct genre/style profiles, got ${signatures.size}" }
    println("PASS: ${profiles.size} distinct genre/style profiles")
}
