# Third-party notices — Sand of Music Reverb 0.6.0

## FFmpegKit maintained Android distribution

Artifact: `dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9`

The maintained FFmpegKit distribution is licensed under GNU Lesser General Public License v3.0 (LGPL-3.0). It includes the audio codec build used for local media decoding and MP3 encoding. The package includes its own `THIRD-PARTY-NOTICES.txt`; consult that bundled notice for the licenses and attributions of the exact binary components.

Project: https://github.com/ffmpegkit-maintained/ffmpeg

This project is not affiliated with or endorsed by FFmpegKit's original upstream author.

## AndroidX WorkManager

Artifact: `androidx.work:work-runtime-ktx:2.12.0`

AndroidX WorkManager is distributed under the Apache License 2.0. See the AndroidX project license and notices for the dependency and its transitive components.

Project: https://developer.android.com/jetpack/androidx/releases/work

## AndroidX Media3

Artifacts: `androidx.media3:media3-exoplayer:1.11.1` and `androidx.media3:media3-session:1.11.1`.

AndroidX Media3 is distributed under the Apache License 2.0. It provides ExoPlayer, MediaSessionService and system media controls. Project and release notes: https://developer.android.com/jetpack/androidx/releases/media3
