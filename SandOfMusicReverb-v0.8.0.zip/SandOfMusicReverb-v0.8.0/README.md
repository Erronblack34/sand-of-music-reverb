# Sand of Music Reverb 0.8.0

Android offline audio workstation.

## v0.8.0 additions
- Independent genre and processing-style selectors, combined into 80 distinct parameter profiles (10 genres x 8 styles).
- Editable speed, pitch, reverb, room and five-band EQ after applying a profile.
- Added Korean, Spanish, Portuguese, Hindi, Arabic, Persian and French language choices (15 languages total).
- Existing Media3 playback service, media library, FFmpeg import/export, background render and Loki branding retained.

Build: `gradle --no-daemon assembleDebug`
