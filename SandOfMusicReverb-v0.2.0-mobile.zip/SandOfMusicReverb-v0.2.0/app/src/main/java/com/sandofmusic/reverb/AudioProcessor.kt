package com.sandofmusic.reverb

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

 data class DecodedAudio(val samples: FloatArray, val sampleRate: Int, val channels: Int)

object AudioProcessor {
    private const val MAX_DURATION_SECONDS = 300
    // Bound peak heap use on mid-range Android devices (about 110 MiB of decoded Float PCM).
    private const val MAX_PCM_SAMPLES = 22_050_000L

    fun decode(context: Context, uri: Uri): DecodedAudio {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var selectedTrack = -1
            var inputFormat: MediaFormat? = null
            for (track in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(track)
                if (format.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    selectedTrack = track
                    inputFormat = format
                    break
                }
            }
            require(selectedTrack >= 0 && inputFormat != null) { "No audio stream was found in this file." }
            extractor.selectTrack(selectedTrack)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: error("Unknown audio codec.")
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(inputFormat, null, null, 0)
            decoder.start()

            var sampleRate = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            require(channels in 1..2) { "This version supports mono and stereo audio only." }
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
            val maxSamples = min(sampleRate.toLong() * channels * MAX_DURATION_SECONDS, MAX_PCM_SAMPLES)
            val samples = FloatAccumulator(min(65536L, maxSamples).toInt(), maxSamples.toInt())
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = decoder.getInputBuffer(inputIndex) ?: error("Decoder input buffer is unavailable.")
                        inputBuffer.clear()
                        val size = extractor.readSampleData(inputBuffer, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outputIndex = decoder.dequeueOutputBuffer(info, 10_000)
                when {
                    outputIndex >= 0 -> {
                        val outputBuffer = decoder.getOutputBuffer(outputIndex)
                        if (outputBuffer != null && info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                            val data = outputBuffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
                            data.position(info.offset)
                            data.limit(info.offset + info.size)
                            when (pcmEncoding) {
                                AudioFormat.ENCODING_PCM_FLOAT -> while (data.remaining() >= 4) samples.add(data.float)
                                AudioFormat.ENCODING_PCM_32BIT -> while (data.remaining() >= 4) samples.add(data.int / 2147483648f)
                                AudioFormat.ENCODING_PCM_24BIT_PACKED -> while (data.remaining() >= 3) {
                                    val b0 = data.get().toInt() and 0xff
                                    val b1 = data.get().toInt() and 0xff
                                    val b2 = data.get().toInt() and 0xff
                                    var value = b0 or (b1 shl 8) or (b2 shl 16)
                                    if (value and 0x800000 != 0) value = value or -0x1000000
                                    samples.add(value / 8388608f)
                                }
                                AudioFormat.ENCODING_PCM_8BIT -> while (data.remaining() >= 1) samples.add(((data.get().toInt() and 0xff) - 128) / 128f)
                                else -> while (data.remaining() >= 2) samples.add(data.short / 32768f)
                            }
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        decoder.releaseOutputBuffer(outputIndex, false)
                    }
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val outputFormat = decoder.outputFormat
                        if (outputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (outputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                            channels = outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            require(channels in 1..2) { "This version supports mono and stereo audio only." }
                        }
                        if (outputFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) pcmEncoding = outputFormat.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    }
                }
            }
            require(samples.size() > 0) { "The selected file decoded to an empty audio stream." }
            val decoded = samples.toArray()
            require(decoded.size % channels == 0) { "The decoded audio channel layout is invalid." }
            return DecodedAudio(decoded, sampleRate, channels)
        } finally {
            try { decoder?.stop() } catch (_: Exception) { }
            try { decoder?.release() } catch (_: Exception) { }
            extractor.release()
        }
    }

    fun writeWav(file: File, samples: FloatArray, sampleRate: Int, channels: Int) {
        require(channels in 1..2 && samples.size % channels == 0) { "Invalid PCM channel layout." }
        val dataBytesLong = samples.size.toLong() * 2L
        require(dataBytesLong <= 0xffff_ffffL - 36L) { "WAV file exceeds the RIFF size limit." }
        val dataBytes = dataBytesLong.toInt()
        BufferedOutputStream(FileOutputStream(file)).use { output ->
            fun writeLe(value: Int, bytes: Int) {
                for (shift in 0 until bytes) output.write((value ushr (shift * 8)) and 0xff)
            }
            output.write("RIFF".toByteArray(Charsets.US_ASCII)); writeLe(36 + dataBytes, 4)
            output.write("WAVE".toByteArray(Charsets.US_ASCII))
            output.write("fmt ".toByteArray(Charsets.US_ASCII)); writeLe(16, 4)
            writeLe(1, 2); writeLe(channels, 2); writeLe(sampleRate, 4)
            writeLe(sampleRate * channels * 2, 4); writeLe(channels * 2, 2); writeLe(16, 2)
            output.write("data".toByteArray(Charsets.US_ASCII)); writeLe(dataBytes, 4)
            for (sample in samples) {
                val value = (sample.coerceIn(-1f, 1f) * 32767f).toInt()
                writeLe(value, 2)
            }
        }
    }

    private class FloatAccumulator(initialCapacity: Int, private val maxSize: Int) {
        private var buffer = FloatArray(initialCapacity.coerceAtLeast(1))
        private var count = 0
        fun size() = count
        fun add(value: Float) {
            if (count >= maxSize) throw IllegalArgumentException("This release supports audio up to about four minutes, depending on sample rate and channel count. Trim the source or use a shorter file.")
            if (count == buffer.size) {
                val nextSize = min(maxSize, max(buffer.size + 1, buffer.size * 2))
                buffer = buffer.copyOf(nextSize)
            }
            buffer[count++] = if (value.isFinite()) value.coerceIn(-1f, 1f) else 0f
        }
        fun toArray() = buffer.copyOf(count)
    }
}
