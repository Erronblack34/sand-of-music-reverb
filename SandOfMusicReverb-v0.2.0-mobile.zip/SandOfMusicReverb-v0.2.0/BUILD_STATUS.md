# Build and verification report — Sand of Music Reverb 0.2.0

## Current result

- Android source project: prepared.
- DSP module: compiled with the local Kotlin compiler and passed the included synthetic-audio smoke tests.
- Android application Kotlin sources: syntax/type-checked against local lightweight Android API stubs; this is not a substitute for compiling against the real Android SDK.
- Android manifest, theme and launcher vector XML: parsed successfully.
- Real APK: **not generated in this environment**.

## Why an APK could not be produced here

The current build container has JDK 21, but does not contain Gradle, Android SDK Platform 35, Android Build Tools (`aapt2`, `d8`, `apksigner`) or an Android platform `android.jar`. Outbound network access is unavailable, so these components could not be installed or downloaded during this run. A placeholder file is not being presented as an APK.

## DSP smoke tests run

`tools/dsp_smoke_test.kt` synthesizes stereo audio and verifies:

1. Slowed output duration is consistent with the selected speed.
2. Nightcore output duration is consistent with the selected speed.
3. Slowed mode preserves a 440 Hz test tone while speed changes.
4. A +3 semitone Nightcore shift moves the test tone to approximately 523 Hz.
5. Output samples remain finite and the enabled limiter keeps sample peaks within the digital ceiling.
6. A silent right channel remains silent during stereo reverb processing.

All included smoke tests passed with the local Kotlin/JVM compiler. A separate 60-second stereo processing benchmark completed in approximately 0.4 seconds on this build host; mobile-device performance will vary.

## How to create the APK

1. Open the `SandOfMusicReverb` project folder in Android Studio.
2. Install Android SDK Platform 35 and a matching Android Build Tools version when prompted.
3. Use JDK 17 or 21 and allow Android Studio to sync the Gradle project.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Alternatively, install Gradle 8.9, configure the Android SDK path, and run:

```bash
./build_debug_apk.sh
```

Expected output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

The resulting debug APK is for testing. Before public release, also test on physical devices and create a signed release build.
