#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle was not found. Install Gradle 8.9 or open this project in Android Studio." >&2
  exit 2
fi

if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" && ! -f local.properties ]]; then
  echo "WARNING: Android SDK path was not detected. Configure ANDROID_HOME / ANDROID_SDK_ROOT or create local.properties." >&2
fi

gradle --no-daemon --stacktrace assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -f "$APK" ]]; then
  echo "ERROR: Gradle finished but the expected APK was not found: $APK" >&2
  exit 3
fi

echo "APK created: $APK"
