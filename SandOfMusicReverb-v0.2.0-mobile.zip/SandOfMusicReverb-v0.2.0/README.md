# Sand of Music Reverb — Android source project

**Version:** 0.2.0 (development build)  
**Application ID:** `com.sandofmusic.reverb`  
**Minimum Android:** 8.0 / API 26  
**Target Android:** API 34  
**Language:** Russian / English  
**Dependencies:** Android platform APIs only; no network permission and no third-party runtime dependency.

## What is implemented

- Native Android interface with Simple and PRO workspaces.
- Russian / English UI toggle, remembered locally.
- Import audio through Android's system file picker (Storage Access Framework).
- Original audio preview.
- Quick presets: Slowed + Reverb, Nightcore, Dreamy, Dark, Hyper.
- Independent speed and pitch controls: cubic resampling changes pitch, then WSOLA overlap-add restores the requested duration.
- Stereo-safe algorithmic reverb with separate delay state per channel.
- PRO five-band peaking EQ, room-size control and safety limiter.
- Offline rendering and processed-track preview.
- WAV export as 16-bit PCM via Android's save-file picker.
- Temporary processing files are stored in the app cache and copied to the user's chosen destination.

## Audio processing notes

The current engine uses a lightweight WSOLA time-stretch implementation. It is designed to be usable on mobile hardware and to keep pitch independent from duration, but it is not a phase-vocoder or commercial-grade elastique/Rubber Band engine. Extreme speed/pitch combinations can produce transient smearing or modulation artifacts. The reverb is an algorithmic feedback/diffusion design, not an impulse-response convolution reverb. MP3 export, multitrack editing, waveform trimming, background rendering, user-preset management and undo history are not included in this release.

The decoder uses Android MediaCodec. Supported input formats therefore depend on the codecs provided by the device. The current release accepts mono/stereo files and limits decoded PCM to approximately four minutes, depending on sample rate and channel count to keep memory use bounded on phones. WAV export is 16-bit PCM at the decoded sample rate.

## Build

Requirements:
- Android Studio with Android SDK Platform 35 and Build Tools installed.
- JDK 17 or 21.
- Android Gradle Plugin 8.7.3 and Kotlin Android plugin 2.0.21 (Android Studio/Gradle resolves these from configured repositories).

Open the `SandOfMusicReverb` folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Command line, from this folder, with Gradle 8.9 installed:

```bash
gradle assembleDebug
```

Debug APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Project layout

```text
app/src/main/java/com/sandofmusic/reverb/
  MainActivity.kt       Native UI, import, preview, export
  AudioProcessor.kt    MediaCodec decode and WAV writer
  DspEngine.kt         Independent pitch/time processing, reverb, EQ, limiter
app/src/main/res/values/styles.xml
app/src/main/AndroidManifest.xml
tools/dsp_smoke_test.kt
```

## QA checklist before public distribution

1. Build and install on at least one Android 8+ device and one current Android device.
2. Test MP3, M4A/AAC, WAV and FLAC where the device decoder supports them.
3. Test mono and stereo, short and long tracks, and interrupted file picker flows.
4. Listen for transient smearing at extreme settings and compare output duration/pitch against a reference tone.
5. Test export to internal storage, SD card and cloud document providers.
6. Add proper privacy, attribution and open-source notices before publishing any third-party DSP dependency.

This is a development build. It has not yet been field-tested on a physical Android device.

## Local DSP smoke tests

The DSP engine is plain Kotlin and can be tested without Android SDK:

```bash
kotlinc app/src/main/java/com/sandofmusic/reverb/DspEngine.kt tools/dsp_smoke_test.kt -include-runtime -d /tmp/sand-dsp-tests.jar
java -jar /tmp/sand-dsp-tests.jar
```

For an Android debug build, use `./build_debug_apk.sh` after installing Gradle 8.9 and configuring the Android SDK. See [BUILD_STATUS.md](BUILD_STATUS.md) for the verification boundary and current environment limitation.
