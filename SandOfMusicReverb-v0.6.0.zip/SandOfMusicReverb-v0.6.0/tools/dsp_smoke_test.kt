package com.sandofmusic.reverb

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

fun main() {
    val rate = 44100
    val channels = 2
    val seconds = 2
    val frames = rate * seconds
    val stereo = FloatArray(frames * channels)
    for (i in 0 until frames) {
        val tone = (0.35 * sin(2.0 * PI * 440.0 * i / rate)).toFloat()
        stereo[i * channels] = tone
        stereo[i * channels + 1] = tone * 0.5f
    }

    val slowed = DspEngine.process(stereo, rate, channels, DspSettings(speed = 0.8f, pitchSemitones = 0f, reverbWet = 0f))
    val expectedSlowedFrames = (frames / 0.8f).toInt()
    check(abs(slowed.size / channels - expectedSlowedFrames) < 4) { "Slowed duration mismatch" }

    val nightcore = DspEngine.process(stereo, rate, channels, DspSettings(speed = 1.25f, pitchSemitones = 3f, reverbWet = 0.1f))
    val expectedFastFrames = (frames / 1.25f).toInt() + (rate * (0.30f + 0.52f * 0.85f)).toInt()
    check(abs(nightcore.size / channels - expectedFastFrames) < 4) { "Nightcore duration/tail mismatch" }

    check(slowed.all { it.isFinite() }) { "Slowed output contains NaN/Infinity" }
    check(nightcore.all { it.isFinite() }) { "Nightcore output contains NaN/Infinity" }
    check(nightcore.maxOf { abs(it) } <= 0.93f) { "Output exceeds peak guard ceiling" }

    fun estimateFrequency(signal: FloatArray, sampleRate: Int, channelCount: Int): Float {
        val frameCount = signal.size / channelCount
        val start = frameCount / 5
        val end = frameCount * 3 / 5
        var crossings = 0
        var previous = signal[start * channelCount]
        for (frame in start + 1 until end) {
            val current = signal[frame * channelCount]
            if (previous <= 0f && current > 0f) crossings++
            previous = current
        }
        return crossings.toFloat() * sampleRate / (end - start)
    }
    val slowedTone = estimateFrequency(slowed, rate, channels)
    val nightcoreTone = estimateFrequency(nightcore, rate, channels)
    check(abs(slowedTone - 440f) < 10f) { "Slowed mode changed pitch unexpectedly: $slowedTone Hz" }
    check(abs(nightcoreTone - 440f * Math.pow(2.0, 3.0 / 12.0).toFloat()) < 12f) { "Nightcore pitch shift mismatch: $nightcoreTone Hz" }

    val oneSided = FloatArray(frames * 2)
    for (i in 0 until frames) oneSided[i * 2] = (0.2 * sin(2.0 * PI * 220.0 * i / rate)).toFloat()
    val stereoSafe = DspEngine.process(oneSided, rate, 2, DspSettings(speed = 1f, pitchSemitones = 0f, reverbWet = 0.55f))
    var rightPeak = 0f
    for (i in 0 until stereoSafe.size / 2) rightPeak = maxOf(rightPeak, abs(stereoSafe[i * 2 + 1]))
    check(rightPeak < 1e-6f) { "Stereo channels are bleeding into each other: $rightPeak" }

    println("PASS: duration, pitch/speed separation, reverb tail, finite output, peak guard and stereo isolation")
}
