#!/usr/bin/env bash
set -euo pipefail

gradle --no-daemon --stacktrace assembleDebug
printf '\nAPK: %s\n' "$(pwd)/app/build/outputs/apk/debug/app-debug.apk"
