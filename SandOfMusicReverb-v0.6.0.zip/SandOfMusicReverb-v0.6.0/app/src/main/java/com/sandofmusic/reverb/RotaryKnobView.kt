package com.sandofmusic.reverb

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Compact touch rotary control used for the main sound-shaping parameters. */
class RotaryKnobView(
    context: Context,
    private val label: String,
    private val minimum: Float,
    private val maximum: Float,
    initialValue: Float,
    private val accent: Int,
    private val formatter: (Float) -> String
) : View(context) {
    var onValueChanged: ((Float) -> Unit)? = null
    var value: Float = initialValue.coerceIn(minimum, maximum)
        private set

    private val density = resources.displayMetrics.density
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 5f * density
        color = 0xff233849.toInt()
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 5f * density
        color = accent
    }
    private val outerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xff102133.toInt()
    }
    private val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * density
        color = 0xff34536a.toInt()
    }
    private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 3f * density
        color = 0xffe6fbff.toInt()
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = 0xffeaf7ff.toInt()
        textSize = 15f * density
        typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = 0xff91aabd.toInt()
        textSize = 10f * density
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
    }
    private val arcBounds = RectF()

    init {
        contentDescription = "$label ${formatter(value)}. Drag around the dial to adjust."
        isClickable = true
        isFocusable = true
    }

    fun setValue(newValue: Float, notify: Boolean = false) {
        value = newValue.coerceIn(minimum, maximum)
        contentDescription = "$label ${formatter(value)}"
        invalidate()
        if (notify) onValueChanged?.invoke(value)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val desiredHeight = (132f * density).roundToInt()
        val width = resolveSize((104f * density).roundToInt(), widthMeasureSpec)
        val height = resolveSize(desiredHeight, heightMeasureSpec)
        setMeasuredDimension(width, height)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height * 0.43f
        val radius = min(width * 0.34f, height * 0.31f)
        arcBounds.set(cx - radius, cy - radius, cx + radius, cy + radius)

        canvas.drawCircle(cx, cy, radius + 8f * density, outerPaint)
        canvas.drawCircle(cx, cy, radius + 8f * density, innerPaint)
        canvas.drawArc(arcBounds, 135f, 270f, false, trackPaint)
        val fraction = ((value - minimum) / (maximum - minimum)).coerceIn(0f, 1f)
        canvas.drawArc(arcBounds, 135f, 270f * fraction, false, valuePaint)

        for (i in 0..10) {
            val angle = (135.0 + i * 27.0) * PI / 180.0
            val inner = radius + 12f * density
            val outer = inner + if (i % 5 == 0) 5f * density else 2.5f * density
            val x1 = cx + cos(angle).toFloat() * inner
            val y1 = cy + sin(angle).toFloat() * inner
            val x2 = cx + cos(angle).toFloat() * outer
            val y2 = cy + sin(angle).toFloat() * outer
            markerPaint.strokeWidth = if (i % 5 == 0) 1.8f * density else 1f * density
            markerPaint.color = if (i / 10f <= fraction) accent else 0xff456176.toInt()
            canvas.drawLine(x1, y1, x2, y2, markerPaint)
        }

        canvas.drawCircle(cx, cy, radius - 5f * density, outerPaint)
        canvas.drawCircle(cx, cy, radius - 5f * density, innerPaint)
        textPaint.textSize = 15f * density
        canvas.drawText(formatter(value), cx, cy + 5f * density, textPaint)
        labelPaint.textSize = 10f * density
        canvas.drawText(label.uppercase(), cx, height - 5f * density, labelPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val cx = width / 2f
                val cy = height * 0.43f
                val dx = event.x - cx
                val dy = event.y - cy
                val degrees = (Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat() + 360f) % 360f
                if (degrees in 45f..135f) return true // dead zone at the bottom of the dial
                val travelled = if (degrees < 135f) degrees + 225f else degrees - 135f
                val fraction = (travelled / 270f).coerceIn(0f, 1f)
                setValue(minimum + (maximum - minimum) * fraction, notify = true)
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_UP -> {
                performClick()
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
