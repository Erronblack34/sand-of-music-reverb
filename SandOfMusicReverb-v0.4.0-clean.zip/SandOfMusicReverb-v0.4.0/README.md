# Sand of Music Reverb 0.4.0

Android offline audio remix studio for Slowed + Reverb and Nightcore workflows.

## 0.4.0 changes

- New dark futuristic studio interface with cyan/violet accents.
- Touch rotary dials for speed, pitch and reverb.
- Sticky in-app player dock that stays visible while scrolling, with Play/Pause, Stop, seek and elapsed/total time.
- Refined pitch resampling using windowed-sinc interpolation.
- Smoother WSOLA overlap crossfades.
- More conservative reverb feedback and wet mix, plus a rendered reverb tail.
- Transparent peak guard using global gain reduction instead of hard sample-by-sample clipping.
- Music library, file picker, bilingual UI, Simple/Pro modes and WAV export retained.

## Controls

- Speed: 0.50x–1.60x.
- Pitch: -12 to +12 semitones.
- Reverb: 0–65%.
- Pro mode includes room size, 5-band EQ and peak-protection toggle.

The fixed bottom player dock controls the currently loaded original or rendered preview. It is an in-app player panel, not a separate Android home-screen widget or notification.

## Build

Requirements: JDK 17, Android SDK Platform 35, Build Tools 35.0.0, Gradle 8.9.

From this folder run:

```bash
gradle --no-daemon --stacktrace assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Notes

- Export currently remains WAV. MP3 encoding is not included in this version.
- Audio processing is offline. Long files and extreme speed/pitch settings require more memory and may take longer.
- The DSP smoke test can be run with `kotlinc` by compiling `DspEngine.kt` and `tools/dsp_smoke_test.kt` together.
