package com.sandofmusic.reverb

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.content.pm.PackageManager
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private var selectedUri: Uri? = null
    private var sourceName = ""
    private var sourceDetails = ""
    private var speed = 0.82f
    private var pitch = -2f
    private var reverb = 0.24f
    private var roomSize = 0.52f
    private val eqGains = FloatArray(5)
    private var limiterEnabled = true
    private var proMode = false
    private var english = false
    private var busy = false
    private var player: MediaPlayer? = null
    private var playerPrepared = false
    private var previewCacheFile: File? = null
    private var pendingExport: File? = null
    private var isSeeking = false

    private lateinit var content: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var trackTitle: TextView
    private lateinit var trackDetails: TextView
    private lateinit var renderButton: Button
    private lateinit var previewButton: Button
    private lateinit var sourcePreviewButton: Button
    private lateinit var playPauseButton: Button
    private lateinit var transportTitle: TextView
    private lateinit var transportTime: TextView
    private lateinit var transportSeek: SeekBar

    private val backgroundColor = Color.rgb(5, 12, 22)
    private val cardColor = Color.rgb(13, 27, 42)
    private val cardAlt = Color.rgb(17, 37, 53)
    private val cyan = Color.rgb(53, 224, 210)
    private val violet = Color.rgb(177, 113, 255)
    private val muted = Color.rgb(132, 161, 181)
    private val white = Color.rgb(233, 246, 255)
    private val handler = Handler(Looper.getMainLooper())

    private val progressTicker = object : Runnable {
        override fun run() {
            val current = player
            if (current != null && playerPrepared) {
                try {
                    val duration = current.duration.coerceAtLeast(1)
                    val position = current.currentPosition.coerceAtLeast(0)
                    if (!isSeeking) transportSeek.progress = ((position.toLong() * 1000L) / duration).toInt().coerceIn(0, 1000)
                    transportTime.text = "${formatTime(position)} / ${formatTime(duration)}"
                    handler.postDelayed(this, 250L)
                } catch (_: IllegalStateException) {
                    updateTransportUi()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val preferences = getSharedPreferences("sand_settings", MODE_PRIVATE)
        english = preferences.getBoolean("english", false)
        proMode = preferences.getBoolean("pro", false)
        window.statusBarColor = backgroundColor
        window.navigationBarColor = backgroundColor
        window.decorView.systemUiVisibility = 0
        buildUi()
    }

    private fun t(ru: String, en: String) = if (english) en else ru
    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()
    private fun params(width: Int = ViewGroup.LayoutParams.MATCH_PARENT, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) = LinearLayout.LayoutParams(width, height)

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(backgroundColor)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(backgroundColor)
            clipToPadding = false
            isFillViewport = true
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(16), dp(17), dp(22))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        buildTransportDock(root)
        setContentView(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        addText(brand, "SAND / MUSIC", 23, white, true)
        addText(brand, "A U D I O   L A B   •   V 0 4", 10, cyan, true)
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(actionButton(if (english) "РУС" else "EN", false) {
            english = !english
            getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putBoolean("english", english).apply()
            buildUi()
        }, params(dp(60), dp(40)))
        content.addView(top)
        addSpace(content, 5)
        addText(content, t("СТУДИЯ ОБРАБОТКИ ЗВУКА", "OFFLINE AUDIO WORKSTATION"), 10, muted, true)
        addText(content, t("Формируй звук. Управляй атмосферой.", "Shape the sound. Control the atmosphere."), 13, cyan)
        addSpace(content, 15)

        val trackCard = card()
        addBadge(trackCard, t("SOURCE INPUT", "SOURCE INPUT"), cyan)
        trackTitle = addText(trackCard, if (sourceName.isBlank()) t("Трек ещё не выбран", "No track selected") else sourceName, 17, white, true)
        trackDetails = addText(trackCard, if (sourceDetails.isBlank()) t("Добавь аудио из медиатеки или файлов", "Add audio from your library or files") else sourceDetails, 11, muted)
        addSpace(trackCard, 9)
        trackCard.addView(actionButton(t("♫  Открыть медиатеку", "♫  Open music library"), true) { openMusicLibrary() }, params())
        trackCard.addView(actionButton(t("＋  Выбрать аудиофайл", "＋  Choose audio file"), false) { pickAudio() }, params().apply { topMargin = dp(7) })
        content.addView(trackCard)
        addSpace(content, 15)

        val presetCard = card()
        addBadge(presetCard, t("SIGNAL PRESETS", "SIGNAL PRESETS"), violet)
        val presetRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presetRow1.addView(actionButton("SLOWED + REVERB", false) { applyPreset("slowed") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        presetRow1.addView(actionButton("NIGHTCORE", false) { applyPreset("nightcore") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(5) })
        presetCard.addView(presetRow1)
        val presetRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presetRow2.addView(actionButton("DREAM", false) { applyPreset("dreamy") }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
        presetRow2.addView(actionButton("DARK", false) { applyPreset("dark") }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        presetRow2.addView(actionButton("HYPER", false) { applyPreset("hyper") }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4) })
        presetCard.addView(presetRow2, params().apply { topMargin = dp(6) })
        content.addView(presetCard)
        addSpace(content, 15)

        val modeCard = card()
        addBadge(modeCard, t("WORKSPACE MODE", "WORKSPACE MODE"), cyan)
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modes.addView(actionButton(t("ПРОСТОЙ", "ESSENTIAL"), !proMode) {
            proMode = false
            getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putBoolean("pro", false).apply()
            buildUi()
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
        modes.addView(actionButton("PRO LAB", proMode) {
            proMode = true
            getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putBoolean("pro", true).apply()
            buildUi()
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) })
        modeCard.addView(modes)
        content.addView(modeCard)
        addSpace(content, 15)

        val controlCard = card()
        addBadge(controlCard, t("SOUND ENGINE / TOUCH DIALS", "SOUND ENGINE / TOUCH DIALS"), cyan)
        addText(controlCard, t("Коснись шкалы и поверни регулятор по дуге.", "Touch a dial and rotate along its arc."), 10, muted)
        val dialRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val speedDial = RotaryKnobView(this, t("Скорость", "SPEED"), 0.5f, 1.6f, speed, cyan) { "${fmt(it)}×" }
        speedDial.onValueChanged = { speed = it }
        val pitchDial = RotaryKnobView(this, t("Тон", "PITCH"), -12f, 12f, pitch, violet) { "${if (it > 0) "+" else ""}${it.roundToInt()} st" }
        pitchDial.onValueChanged = { pitch = it }
        val reverbDial = RotaryKnobView(this, t("Реверб", "REVERB"), 0f, 0.65f, reverb, cyan) { "${(it * 100).roundToInt()}%" }
        reverbDial.onValueChanged = { reverb = it }
        dialRow.addView(speedDial, LinearLayout.LayoutParams(0, dp(132), 1f))
        dialRow.addView(pitchDial, LinearLayout.LayoutParams(0, dp(132), 1f))
        dialRow.addView(reverbDial, LinearLayout.LayoutParams(0, dp(132), 1f))
        controlCard.addView(dialRow, params())

        if (proMode) {
            addSpace(controlCard, 6)
            addSlider(controlCard, t("Размер комнаты", "Room size"), 0, 100, (roomSize * 100).roundToInt(), { (it / 100f).also { v -> roomSize = v } }, { "$it%" })
            addSpace(controlCard, 4)
            addBadge(controlCard, t("ПЯТИПОЛОСНЫЙ ЭКВАЛАЙЗЕР", "5-BAND EQUALIZER"), violet)
            val frequencies = listOf("80 Hz", "250 Hz", "1 kHz", "4 kHz", "12 kHz")
            frequencies.forEachIndexed { index, name ->
                addSlider(controlCard, name, -6, 6, eqGains[index].roundToInt(), { eqGains[index] = it.toFloat() }, { "${if (it > 0) "+" else ""}$it dB" })
            }
            val limiter = CheckBox(this).apply {
                text = t("Защита пиков", "Peak protection")
                setTextColor(white)
                buttonTintList = ColorStateList.valueOf(cyan)
                isChecked = limiterEnabled
                setOnCheckedChangeListener { _, checked -> limiterEnabled = checked }
            }
            controlCard.addView(limiter)
            addText(controlCard, t("Защита снижает общий уровень только при необходимости, чтобы избежать жёсткого цифрового клиппинга.", "Peak protection lowers overall gain only when needed to avoid hard digital clipping."), 10, muted)
        }
        content.addView(controlCard)
        addSpace(content, 15)

        val actionsCard = card()
        addBadge(actionsCard, t("RENDER / MONITOR", "RENDER / MONITOR"), violet)
        sourcePreviewButton = actionButton(t("▶  Оригинал", "▶  Original"), false) { previewOriginal() }
        actionsCard.addView(sourcePreviewButton, params())
        previewButton = actionButton(t("♫  Создать предпрослушивание", "♫  Render preview"), false) { render(export = false) }
        actionsCard.addView(previewButton, params().apply { topMargin = dp(7) })
        renderButton = actionButton(t("↓  Экспортировать WAV", "↓  Export WAV"), true) { render(export = true) }
        actionsCard.addView(renderButton, params().apply { topMargin = dp(7) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.GONE
            indeterminateTintList = ColorStateList.valueOf(cyan)
        }
        actionsCard.addView(progressBar, params(-1, dp(4)).apply { topMargin = dp(9) })
        statusText = addText(actionsCard, t("Готов к работе. Выбери трек или пресет.", "Ready. Select a track or preset."), 11, muted)
        content.addView(actionsCard)

        addSpace(content, 17)
        addText(content, "SAND AUDIO ENGINE  •  LOCAL DSP  •  WAV MASTER", 9, muted, true).gravity = Gravity.CENTER
        addText(content, "v0.4.0 · Touch controls / Playback dock / Clean DSP", 9, muted).gravity = Gravity.CENTER
        updateBusyState(busy)
        updateTransportUi()
    }

    private fun buildTransportDock(root: LinearLayout) {
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(9), dp(14), dp(8))
            background = roundedGradient(cardAlt, cardColor, dp(18), cyan)
            elevation = dp(10).toFloat()
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titleBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        addText(titleBlock, "NOW PLAYING", 9, cyan, true)
        transportTitle = addText(titleBlock, t("Плеер готов к запуску", "Player ready"), 12, white, true)
        header.addView(titleBlock, LinearLayout.LayoutParams(0, -2, 1f))
        playPauseButton = actionButton("▶", true) { togglePlayback() }.apply { textSize = 17f }
        header.addView(playPauseButton, params(dp(52), dp(42)))
        val stopButton = actionButton("■", false) { stopPlayback(); updateTransportUi() }.apply { textSize = 15f }
        header.addView(stopButton, params(dp(48), dp(42)).apply { marginStart = dp(7) })
        dock.addView(header)

        transportSeek = SeekBar(this).apply {
            max = 1000
            progress = 0
            progressTintList = ColorStateList.valueOf(cyan)
            progressBackgroundTintList = ColorStateList.valueOf(0xff315165.toInt())
            thumbTintList = ColorStateList.valueOf(white)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        isSeeking = true
                        val duration = try { player?.duration ?: 0 } catch (_: Exception) { 0 }
                        transportTime.text = "${formatTime(duration * progress / 1000)} / ${formatTime(duration)}"
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) { isSeeking = true }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val duration = try { player?.duration ?: 0 } catch (_: Exception) { 0 }
                    if (playerPrepared && duration > 0) {
                        try { player?.seekTo((duration.toLong() * (seekBar?.progress ?: 0) / 1000L).toInt()) } catch (_: Exception) { }
                    }
                    isSeeking = false
                }
            })
        }
        dock.addView(transportSeek, params().apply { topMargin = dp(-3) })
        transportTime = addText(dock, "0:00 / 0:00", 9, muted)
        root.addView(dock, params().apply { leftMargin = dp(12); rightMargin = dp(12); bottomMargin = dp(8) })
        updateTransportUi()
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = roundedGradient(cardColor, Color.rgb(9, 20, 33), dp(18), Color.rgb(35, 73, 94))
        elevation = dp(2).toFloat()
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius.toFloat()
        stroke?.let { setStroke(dp(1), it) }
    }

    private fun roundedGradient(top: Int, bottom: Int, radius: Int, stroke: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(top, bottom)).apply {
            cornerRadius = radius.toFloat()
            setStroke(dp(1), stroke)
        }

    private fun addBadge(parent: LinearLayout, label: String, color: Int) {
        val badge = TextView(this).apply {
            text = "◈  $label"
            textSize = 9f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(color)
            letterSpacing = 0.06f
            setPadding(0, 0, 0, dp(7))
        }
        parent.addView(badge, params())
    }

    private fun addText(parent: LinearLayout, value: String, size: Int, color: Int, bold: Boolean = false): TextView {
        val view = TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
            isSingleLine = false
        }
        parent.addView(view, params())
        return view
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun actionButton(value: String, primary: Boolean, action: () -> Unit): Button = Button(this).apply {
        text = value
        setAllCaps(false)
        textSize = 11.5f
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setTextColor(if (primary) Color.rgb(4, 20, 28) else white)
        background = if (primary) roundedGradient(cyan, Color.rgb(35, 174, 178), dp(13), cyan)
            else rounded(Color.rgb(17, 42, 59), dp(13), Color.rgb(48, 89, 112))
        setPadding(dp(8), dp(3), dp(8), dp(3))
        minHeight = dp(40)
        stateListAnimator = null
        setOnClickListener { if (!busy || value == "▶" || value == "■") action() }
    }

    private fun addSlider(
        parent: LinearLayout,
        title: String,
        minimum: Int,
        maximum: Int,
        initial: Int,
        changed: (Int) -> Unit,
        valueText: (Int) -> String
    ) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val label = TextView(this).apply { text = title; textSize = 11f; setTextColor(white) }
        val value = TextView(this).apply { text = valueText(initial); textSize = 10f; setTextColor(cyan); gravity = Gravity.END }
        row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(value, params(dp(84), -2))
        parent.addView(row, params())
        val seek = SeekBar(this).apply {
            max = maximum - minimum
            progress = (initial - minimum).coerceIn(0, max)
            progressTintList = ColorStateList.valueOf(violet)
            progressBackgroundTintList = ColorStateList.valueOf(0xff2b465b.toInt())
            thumbTintList = ColorStateList.valueOf(cyan)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + minimum
                value.text = valueText(v)
                changed(v)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        parent.addView(seek, params())
        addSpace(parent, 4)
    }

    private fun fmt(value: Float) = String.format(Locale.US, "%.2f", value)

    private fun applyPreset(name: String) {
        when (name) {
            "slowed" -> { speed = 0.78f; pitch = -2f; reverb = 0.24f; roomSize = 0.56f; eqGains.fill(0f) }
            "nightcore" -> { speed = 1.25f; pitch = 4f; reverb = 0.06f; roomSize = 0.30f; eqGains.fill(0f); eqGains[3] = 1f; eqGains[4] = 1f }
            "dreamy" -> { speed = 0.88f; pitch = -1f; reverb = 0.48f; roomSize = 0.76f; eqGains.fill(0f) }
            "dark" -> { speed = 0.82f; pitch = -3f; reverb = 0.20f; roomSize = 0.60f; eqGains.fill(0f); eqGains[0] = 2f; eqGains[4] = -2f }
            "hyper" -> { speed = 1.38f; pitch = 5f; reverb = 0.03f; roomSize = 0.24f; eqGains.fill(0f); eqGains[3] = 2f; eqGains[4] = 2f }
        }
        buildUi()
        statusText.text = t("Пресет применён. Можно точно настроить регуляторы.", "Preset applied. Fine-tune the controls as needed.")
    }

    private data class LibraryTrack(val uri: Uri, val title: String, val artist: String, val duration: Long) {
        fun label(): String {
            val minutes = duration / 60000
            val seconds = (duration / 1000) % 60
            return "$title\n$artist  ·  $minutes:${seconds.toString().padStart(2, '0')}"
        }
    }

    private fun audioPermission(): String = if (Build.VERSION.SDK_INT >= 33) "android.permission.READ_MEDIA_AUDIO" else "android.permission.READ_EXTERNAL_STORAGE"

    private fun openMusicLibrary() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(audioPermission()) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(audioPermission()), REQUEST_LIBRARY_PERMISSION)
            return
        }
        showMusicLibrary()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LIBRARY_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) showMusicLibrary()
            else showMessage(t("Без доступа к аудиофайлам медиатека не сможет показать песни.", "Allow audio access to display your music library."))
        }
    }

    private fun loadLibraryTracks(): List<LibraryTrack> {
        val tracks = mutableListOf<LibraryTrack>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: t("Без названия", "Untitled")
                val artist = cursor.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: t("Неизвестный исполнитель", "Unknown artist")
                tracks.add(LibraryTrack(Uri.withAppendedPath(collection, id.toString()), title, artist, cursor.getLong(durationCol)))
            }
        }
        return tracks
    }

    private fun showMusicLibrary() {
        try {
            val tracks = loadLibraryTracks()
            if (tracks.isEmpty()) return showMessage(t("В медиатеке пока не найдено музыкальных файлов.", "No music files were found in the media library."))
            val dialogView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(4)) }
            val search = EditText(this).apply {
                hint = t("Поиск по песне или исполнителю", "Search title or artist")
                setSingleLine(true)
                inputType = android.text.InputType.TYPE_CLASS_TEXT
                setTextColor(white)
                setHintTextColor(muted)
            }
            val list = ListView(this)
            dialogView.addView(search, params())
            dialogView.addView(list, LinearLayout.LayoutParams(-1, dp(390)))
            var visibleTracks = tracks
            list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, visibleTracks.map { it.label() })
            val dialog = AlertDialog.Builder(this)
                .setTitle(t("МУЗЫКАЛЬНАЯ БИБЛИОТЕКА", "MUSIC LIBRARY"))
                .setView(dialogView)
                .setNegativeButton(t("Закрыть", "Close"), null)
                .create()
            search.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val query = s?.toString()?.trim()?.lowercase(Locale.ROOT).orEmpty()
                    visibleTracks = tracks.filter { it.title.lowercase(Locale.ROOT).contains(query) || it.artist.lowercase(Locale.ROOT).contains(query) }
                    list.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, visibleTracks.map { it.label() })
                }
                override fun afterTextChanged(s: Editable?) {}
            })
            list.setOnItemClickListener { _, _, position, _ ->
                val track = visibleTracks[position]
                selectedUri = track.uri
                sourceName = track.title
                sourceDetails = "${track.artist}  ·  ${formatTime(track.duration.toInt())}"
                trackTitle.text = sourceName
                trackDetails.text = sourceDetails
                transportTitle.text = sourceName
                statusText.text = t("Трек выбран из медиатеки.", "Track selected from your library.")
                dialog.dismiss()
            }
            dialog.show()
        } catch (error: Exception) {
            showMessage(t("Не удалось открыть медиатеку: ${error.message}", "Could not open music library: ${error.message}"))
        }
    }

    private fun pickAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_PICK_AUDIO)
    }

    @Deprecated("Legacy activity result is used to keep this project dependency-light.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) {
            if (requestCode == REQUEST_CREATE_EXPORT) { pendingExport?.delete(); pendingExport = null }
            return
        }
        val uri = data.data!!
        when (requestCode) {
            REQUEST_PICK_AUDIO -> {
                selectedUri = uri
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                val meta = readAudioInfo(uri)
                sourceName = meta.first
                sourceDetails = meta.second
                trackTitle.text = sourceName
                trackDetails.text = sourceDetails
                transportTitle.text = sourceName
                statusText.text = t("Файл выбран. Можно включить оригинал или создать ремикс.", "Track loaded. Play the original or render a remix.")
            }
            REQUEST_CREATE_EXPORT -> {
                val source = pendingExport
                pendingExport = null
                if (source != null) {
                    try {
                        contentResolver.openOutputStream(uri, "w")?.use { output -> source.inputStream().use { input -> input.copyTo(output) } }
                            ?: error("The selected destination could not be opened.")
                        statusText.text = t("Экспорт завершён — WAV сохранён.", "Export complete — WAV saved.")
                    } catch (error: Exception) {
                        statusText.text = t("Ошибка сохранения: ${error.message}", "Save failed: ${error.message}")
                    } finally { source.delete() }
                }
            }
        }
    }

    private fun readAudioInfo(uri: Uri): Pair<String, String> {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: t("Аудиофайл", "Audio file")
        var size: Long? = null
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            if (cursor?.moveToFirst() == true) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        } catch (_: Exception) { } finally { cursor?.close() }
        var durationText = ""
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            if (durationMs != null) durationText = " · ${formatTime(durationMs.toInt())}"
        } catch (_: Exception) { } finally { try { retriever.release() } catch (_: Exception) { } }
        val sizeText = size?.let { " · ${String.format(Locale.US, "%.1f MB", it / (1024f * 1024f))}" } ?: ""
        return name to (t("Аудиофайл", "Audio file") + durationText + sizeText)
    }

    private fun previewOriginal() {
        val uri = selectedUri ?: return showMessage(t("Сначала выбери аудиофайл.", "Choose an audio file first."))
        stopPlayback()
        try {
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { media ->
                    playerPrepared = true
                    media.start()
                    transportTitle.text = sourceName.ifBlank { t("Оригинал", "Original") }
                    statusText.text = t("Воспроизводится оригинал.", "Playing original audio.")
                    updateTransportUi()
                    handler.removeCallbacks(progressTicker)
                    handler.post(progressTicker)
                }
                setOnCompletionListener { finishPlayback(t("Оригинал завершён.", "Original playback finished.")) }
                setOnErrorListener { _, what, extra -> showMessage("Playback error ($what/$extra)"); finishPlayback(t("Ошибка воспроизведения.", "Playback error.")); true }
                prepareAsync()
            }
            transportTitle.text = t("Подготовка оригинала…", "Preparing original…")
            statusText.text = t("Подготовка оригинала…", "Preparing original…")
        } catch (error: Exception) {
            finishPlayback(t("Не удалось воспроизвести файл.", "Could not play the file."))
            showMessage(t("Ошибка воспроизведения: ${error.message}", "Playback error: ${error.message}"))
        }
    }

    private fun togglePlayback() {
        val current = player
        if (current == null || !playerPrepared) {
            showMessage(t("Сначала запусти оригинал или создай предпрослушивание.", "Start the original or render a preview first."))
            return
        }
        try {
            if (current.isPlaying) {
                current.pause()
                statusText.text = t("Пауза.", "Paused.")
            } else {
                current.start()
                statusText.text = t("Воспроизведение продолжается.", "Playback resumed.")
                handler.removeCallbacks(progressTicker)
                handler.post(progressTicker)
            }
            updateTransportUi()
        } catch (error: Exception) {
            showMessage(t("Не удалось изменить воспроизведение: ${error.message}", "Playback control failed: ${error.message}"))
        }
    }

    private fun stopPlayback() {
        handler.removeCallbacks(progressTicker)
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        playerPrepared = false
        isSeeking = false
        previewCacheFile?.delete()
        previewCacheFile = null
        if (::transportSeek.isInitialized) transportSeek.progress = 0
        if (::transportTime.isInitialized) transportTime.text = "0:00 / 0:00"
        updateTransportUi()
    }

    private fun finishPlayback(message: String) {
        handler.removeCallbacks(progressTicker)
        try { player?.release() } catch (_: Exception) { }
        player = null
        playerPrepared = false
        previewCacheFile?.delete()
        previewCacheFile = null
        if (::transportSeek.isInitialized) transportSeek.progress = 0
        if (::transportTime.isInitialized) transportTime.text = "0:00 / 0:00"
        if (::statusText.isInitialized) statusText.text = message
        updateTransportUi()
    }

    private fun updateTransportUi() {
        if (!::playPauseButton.isInitialized) return
        val active = player != null && playerPrepared
        val playing = try { player?.isPlaying == true } catch (_: Exception) { false }
        playPauseButton.text = if (playing) "Ⅱ" else "▶"
        playPauseButton.isEnabled = active
        playPauseButton.alpha = if (active) 1f else 0.55f
        if (!active && ::transportTitle.isInitialized && transportTitle.text.isNullOrBlank()) {
            transportTitle.text = t("Плеер готов к запуску", "Player ready")
        }
    }

    private fun formatTime(milliseconds: Int): String {
        val seconds = (milliseconds.coerceAtLeast(0) / 1000)
        return "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
    }

    private fun render(export: Boolean) {
        val uri = selectedUri ?: return showMessage(t("Сначала выбери аудиофайл.", "Choose an audio file first."))
        if (busy) return
        stopPlayback()
        val settings = DspSettings(
            speed = speed,
            pitchSemitones = pitch,
            reverbWet = reverb,
            roomSize = roomSize,
            eqGainsDb = eqGains.copyOf(),
            limiterEnabled = limiterEnabled
        )
        busy = true
        updateBusyState(true)
        statusText.text = t("Анализ и обработка аудио…", "Analyzing and processing audio…")
        thread(name = "SandAudioRender") {
            var outputFile: File? = null
            try {
                val decoded = AudioProcessor.decode(this, uri)
                val processed = DspEngine.process(decoded.samples, decoded.sampleRate, decoded.channels, settings)
                val completedFile = File(cacheDir, "sand_remix_${System.currentTimeMillis()}.wav")
                outputFile = completedFile
                AudioProcessor.writeWav(completedFile, processed, decoded.sampleRate, decoded.channels)
                runOnUiThread {
                    busy = false
                    updateBusyState(false)
                    if (export) {
                        pendingExport = completedFile
                        statusText.text = t("Рендер готов. Выбери место сохранения.", "Render ready. Choose where to save it.")
                        val create = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "audio/wav"
                            putExtra(Intent.EXTRA_TITLE, safeFileName(sourceName) + "_remix.wav")
                        }
                        startActivityForResult(create, REQUEST_CREATE_EXPORT)
                    } else {
                        statusText.text = t("Ремикс готов. Запускаю предпрослушивание.", "Remix ready. Starting preview.")
                        playRenderedFile(completedFile)
                    }
                }
            } catch (error: Exception) {
                outputFile?.delete()
                runOnUiThread {
                    busy = false
                    updateBusyState(false)
                    statusText.text = t("Ошибка обработки: ${error.message}", "Processing error: ${error.message}")
                }
            }
        }
    }

    private fun playRenderedFile(file: File) {
        stopPlayback()
        previewCacheFile = file
        try {
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnPreparedListener { media ->
                    playerPrepared = true
                    media.start()
                    transportTitle.text = t("Обработанный ремикс", "Processed remix")
                    statusText.text = t("Прослушивается обработанный ремикс.", "Playing processed remix.")
                    updateTransportUi()
                    handler.removeCallbacks(progressTicker)
                    handler.post(progressTicker)
                }
                setOnCompletionListener { finishPlayback(t("Предпрослушивание завершено.", "Preview finished.")) }
                setOnErrorListener { _, what, extra ->
                    showMessage("Playback error ($what/$extra)")
                    finishPlayback(t("Ошибка предпрослушивания.", "Preview playback error."))
                    true
                }
                prepareAsync()
            }
            transportTitle.text = t("Загрузка предпрослушивания…", "Loading preview…")
        } catch (error: Exception) {
            finishPlayback(t("Ошибка предпрослушивания: ${error.message}", "Preview error: ${error.message}"))
        }
    }

    private fun safeFileName(value: String): String {
        val noExtension = value.substringBeforeLast('.', value).trim()
        val cleaned = noExtension.replace(Regex("[^A-Za-zА-Яа-я0-9_-]+"), "_").trim('_')
        return cleaned.ifBlank { "SandOfMusic" }.take(48)
    }

    private fun updateBusyState(isBusy: Boolean) {
        if (::progressBar.isInitialized) progressBar.visibility = if (isBusy) View.VISIBLE else View.GONE
        if (::renderButton.isInitialized) { renderButton.isEnabled = !isBusy; renderButton.alpha = if (isBusy) 0.55f else 1f }
        if (::previewButton.isInitialized) { previewButton.isEnabled = !isBusy; previewButton.alpha = if (isBusy) 0.55f else 1f }
        if (::sourcePreviewButton.isInitialized) { sourcePreviewButton.isEnabled = !isBusy; sourcePreviewButton.alpha = if (isBusy) 0.55f else 1f }
    }

    private fun showMessage(message: String) {
        if (::statusText.isInitialized) statusText.text = message
    }

    override fun onDestroy() {
        handler.removeCallbacks(progressTicker)
        stopPlayback()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_PICK_AUDIO = 410
        private const val REQUEST_CREATE_EXPORT = 411
        private const val REQUEST_LIBRARY_PERMISSION = 412
    }
}
