# Sand of Music Reverb 0.4.0 — build status

## Implemented

- Updated futuristic native Android UI.
- Three touch rotary controls for speed, pitch and reverb.
- Fixed bottom in-app transport dock with Play/Pause, Stop, seek bar and time display.
- Refined DSP: windowed-sinc pitch resampling, cosine WSOLA crossfades, softer reverb mix/feedback, appended reverb tail, edge fades and transparent peak guard.
- Retained MediaStore library, file picker, Simple/Pro modes and WAV export.

## Verification completed in this environment

- `DspEngine.kt` compiled with the local Kotlin/JVM compiler.
- DSP smoke test passed: speed/duration, separate pitch/speed, reverb tail length, finite output, peak ceiling and stereo isolation.
- The full Android app has **not yet been built against Android SDK Platform 35 in this environment**. Run the provided GitHub Actions workflow to perform the authoritative Android build.

## Not included

- MP3 encoder/export.
- Separate Android launcher widget or notification media controls; the player dock is fixed inside the app screen.
