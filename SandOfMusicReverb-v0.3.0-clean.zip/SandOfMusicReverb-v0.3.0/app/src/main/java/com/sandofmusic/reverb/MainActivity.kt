package com.sandofmusic.reverb

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.MediaStore
import android.content.pm.PackageManager
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private var selectedUri: Uri? = null
    private var sourceName = ""
    private var sourceDetails = ""
    private var speed = 0.82f
    private var pitch = -2f
    private var reverb = 0.38f
    private var roomSize = 0.62f
    private val eqGains = FloatArray(5)
    private var limiterEnabled = true
    private var proMode = false
    private var english = false
    private var busy = false
    private var player: MediaPlayer? = null
    private var previewCacheFile: File? = null
    private var pendingExport: File? = null

    private lateinit var content: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var trackTitle: TextView
    private lateinit var trackDetails: TextView
    private lateinit var renderButton: Button
    private lateinit var previewButton: Button
    private lateinit var sourcePreviewButton: Button

    private val purple = Color.rgb(178, 133, 255)
    private val backgroundColor = Color.rgb(11, 9, 17)
    private val cardColor = Color.rgb(24, 20, 34)
    private val muted = Color.rgb(160, 151, 177)
    private val white = Color.rgb(246, 242, 252)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val preferences = getSharedPreferences("sand_settings", MODE_PRIVATE)
        english = preferences.getBoolean("english", false)
        proMode = preferences.getBoolean("pro", false)
        window.statusBarColor = backgroundColor
        window.navigationBarColor = backgroundColor
        buildUi()
    }

    private fun t(ru: String, en: String) = if (english) en else ru
    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()
    private fun params(width: Int = ViewGroup.LayoutParams.MATCH_PARENT, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) = LinearLayout.LayoutParams(width, height)

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(backgroundColor)
            clipToPadding = false
            isFillViewport = true
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(30))
        }
        scroll.addView(content)
        setContentView(scroll)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brandBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        addText(brandBlock, "SAND OF MUSIC", 21, white, true)
        addText(brandBlock, "R E V E R B   S T U D I O", 10, purple, true)
        top.addView(brandBlock, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(actionButton(if (english) "РУС" else "EN", false) {
            english = !english
            getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putBoolean("english", english).apply()
            buildUi()
        }, params(dp(66), dp(42)))
        content.addView(top)
        addText(content, t("ПРОСТО СОЗДАВАТЬ. КРАСИВО ЗВУЧАТЬ.", "MAKE IT SIMPLE. MAKE IT SOUND BEAUTIFUL."), 10, muted, true)
        addSpace(content, 20)

        val trackCard = card()
        addText(trackCard, t("ТВОЙ ТРЕК", "YOUR TRACK"), 11, purple, true)
        trackTitle = addText(trackCard, if (sourceName.isBlank()) t("Аудиофайл не выбран", "No audio selected") else sourceName, 17, white, true)
        trackDetails = addText(trackCard, if (sourceDetails.isBlank()) t("Импортируй музыку, чтобы начать", "Import a song to get started") else sourceDetails, 11, muted)
        addSpace(trackCard, 8)
        trackCard.addView(actionButton(t("♫  Открыть медиатеку телефона", "♫  Open phone music library"), true) { openMusicLibrary() }, params())
        trackCard.addView(actionButton(t("＋  Выбрать аудиофайл", "＋  Choose audio file"), false) { pickAudio() }, params())
        content.addView(trackCard)
        addSpace(content, 17)

        addSectionTitle(content, t("БЫСТРЫЙ СТАРТ", "QUICK START"))
        val presetRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presetRow1.addView(actionButton("SLOWED + REVERB", false) { applyPreset("slowed") }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) })
        presetRow1.addView(actionButton("NIGHTCORE", false) { applyPreset("nightcore") }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(5) })
        content.addView(presetRow1)
        val presetRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presetRow2.addView(actionButton(t("DREAMY", "DREAMY"), false) { applyPreset("dreamy") }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
        presetRow2.addView(actionButton(t("DARK", "DARK"), false) { applyPreset("dark") }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
        presetRow2.addView(actionButton(t("HYPER", "HYPER"), false) { applyPreset("hyper") }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) })
        content.addView(presetRow2)
        addSpace(content, 17)

        val modeCard = card()
        addText(modeCard, t("РЕЖИМ РАБОТЫ", "WORKSPACE"), 11, purple, true)
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modes.addView(actionButton(t("ПРОСТОЙ", "SIMPLE"), !proMode) {
            proMode = false
            getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putBoolean("pro", false).apply()
            buildUi()
        }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        modes.addView(actionButton("PRO", proMode) {
            proMode = true
            getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putBoolean("pro", true).apply()
            buildUi()
        }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(5) })
        modeCard.addView(modes)
        content.addView(modeCard)
        addSpace(content, 17)

        val controlCard = card()
        addText(controlCard, t("НАСТРОЙКА ЗВУКА", "SOUND SHAPING"), 11, purple, true)
        addSlider(controlCard, t("Скорость", "Speed"), 50, 160, (speed * 100).roundToInt(), { (it / 100f).also { v -> speed = v } }, { "${fmt(it / 100f)}×" })
        addSlider(controlCard, t("Высота тона", "Pitch"), -12, 12, pitch.roundToInt(), { it.toFloat().also { v -> pitch = v } }, { "${if (it > 0) "+" else ""}$it" })
        addSlider(controlCard, t("Реверберация", "Reverb"), 0, 100, (reverb * 100).roundToInt(), { (it / 100f).also { v -> reverb = v } }, { "$it%" })
        if (proMode) {
            addSlider(controlCard, t("Размер пространства", "Room size"), 0, 100, (roomSize * 100).roundToInt(), { (it / 100f).also { v -> roomSize = v } }, { "$it%" })
            addSpace(controlCard, 8)
            addText(controlCard, t("ПЯТИПОЛОСНЫЙ ЭКВАЛАЙЗЕР", "5-BAND EQUALIZER"), 10, purple, true)
            val frequencies = listOf("80 Hz", "250 Hz", "1 kHz", "4 kHz", "12 kHz")
            frequencies.forEachIndexed { index, name ->
                addSlider(controlCard, name, -9, 9, eqGains[index].roundToInt(), { eqGains[index] = it.toFloat() }, { "${if (it > 0) "+" else ""}$it dB" })
            }
            val limiter = CheckBox(this).apply {
                text = t("Защитный лимитер", "Safety limiter")
                setTextColor(white)
                buttonTintList = ColorStateList.valueOf(purple)
                isChecked = limiterEnabled
                setOnCheckedChangeListener { _, checked -> limiterEnabled = checked }
            }
            controlCard.addView(limiter)
            addText(controlCard, t("Лимитер мягко сдерживает пики громкости и помогает избежать цифрового клиппинга.", "The limiter gently controls peaks and helps prevent digital clipping."), 10, muted)
        }
        content.addView(controlCard)
        addSpace(content, 17)

        val actionsCard = card()
        addText(actionsCard, t("ПРОСЛУШИВАНИЕ И ЭКСПОРТ", "LISTEN & EXPORT"), 11, purple, true)
        sourcePreviewButton = actionButton(t("▶  Оригинал", "▶  Original"), false) { previewOriginal() }
        actionsCard.addView(sourcePreviewButton, params())
        previewButton = actionButton(t("♫  Прослушать обработку", "♫  Preview remix"), false) { render(export = false) }
        actionsCard.addView(previewButton, params())
        renderButton = actionButton(t("↓  Экспортировать WAV", "↓  Export WAV"), true) { render(export = true) }
        actionsCard.addView(renderButton, params())
        val stop = actionButton(t("■  Остановить", "■  Stop playback"), false) { stopPlayback() }
        actionsCard.addView(stop, params())
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.GONE
            indeterminateTintList = ColorStateList.valueOf(purple)
        }
        actionsCard.addView(progressBar, params(-1, dp(4)))
        statusText = addText(actionsCard, t("Готово. Выбери трек или быстрый пресет.", "Ready. Choose a track or a quick preset."), 12, muted)
        content.addView(actionsCard)

        addSpace(content, 18)
        addText(content, "SAND AUDIO ENGINE  •  OFFLINE PROCESSING", 9, muted, true).gravity = Gravity.CENTER
        addText(content, "v0.3.0 · Local library / WAV", 9, muted).gravity = Gravity.CENTER
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14))
        background = rounded(cardColor, dp(18), Color.rgb(53, 43, 70))
        elevation = dp(2).toFloat()
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius.toFloat()
        stroke?.let { setStroke(dp(1), it) }
    }

    private fun addText(parent: LinearLayout, value: String, size: Int, color: Int, bold: Boolean = false): TextView {
        val view = TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(4))
            isSingleLine = false
        }
        parent.addView(view, params())
        return view
    }

    private fun addSectionTitle(parent: LinearLayout, value: String) {
        addText(parent, value, 11, purple, true)
        addSpace(parent, 5)
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun actionButton(value: String, primary: Boolean, action: () -> Unit): Button = Button(this).apply {
        text = value
        setAllCaps(false)
        textSize = 12f
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setTextColor(if (primary) Color.rgb(22, 14, 33) else white)
        background = rounded(if (primary) purple else Color.rgb(46, 37, 60), dp(13), if (primary) null else Color.rgb(74, 59, 94))
        setPadding(dp(8), dp(4), dp(8), dp(4))
        minHeight = dp(40)
        setOnClickListener { if (!busy) action() }
    }

    private fun addSlider(
        parent: LinearLayout,
        title: String,
        minimum: Int,
        maximum: Int,
        initial: Int,
        changed: (Int) -> Unit,
        valueText: (Int) -> String
    ) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val label = TextView(this).apply { text = title; textSize = 12f; setTextColor(white) }
        val value = TextView(this).apply { text = valueText(initial); textSize = 11f; setTextColor(purple); gravity = Gravity.END }
        row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(value, params(dp(90), -2))
        parent.addView(row, params())
        val seek = SeekBar(this).apply {
            max = maximum - minimum
            progress = (initial - minimum).coerceIn(0, max)
            progressTintList = ColorStateList.valueOf(purple)
            thumbTintList = ColorStateList.valueOf(Color.rgb(225, 204, 255))
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + minimum
                value.text = valueText(v)
                changed(v)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        parent.addView(seek, params())
        addSpace(parent, 5)
    }

    private fun fmt(value: Float) = String.format(Locale.US, "%.2f", value)

    private fun applyPreset(name: String) {
        when (name) {
            "slowed" -> { speed = 0.78f; pitch = -2f; reverb = 0.48f; roomSize = 0.64f; eqGains.fill(0f) }
            "nightcore" -> { speed = 1.25f; pitch = 4f; reverb = 0.08f; roomSize = 0.35f; eqGains.fill(0f); eqGains[3] = 1f; eqGains[4] = 1f }
            "dreamy" -> { speed = 0.88f; pitch = -1f; reverb = 0.72f; roomSize = 0.82f; eqGains.fill(0f) }
            "dark" -> { speed = 0.82f; pitch = -3f; reverb = 0.38f; roomSize = 0.70f; eqGains.fill(0f); eqGains[0] = 2f; eqGains[4] = -2f }
            "hyper" -> { speed = 1.38f; pitch = 5.5f; reverb = 0.05f; roomSize = 0.28f; eqGains.fill(0f); eqGains[3] = 2f; eqGains[4] = 2f }
        }
        buildUi()
        statusText.text = t("Пресет применён. Настройки можно изменить вручную.", "Preset applied. You can fine-tune every setting.")
    }

    private data class LibraryTrack(val uri: Uri, val title: String, val artist: String, val duration: Long) {
        fun label(): String {
            val minutes = duration / 60000
            val seconds = (duration / 1000) % 60
            return "$title\n$artist  ·  $minutes:${seconds.toString().padStart(2, '0')}"
        }
    }

    private fun audioPermission(): String = if (Build.VERSION.SDK_INT >= 33) "android.permission.READ_MEDIA_AUDIO" else "android.permission.READ_EXTERNAL_STORAGE"

    private fun openMusicLibrary() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(audioPermission()) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(audioPermission()), REQUEST_LIBRARY_PERMISSION)
            return
        }
        showMusicLibrary()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LIBRARY_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) showMusicLibrary()
            else showMessage(t("Без доступа к аудиофайлам медиатека не сможет показать песни.", "Allow audio access to display your music library."))
        }
    }

    private fun loadLibraryTracks(): List<LibraryTrack> {
        val tracks = mutableListOf<LibraryTrack>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: t("Без названия", "Untitled")
                val artist = cursor.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: t("Неизвестный исполнитель", "Unknown artist")
                val duration = cursor.getLong(durationCol)
                tracks.add(LibraryTrack(Uri.withAppendedPath(collection, id.toString()), title, artist, duration))
            }
        }
        return tracks
    }

    private fun showMusicLibrary() {
        try {
            val tracks = loadLibraryTracks()
            if (tracks.isEmpty()) {
                showMessage(t("В медиатеке пока не найдено музыкальных файлов.", "No music files were found in the media library."))
                return
            }
            val dialogView = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(8), dp(18), dp(4))
            }
            val search = EditText(this).apply {
                hint = t("Поиск по песне или исполнителю", "Search title or artist")
                singleLine = true
                inputType = android.text.InputType.TYPE_CLASS_TEXT
            }
            val list = ListView(this)
            dialogView.addView(search, params())
            dialogView.addView(list, LinearLayout.LayoutParams(-1, dp(390)))
            var visibleTracks = tracks
            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, visibleTracks.map { it.label() })
            list.adapter = adapter
            val dialog = AlertDialog.Builder(this)
                .setTitle(t("МУЗЫКАЛЬНАЯ БИБЛИОТЕКА", "MUSIC LIBRARY"))
                .setView(dialogView)
                .setNegativeButton(t("Закрыть", "Close"), null)
                .create()
            search.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val query = s?.toString()?.trim()?.lowercase(Locale.ROOT).orEmpty()
                    visibleTracks = tracks.filter { it.title.lowercase(Locale.ROOT).contains(query) || it.artist.lowercase(Locale.ROOT).contains(query) }
                    list.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, visibleTracks.map { it.label() })
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
            list.setOnItemClickListener { _, _, position, _ ->
                val track = visibleTracks[position]
                selectedUri = track.uri
                sourceName = track.title
                sourceDetails = "${track.artist}  ·  ${track.duration / 60000}:${((track.duration / 1000) % 60).toString().padStart(2, '0')}"
                trackTitle.text = sourceName
                trackDetails.text = sourceDetails
                statusText.text = t("Трек выбран из медиатеки.", "Track selected from your library.")
                dialog.dismiss()
            }
            dialog.show()
        } catch (error: Exception) {
            showMessage(t("Не удалось открыть медиатеку: ${error.message}", "Could not open music library: ${error.message}"))
        }
    }

    private fun pickAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_PICK_AUDIO)
    }

    @Deprecated("Legacy activity result is used to keep the project dependency-free.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) {
            if (requestCode == REQUEST_CREATE_EXPORT) {
                pendingExport?.delete()
                pendingExport = null
            }
            return
        }
        val uri = data.data!!
        when (requestCode) {
            REQUEST_PICK_AUDIO -> {
                selectedUri = uri
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                val meta = readAudioInfo(uri)
                sourceName = meta.first
                sourceDetails = meta.second
                trackTitle.text = sourceName
                trackDetails.text = sourceDetails
                statusText.text = t("Файл выбран. Можно прослушать оригинал или создать ремикс.", "Track loaded. Preview the original or create a remix.")
            }
            REQUEST_CREATE_EXPORT -> {
                val source = pendingExport
                pendingExport = null
                if (source != null) {
                    try {
                        contentResolver.openOutputStream(uri, "w")?.use { output -> source.inputStream().use { input -> input.copyTo(output) } }
                            ?: error("The selected destination could not be opened.")
                        statusText.text = t("Экспорт завершён — WAV сохранён.", "Export complete — WAV saved.")
                    } catch (error: Exception) {
                        statusText.text = t("Ошибка сохранения: ${error.message}", "Save failed: ${error.message}")
                    } finally {
                        source.delete()
                    }
                }
            }
        }
    }

    private fun readAudioInfo(uri: Uri): Pair<String, String> {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: t("Аудиофайл", "Audio file")
        var size: Long? = null
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            if (cursor?.moveToFirst() == true) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        } catch (_: Exception) { } finally { cursor?.close() }
        var durationText = ""
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            if (durationMs != null) {
                val seconds = durationMs / 1000
                durationText = " · ${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
            }
        } catch (_: Exception) { } finally { try { retriever.release() } catch (_: Exception) { } }
        val sizeText = size?.let { " · ${String.format(Locale.US, "%.1f MB", it / (1024f * 1024f))}" } ?: ""
        return name to (t("Аудиофайл", "Audio file") + durationText + sizeText)
    }

    private fun previewOriginal() {
        val uri = selectedUri ?: return showMessage(t("Сначала выбери аудиофайл.", "Choose an audio file first."))
        stopPlayback()
        try {
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { it.start(); statusText.text = t("Воспроизводится оригинал.", "Playing original audio.") }
                setOnCompletionListener { statusText.text = t("Воспроизведение завершено.", "Playback finished.") }
                setOnErrorListener { _, what, extra -> statusText.text = "Playback error ($what/$extra)"; true }
                prepareAsync()
            }
            statusText.text = t("Подготовка оригинала…", "Preparing original…")
        } catch (error: Exception) {
            showMessage(t("Не удалось воспроизвести файл: ${error.message}", "Could not play the file: ${error.message}"))
        }
    }

    private fun stopPlayback() {
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        previewCacheFile?.delete()
        previewCacheFile = null
    }

    private fun render(export: Boolean) {
        val uri = selectedUri ?: return showMessage(t("Сначала выбери аудиофайл.", "Choose an audio file first."))
        if (busy) return
        stopPlayback()
        val settings = DspSettings(
            speed = speed,
            pitchSemitones = pitch,
            reverbWet = reverb,
            roomSize = roomSize,
            eqGainsDb = eqGains.copyOf(),
            limiterEnabled = limiterEnabled
        )
        busy = true
        updateBusyState(true)
        statusText.text = t("Анализ и обработка аудио…", "Analyzing and processing audio…")
        thread(name = "SandAudioRender") {
            var outputFile: File? = null
            try {
                val decoded = AudioProcessor.decode(this, uri)
                val processed = DspEngine.process(decoded.samples, decoded.sampleRate, decoded.channels, settings)
                val completedFile = File(cacheDir, "sand_remix_${System.currentTimeMillis()}.wav")
                outputFile = completedFile
                AudioProcessor.writeWav(completedFile, processed, decoded.sampleRate, decoded.channels)
                runOnUiThread {
                    busy = false
                    updateBusyState(false)
                    if (export) {
                        pendingExport = completedFile
                        statusText.text = t("Рендер готов. Выбери место сохранения.", "Render ready. Choose where to save it.")
                        val create = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "audio/wav"
                            putExtra(Intent.EXTRA_TITLE, safeFileName(sourceName) + "_remix.wav")
                        }
                        startActivityForResult(create, REQUEST_CREATE_EXPORT)
                    } else {
                        statusText.text = t("Ремикс готов. Запускаю предпрослушивание.", "Remix ready. Starting preview.")
                        playRenderedFile(completedFile)
                    }
                }
            } catch (error: Exception) {
                outputFile?.delete()
                runOnUiThread {
                    busy = false
                    updateBusyState(false)
                    statusText.text = t("Ошибка обработки: ${error.message}", "Processing error: ${error.message}")
                }
            }
        }
    }

    private fun playRenderedFile(file: File) {
        stopPlayback()
        previewCacheFile = file
        try {
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnPreparedListener { it.start(); statusText.text = t("Прослушивается обработанный ремикс.", "Playing processed remix.") }
                setOnCompletionListener {
                    statusText.text = t("Предпрослушивание завершено.", "Preview finished.")
                    previewCacheFile?.delete()
                    previewCacheFile = null
                }
                setOnErrorListener { _, what, extra -> statusText.text = "Playback error ($what/$extra)"; true }
                prepareAsync()
            }
        } catch (error: Exception) {
            previewCacheFile?.delete()
            previewCacheFile = null
            statusText.text = t("Ошибка предпрослушивания: ${error.message}", "Preview error: ${error.message}")
        }
    }

    private fun safeFileName(value: String): String {
        val noExtension = value.substringBeforeLast('.', value).trim()
        val cleaned = noExtension.replace(Regex("[^A-Za-zА-Яа-я0-9_-]+"), "_").trim('_')
        return cleaned.ifBlank { "SandOfMusic" }.take(48)
    }

    private fun updateBusyState(isBusy: Boolean) {
        progressBar.visibility = if (isBusy) View.VISIBLE else View.GONE
        renderButton.isEnabled = !isBusy
        previewButton.isEnabled = !isBusy
        sourcePreviewButton.isEnabled = !isBusy
        renderButton.alpha = if (isBusy) 0.55f else 1f
        previewButton.alpha = if (isBusy) 0.55f else 1f
        sourcePreviewButton.alpha = if (isBusy) 0.55f else 1f
    }

    private fun showMessage(message: String) {
        if (::statusText.isInitialized) statusText.text = message
    }

    override fun onDestroy() {
        stopPlayback()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_PICK_AUDIO = 410
        private const val REQUEST_CREATE_EXPORT = 411
        private const val REQUEST_LIBRARY_PERMISSION = 412
    }
}
