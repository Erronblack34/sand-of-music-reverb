# Sand of Music Reverb v0.3.0

Android audio editor for offline Slowed + Reverb and Nightcore processing.

## v0.3.0 changes
- Added an on-device music library using Android MediaStore.
- Search tracks by title or artist and select a track with one tap.
- Added runtime permission handling for Android 13+ (`READ_MEDIA_AUDIO`) and older Android versions (`READ_EXTERNAL_STORAGE`).
- Existing document picker remains available as a fallback.
- Existing WAV export and DSP pipeline are retained.

## Export status
This build still exports WAV/PCM 16-bit. MP3 encoding and bitrate selection (128/192/320 kbps) are **not included yet**; they require a bundled/verified MP3 encoder. The app does not disguise WAV data as MP3.

## Build
Run `./build_debug_apk.sh` with Android SDK and Gradle 8.9 installed, or use the GitHub Actions workflow supplied alongside this archive.
