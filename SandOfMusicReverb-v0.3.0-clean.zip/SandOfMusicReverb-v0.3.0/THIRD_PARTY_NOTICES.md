# Third-party notices

## Android LAME encoder

This project uses `com.github.axet:lame:1.0.9`, which wraps the LAME MP3 encoder for Android, and its `com.github.axet:liblame:3.100` native dependency.

- Project: https://gitlab.com/axet/android-lame
- LAME project: https://lame.sourceforge.io/
- The Android wrapper is published under LGPL-3.0.
- The bundled `liblame` native component is published under LGPL-2.1.

Please consult the upstream project distributions for the complete license texts and source corresponding to the exact binary versions used.
