# Sand of Music Reverb 0.7.0 — Ultimate Music Edition

Offline Android audio editor and player. The project keeps the existing FFmpeg-based render pipeline and adds Media3 background playback, genre starting presets, a category-based media library, Favorites / My Playlist, and an offline language selector.

## v0.7.0 features

- Local import and rendering pipeline retained from 0.6.5: audio files and video containers with audio tracks, WAV and MP3 export, slowed, pitch, reverb, five-band EQ and peak protection.
- Ten genre starting presets: Hip-Hop/Rap, Rock, Jazz, Afrobeats, Pop, R&B/Soul, EDM/House, Phonk/Trap, Reggae/Dub and Lo-Fi/Chill.
- Creative presets: Slowed + Reverb, Nightcore, Dream, Dark, Hyper, Daycore, Vaporwave and Ambient.
- AndroidX Media3 ExoPlayer in a `MediaSessionService`. When a library queue is playing, Android's system media notification can provide previous, play/pause and next controls, along with track metadata and artwork where available.
- Library categories: Tracks, Albums, Artists, Folders, Playlists (one local "My Playlist") and Favorites. Long-press a track to toggle Favorites or My Playlist.
- Offline language selector: Russian, English, Japanese, Simplified Chinese, Turkish, Ukrainian, Belarusian and Uzbek. Core labels/navigation have translations; less common dynamic messages safely fall back to English for non-Russian languages.
- Background rendering remains handled by WorkManager; playback is handled separately by Media3.

Genre presets are conservative starting points, not automatic genre recognition or mastering targets. Users can fine-tune the controls after applying a preset. System media notification layout is controlled by Android and the device manufacturer.

## Build

Project folder: `SandOfMusicReverb-v0.7.0`

- Android Gradle Plugin 8.13.2
- Gradle 8.13
- Kotlin Gradle Plugin 2.2.21
- JDK 17
- compileSdk 36; targetSdk 34; minSdk 26

Run `gradle --no-daemon --stacktrace assembleDebug` from this directory, or use the repository workflow `.github/workflows/build-apk.yml` after uploading `SandOfMusicReverb-v0.7.0.zip` to the repository root.

## Verification note

The ZIP archive, manifest XML, workflow YAML, language catalog and standalone DSP Kotlin sources were checked in the packaging workspace. The workspace does not have an Android SDK or Gradle distribution available, so the complete Android APK build has not been run here. Confirm the full build in GitHub Actions before installing the APK.
