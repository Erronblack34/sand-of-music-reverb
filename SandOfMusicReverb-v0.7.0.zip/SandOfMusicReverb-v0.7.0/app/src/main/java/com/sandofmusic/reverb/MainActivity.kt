package com.sandofmusic.reverb

import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import android.app.AlertDialog
import android.content.Intent
import android.content.ComponentName
import android.content.res.ColorStateList
import android.database.Cursor
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.content.pm.PackageManager
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.Executor
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.lifecycle.Observer
import androidx.lifecycle.LiveData
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) showMusicLibrary()
        else showMessage(t("Без доступа к аудиофайлам медиатека не сможет показать песни.", "Allow audio access to display your music library."))
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Notifications are optional; background rendering continues without them. */ }

    private var selectedUri: Uri? = null
    private var sourceName = ""
    private var sourceDetails = ""
    private var speed = 0.82f
    private var pitch = -2f
    private var reverb = 0.24f
    private var roomSize = 0.52f
    private val eqGains = FloatArray(5)
    private var limiterEnabled = true
    private var proMode = false
    private var languageCode = "ru"
    private var english = false
    private var busy = false
    private var activeWorkId: UUID? = null
    private var activeWorkObserver: Observer<WorkInfo?>? = null
    private var activeWorkLiveData: LiveData<WorkInfo?>? = null
    private var activeWorkAction: String = AudioRenderWorker.ACTION_RENDER
    private var activeWorkSourceName: String = "SandOfMusic"
    private var activeWorkProgress = 0
    private var activeWorkStage = ""
    private var workCompletionHandled = false
    private val albumArtExecutor = Executors.newFixedThreadPool(2)
    private val albumArtCache = object : LruCache<Long, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }
    private var player: MediaPlayer? = null
    private var mediaController: MediaController? = null
    private var controllerFuture: com.google.common.util.concurrent.ListenableFuture<MediaController>? = null
    private var playbackListener: Player.Listener? = null
    private var pendingLibraryQueue: List<LibraryTrack>? = null
    private var pendingLibraryQueueStart = 0
    private var playerPrepared = false
    private var previewCacheFile: File? = null
    private var pendingExport: File? = null
    private var isSeeking = false

    private lateinit var content: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var cancelWorkButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var trackTitle: TextView
    private lateinit var trackDetails: TextView
    private lateinit var renderButton: Button
    private lateinit var mp3ExportButton: Button
    private lateinit var previewButton: Button
    private lateinit var sourcePreviewButton: Button
    private lateinit var playPauseButton: Button
    private lateinit var transportTitle: TextView
    private lateinit var transportTime: TextView
    private lateinit var transportSeek: SeekBar

    private val backgroundColor = Color.rgb(5, 12, 22)
    private val cardColor = Color.rgb(13, 27, 42)
    private val cardAlt = Color.rgb(17, 37, 53)
    private val cyan = Color.rgb(53, 224, 210)
    private val violet = Color.rgb(177, 113, 255)
    private val muted = Color.rgb(132, 161, 181)
    private val white = Color.rgb(233, 246, 255)
    private val handler = Handler(Looper.getMainLooper())

    private val progressTicker = object : Runnable {
        override fun run() {
            val controller = mediaController
            if (controller != null && controller.mediaItemCount > 0) {
                try {
                    val duration = controller.duration.takeIf { it > 0 && it != C.TIME_UNSET } ?: 0L
                    val position = controller.currentPosition.coerceAtLeast(0L)
                    if (!isSeeking && duration > 0L) transportSeek.progress = ((position * 1000L) / duration).toInt().coerceIn(0, 1000)
                    transportTime.text = "${formatTime(position.toInt())} / ${formatTime(duration.toInt())}"
                    handler.postDelayed(this, 350L)
                } catch (_: IllegalStateException) { updateTransportUi() }
            } else {
                val current = player
                if (current != null && playerPrepared) {
                    try {
                        val duration = current.duration.coerceAtLeast(1)
                        val position = current.currentPosition.coerceAtLeast(0)
                        if (!isSeeking) transportSeek.progress = ((position.toLong() * 1000L) / duration).toInt().coerceIn(0, 1000)
                        transportTime.text = "${formatTime(position)} / ${formatTime(duration)}"
                        handler.postDelayed(this, 250L)
                    } catch (_: IllegalStateException) { updateTransportUi() }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val preferences = getSharedPreferences("sand_settings", MODE_PRIVATE)
        languageCode = preferences.getString("language", if (preferences.getBoolean("english", false)) "en" else "ru") ?: "ru"
        if (LanguageCatalog.languages.none { it.code == languageCode }) languageCode = "ru"
        english = languageCode != "ru"
        proMode = preferences.getBoolean("pro", false)
        window.statusBarColor = backgroundColor
        window.navigationBarColor = backgroundColor
        window.decorView.systemUiVisibility = 0
        activeWorkId = preferences.getString("active_work_id", null)?.let { runCatching { UUID.fromString(it) }.getOrNull() }
        activeWorkAction = preferences.getString("active_work_action", AudioRenderWorker.ACTION_RENDER) ?: AudioRenderWorker.ACTION_RENDER
        activeWorkSourceName = preferences.getString("active_work_source", "SandOfMusic") ?: "SandOfMusic"
        activeWorkAction = preferences.getString("pending_export_action", activeWorkAction) ?: activeWorkAction
        activeWorkSourceName = preferences.getString("pending_export_name", activeWorkSourceName) ?: activeWorkSourceName
        pendingExport = preferences.getString("pending_export_path", null)?.let { File(it).takeIf(File::exists) }
        buildUi()
        connectToPlaybackService()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch("android.permission.POST_NOTIFICATIONS")
        }
        activeWorkId?.let { observeWork(it) }
        if (activeWorkId == null && pendingExport != null) {
            handler.post { pendingExport?.let { launchExportSaveDialog(it, activeWorkSourceName, activeWorkAction) } }
        }
    }

    private fun t(ru: String, en: String) = LanguageCatalog.translate(languageCode, ru, en)

    private fun showLanguagePicker() {
        val labels = LanguageCatalog.languages.map { "${it.nativeName}  (${it.code.uppercase(Locale.ROOT)})" }.toTypedArray()
        val selected = LanguageCatalog.languages.indexOfFirst { it.code == languageCode }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(t("ЯЗЫК ПРИЛОЖЕНИЯ", "APP LANGUAGE"))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                languageCode = LanguageCatalog.languages[which].code
                english = languageCode != "ru"
                getSharedPreferences("sand_settings", MODE_PRIVATE).edit()
                    .putString("language", languageCode)
                    .putBoolean("english", english)
                    .apply()
                dialog.dismiss()
                buildUi()
                updateTransportUi()
            }
            .setNegativeButton(t("Закрыть", "Close"), null)
            .show()
    }

    private fun connectToPlaybackService() {
        if (mediaController != null || controllerFuture != null) return
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            if (isFinishing || isDestroyed) return@addListener
            try {
                val controller = future.get()
                mediaController = controller
                val listener = object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        runOnUiThread {
                            updateTransportUi()
                            if (isPlaying) {
                                handler.removeCallbacks(progressTicker)
                                handler.post(progressTicker)
                            } else handler.removeCallbacks(progressTicker)
                        }
                    }

                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        runOnUiThread {
                            val title = mediaItem?.mediaMetadata?.title?.toString().orEmpty()
                            if (title.isNotBlank() && ::transportTitle.isInitialized) transportTitle.text = title
                            updateTransportUi()
                        }
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        runOnUiThread { updateTransportUi() }
                    }
                }
                playbackListener = listener
                controller.addListener(listener)
                updateTransportUi()
                pendingLibraryQueue?.let { queue ->
                    val start = pendingLibraryQueueStart
                    pendingLibraryQueue = null
                    playLibraryQueue(queue, start)
                }
            } catch (error: Exception) {
                controllerFuture = null
                if (::statusText.isInitialized) statusText.text = t("Системный плеер пока недоступен: ${error.message}", "System player is unavailable: ${error.message}")
            }
        }, Executor { command -> command.run() })
    }

    private fun playLibraryQueue(tracks: List<LibraryTrack>, startIndex: Int) {
        if (tracks.isEmpty()) return
        val controller = mediaController
        if (controller == null) {
            pendingLibraryQueue = tracks
            pendingLibraryQueueStart = startIndex.coerceIn(0, tracks.lastIndex)
            connectToPlaybackService()
            showMessage(t("Подключаю системный плеер…", "Connecting to system player…"))
            return
        }
        stopLocalPreviewOnly()
        val items = tracks.map { track ->
            val metadata = MediaMetadata.Builder()
                .setTitle(track.title)
                .setArtist(track.artist)
                .setAlbumTitle(track.album)
                .apply {
                    if (track.albumId > 0L) setArtworkUri(Uri.parse("content://media/external/audio/albumart/${track.albumId}"))
                }
                .build()
            MediaItem.Builder()
                .setMediaId(track.uri.toString())
                .setUri(track.uri)
                .setMediaMetadata(metadata)
                .build()
        }
        try {
            controller.setMediaItems(items, startIndex.coerceIn(0, items.lastIndex), C.TIME_UNSET)
            controller.prepare()
            controller.play()
            transportTitle.text = tracks[startIndex.coerceIn(0, tracks.lastIndex)].title
            handler.removeCallbacks(progressTicker)
            handler.post(progressTicker)
            updateTransportUi()
        } catch (error: Exception) {
            showMessage(t("Не удалось запустить очередь: ${error.message}", "Could not start the playback queue: ${error.message}"))
        }
    }

    private fun stopLocalPreviewOnly() {
        handler.removeCallbacks(progressTicker)
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        playerPrepared = false
        previewCacheFile?.delete()
        previewCacheFile = null
    }

    private fun seekToPrevious() {
        val controller = mediaController
        if (controller != null && controller.mediaItemCount > 0) controller.seekToPreviousMediaItem()
        else if (playerPrepared) player?.seekTo(0)
    }

    private fun seekToNext() {
        val controller = mediaController
        if (controller != null && controller.mediaItemCount > 0) controller.seekToNextMediaItem()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()
    private fun params(width: Int = ViewGroup.LayoutParams.MATCH_PARENT, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) = LinearLayout.LayoutParams(width, height)

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(backgroundColor)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(backgroundColor)
            clipToPadding = false
            isFillViewport = true
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(16), dp(17), dp(22))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        buildTransportDock(root)
        setContentView(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.loki_emblem)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = t("Эмблема приложения", "Application emblem")
        }
        top.addView(actionButton("☰", false) { openMusicLibrary() }, params(dp(42), dp(42)).apply { marginEnd = dp(7) })
        top.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(10) })
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        addText(brand, "SAND / MUSIC", 23, white, true)
        addText(brand, "A U D I O   L A B   •   V 0 7", 10, cyan, true)
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(actionButton("🌐 ${languageCode.uppercase(Locale.ROOT)}", false) { showLanguagePicker() }, params(dp(72), dp(40)))
        content.addView(top)
        addSpace(content, 5)
        addText(content, t("СТУДИЯ ОБРАБОТКИ ЗВУКА", "OFFLINE AUDIO WORKSTATION"), 10, muted, true)
        addText(content, t("Формируй звук. Управляй атмосферой.", "Shape the sound. Control the atmosphere."), 13, cyan)
        addSpace(content, 15)

        val trackCard = card()
        addBadge(trackCard, t("SOURCE INPUT", "SOURCE INPUT"), cyan)
        trackTitle = addText(trackCard, if (sourceName.isBlank()) t("Трек ещё не выбран", "No track selected") else sourceName, 17, white, true)
        trackDetails = addText(trackCard, if (sourceDetails.isBlank()) t("Добавь аудио из медиатеки или файлов", "Add audio from your library or files") else sourceDetails, 11, muted)
        addSpace(trackCard, 9)
        trackCard.addView(actionButton(t("♫  Открыть медиатеку", "♫  Open music library"), true) { openMusicLibrary() }, params())
        trackCard.addView(actionButton(t("＋  Выбрать аудиофайл", "＋  Choose audio file"), false) { pickAudio() }, params().apply { topMargin = dp(7) })
        content.addView(trackCard)
        addSpace(content, 15)

        val presetCard = card()
        addBadge(presetCard, t("SIGNAL PRESETS", "SIGNAL PRESETS"), violet)
        val presetRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presetRow1.addView(actionButton("SLOWED + REVERB", false) { applyPreset("slowed") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        presetRow1.addView(actionButton("NIGHTCORE", false) { applyPreset("nightcore") }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(5) })
        presetCard.addView(presetRow1)
        val presetRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presetRow2.addView(actionButton("DREAM", false) { applyPreset("dreamy") }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
        presetRow2.addView(actionButton("DARK", false) { applyPreset("dark") }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        presetRow2.addView(actionButton("HYPER", false) { applyPreset("hyper") }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4) })
        presetCard.addView(presetRow2, params().apply { topMargin = dp(6) })
        val moodRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        moodRow.addView(actionButton("DAYCORE", false) { applyPreset("daycore") }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(4) })
        moodRow.addView(actionButton("VAPORWAVE", false) { applyPreset("vaporwave") }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        moodRow.addView(actionButton("AMBIENT", false) { applyPreset("ambient") }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(4) })
        presetCard.addView(moodRow, params().apply { topMargin = dp(5) })
        addSpace(presetCard, 9)
        addBadge(presetCard, t("ЖАНРОВЫЕ ПРЕСЕТЫ", "GENRE PRESETS"), violet)
        val genreRows = listOf(
            listOf("HIP-HOP / RAP" to "hiphop", "ROCK" to "rock"),
            listOf("JAZZ" to "jazz", "AFROBEATS" to "afrobeats"),
            listOf("POP" to "pop", "R&B / SOUL" to "rnb"),
            listOf("EDM / HOUSE" to "edm", "PHONK / TRAP" to "phonk"),
            listOf("REGGAE / DUB" to "reggae", "LO-FI / CHILL" to "lofi")
        )
        genreRows.forEach { entries ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            entries.forEachIndexed { index, entry ->
                row.addView(actionButton(t(entry.first, entry.first), false) { applyPreset(entry.second) },
                    LinearLayout.LayoutParams(0, dp(39), 1f).apply { if (index == 0) marginEnd = dp(4) else marginStart = dp(4) })
            }
            presetCard.addView(row, params().apply { topMargin = dp(5) })
        }
        content.addView(presetCard)
        addSpace(content, 15)

        val modeCard = card()
        addBadge(modeCard, t("WORKSPACE MODE", "WORKSPACE MODE"), cyan)
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modes.addView(actionButton(t("ПРОСТОЙ", "ESSENTIAL"), !proMode) {
            proMode = false
            getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putBoolean("pro", false).apply()
            buildUi()
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
        modes.addView(actionButton("PRO LAB", proMode) {
            proMode = true
            getSharedPreferences("sand_settings", MODE_PRIVATE).edit().putBoolean("pro", true).apply()
            buildUi()
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) })
        modeCard.addView(modes)
        content.addView(modeCard)
        addSpace(content, 15)

        val controlCard = card()
        addBadge(controlCard, t("SOUND ENGINE / TOUCH DIALS", "SOUND ENGINE / TOUCH DIALS"), cyan)
        addText(controlCard, t("Коснись шкалы и поверни регулятор по дуге.", "Touch a dial and rotate along its arc."), 10, muted)
        val dialRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val speedDial = RotaryKnobView(this, t("Скорость", "SPEED"), 0.5f, 1.6f, speed, cyan) { "${fmt(it)}×" }
        speedDial.onValueChanged = { speed = it }
        val pitchDial = RotaryKnobView(this, t("Тон", "PITCH"), -12f, 12f, pitch, violet) { "${if (it > 0) "+" else ""}${it.roundToInt()} st" }
        pitchDial.onValueChanged = { pitch = it }
        val reverbDial = RotaryKnobView(this, t("Реверб", "REVERB"), 0f, 0.65f, reverb, cyan) { "${(it * 100).roundToInt()}%" }
        reverbDial.onValueChanged = { reverb = it }
        dialRow.addView(speedDial, LinearLayout.LayoutParams(0, dp(132), 1f))
        dialRow.addView(pitchDial, LinearLayout.LayoutParams(0, dp(132), 1f))
        dialRow.addView(reverbDial, LinearLayout.LayoutParams(0, dp(132), 1f))
        controlCard.addView(dialRow, params())

        if (proMode) {
            addSpace(controlCard, 6)
            addSlider(controlCard, t("Размер комнаты", "Room size"), 0, 100, (roomSize * 100).roundToInt(), { (it / 100f).also { v -> roomSize = v } }, { "$it%" })
            addSpace(controlCard, 4)
            addBadge(controlCard, t("ПЯТИПОЛОСНЫЙ ЭКВАЛАЙЗЕР", "5-BAND EQUALIZER"), violet)
            val frequencies = listOf("80 Hz", "250 Hz", "1 kHz", "4 kHz", "12 kHz")
            frequencies.forEachIndexed { index, name ->
                addSlider(controlCard, name, -6, 6, eqGains[index].roundToInt(), { eqGains[index] = it.toFloat() }, { "${if (it > 0) "+" else ""}$it dB" })
            }
            val limiter = CheckBox(this).apply {
                text = t("Защита пиков", "Peak protection")
                setTextColor(white)
                buttonTintList = ColorStateList.valueOf(cyan)
                isChecked = limiterEnabled
                setOnCheckedChangeListener { _, checked -> limiterEnabled = checked }
            }
            controlCard.addView(limiter)
            addText(controlCard, t("Защита снижает общий уровень только при необходимости, чтобы избежать жёсткого цифрового клиппинга.", "Peak protection lowers overall gain only when needed to avoid hard digital clipping."), 10, muted)
        }
        content.addView(controlCard)
        addSpace(content, 15)

        val actionsCard = card()
        addBadge(actionsCard, t("RENDER / MONITOR", "RENDER / MONITOR"), violet)
        sourcePreviewButton = actionButton(t("▶  Оригинал", "▶  Original"), false) { previewOriginal() }
        actionsCard.addView(sourcePreviewButton, params())
        previewButton = actionButton(t("♫  Создать предпрослушивание", "♫  Render preview"), false) { render(exportFormat = null) }
        actionsCard.addView(previewButton, params().apply { topMargin = dp(7) })
        renderButton = actionButton(t("↓  Экспортировать WAV", "↓  Export WAV"), true) {
            render(exportFormat = MediaPipeline.OutputFormat.WAV)
        }
        actionsCard.addView(renderButton, params().apply { topMargin = dp(7) })
        mp3ExportButton = actionButton(t("♫  Экспортировать MP3", "♫  Export MP3"), false) {
            render(exportFormat = MediaPipeline.OutputFormat.MP3)
        }
        actionsCard.addView(mp3ExportButton, params().apply { topMargin = dp(7) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            isIndeterminate = false
            visibility = View.GONE
            progressTintList = ColorStateList.valueOf(cyan)
            progressBackgroundTintList = ColorStateList.valueOf(0xff294254.toInt())
        }
        actionsCard.addView(progressBar, params(-1, dp(6)).apply { topMargin = dp(10) })
        statusText = addText(actionsCard, t("Готов к работе. Выбери трек или пресет.", "Ready. Select a track or preset."), 11, muted)
        cancelWorkButton = actionButton(t("Остановить обработку", "Cancel processing"), false) {
            activeWorkId?.let { WorkManager.getInstance(applicationContext).cancelWorkById(it) }
        }.apply { visibility = View.GONE }
        actionsCard.addView(cancelWorkButton, params().apply { topMargin = dp(5) })
        content.addView(actionsCard)

        addSpace(content, 17)
        addText(content, "SAND AUDIO ENGINE  •  LOCAL DSP  •  WAV / MP3", 9, muted, true).gravity = Gravity.CENTER
        addText(content, "v0.7.0 · Media Session / Genre Presets / Multilingual Library", 9, muted).gravity = Gravity.CENTER
        updateBusyState(busy)
        updateTransportUi()
        if (activeWorkId != null && busy) updateWorkUi()
    }

    private fun buildTransportDock(root: LinearLayout) {
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(9), dp(14), dp(8))
            background = roundedGradient(cardAlt, cardColor, dp(18), cyan)
            elevation = dp(10).toFloat()
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titleBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        addText(titleBlock, "NOW PLAYING", 9, cyan, true)
        transportTitle = addText(titleBlock, t("Плеер готов к запуску", "Player ready"), 12, white, true)
        header.addView(titleBlock, LinearLayout.LayoutParams(0, -2, 1f))
        val previousButton = actionButton("|◀", false) { seekToPrevious() }.apply { textSize = 12f }
        header.addView(previousButton, params(dp(38), dp(42)).apply { marginEnd = dp(4) })
        playPauseButton = actionButton("▶", true) { togglePlayback() }.apply { textSize = 17f }
        header.addView(playPauseButton, params(dp(48), dp(42)))
        val nextButton = actionButton("▶|", false) { seekToNext() }.apply { textSize = 12f }
        header.addView(nextButton, params(dp(38), dp(42)).apply { marginStart = dp(4) })
        val stopButton = actionButton("■", false) { stopPlayback(); updateTransportUi() }.apply { textSize = 15f }
        header.addView(stopButton, params(dp(48), dp(42)).apply { marginStart = dp(7) })
        dock.addView(header)

        transportSeek = SeekBar(this).apply {
            max = 1000
            progress = 0
            progressTintList = ColorStateList.valueOf(cyan)
            progressBackgroundTintList = ColorStateList.valueOf(0xff315165.toInt())
            thumbTintList = ColorStateList.valueOf(white)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        isSeeking = true
                        val duration = try { mediaController?.duration?.takeIf { it > 0 && it != C.TIME_UNSET }?.toInt() ?: (player?.duration ?: 0) } catch (_: Exception) { 0 }
                        transportTime.text = "${formatTime(duration * progress / 1000)} / ${formatTime(duration)}"
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) { isSeeking = true }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val controller = mediaController
                    val duration = try { controller?.duration?.takeIf { it > 0 && it != C.TIME_UNSET }?.toInt() ?: (player?.duration ?: 0) } catch (_: Exception) { 0 }
                    if (duration > 0) {
                        val target = (duration.toLong() * (seekBar?.progress ?: 0) / 1000L).toLong()
                        try {
                            if (controller != null && controller.mediaItemCount > 0) controller.seekTo(target)
                            else if (playerPrepared) player?.seekTo(target.toInt())
                        } catch (_: Exception) { }
                    }
                    isSeeking = false
                }
            })
        }
        dock.addView(transportSeek, params().apply { topMargin = dp(-3) })
        transportTime = addText(dock, "0:00 / 0:00", 9, muted)
        root.addView(dock, params().apply { leftMargin = dp(12); rightMargin = dp(12); bottomMargin = dp(8) })
        updateTransportUi()
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = roundedGradient(cardColor, Color.rgb(9, 20, 33), dp(18), Color.rgb(35, 73, 94))
        elevation = dp(2).toFloat()
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius.toFloat()
        stroke?.let { setStroke(dp(1), it) }
    }

    private fun roundedGradient(top: Int, bottom: Int, radius: Int, stroke: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(top, bottom)).apply {
            cornerRadius = radius.toFloat()
            setStroke(dp(1), stroke)
        }

    private fun addBadge(parent: LinearLayout, label: String, color: Int) {
        val badge = TextView(this).apply {
            text = "◈  $label"
            textSize = 9f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(color)
            letterSpacing = 0.06f
            setPadding(0, 0, 0, dp(7))
        }
        parent.addView(badge, params())
    }

    private fun addText(parent: LinearLayout, value: String, size: Int, color: Int, bold: Boolean = false): TextView {
        val view = TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
            isSingleLine = false
        }
        parent.addView(view, params())
        return view
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun actionButton(value: String, primary: Boolean, action: () -> Unit): Button = Button(this).apply {
        text = value
        setAllCaps(false)
        textSize = 11.5f
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setTextColor(if (primary) Color.rgb(4, 20, 28) else white)
        background = if (primary) roundedGradient(cyan, Color.rgb(35, 174, 178), dp(13), cyan)
            else rounded(Color.rgb(17, 42, 59), dp(13), Color.rgb(48, 89, 112))
        setPadding(dp(8), dp(3), dp(8), dp(3))
        minHeight = dp(40)
        stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun addSlider(
        parent: LinearLayout,
        title: String,
        minimum: Int,
        maximum: Int,
        initial: Int,
        changed: (Int) -> Unit,
        valueText: (Int) -> String
    ) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val label = TextView(this).apply { text = title; textSize = 11f; setTextColor(white) }
        val value = TextView(this).apply { text = valueText(initial); textSize = 10f; setTextColor(cyan); gravity = Gravity.END }
        row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(value, params(dp(84), -2))
        parent.addView(row, params())
        val seek = SeekBar(this).apply {
            max = maximum - minimum
            progress = (initial - minimum).coerceIn(0, max)
            progressTintList = ColorStateList.valueOf(violet)
            progressBackgroundTintList = ColorStateList.valueOf(0xff2b465b.toInt())
            thumbTintList = ColorStateList.valueOf(cyan)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + minimum
                value.text = valueText(v)
                changed(v)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        parent.addView(seek, params())
        addSpace(parent, 4)
    }

    private fun fmt(value: Float) = String.format(Locale.US, "%.2f", value)

    private fun applyPreset(name: String) {
        when (name) {
            "slowed" -> { speed = 0.78f; pitch = -2f; reverb = 0.24f; roomSize = 0.56f; eqGains.fill(0f) }
            "nightcore" -> { speed = 1.25f; pitch = 4f; reverb = 0.06f; roomSize = 0.30f; eqGains.fill(0f); eqGains[3] = 1f; eqGains[4] = 1f }
            "dreamy" -> { speed = 0.88f; pitch = -1f; reverb = 0.48f; roomSize = 0.76f; eqGains.fill(0f) }
            "dark" -> { speed = 0.82f; pitch = -3f; reverb = 0.20f; roomSize = 0.60f; eqGains.fill(0f); eqGains[0] = 2f; eqGains[4] = -2f }
            "hyper" -> { speed = 1.38f; pitch = 5f; reverb = 0.03f; roomSize = 0.24f; eqGains.fill(0f); eqGains[3] = 2f; eqGains[4] = 2f }
            "daycore" -> { speed = 0.88f; pitch = -1.5f; reverb = 0.14f; roomSize = 0.42f; eqGains.fill(0f); eqGains[0] = 0.8f; eqGains[4] = -0.4f }
            "vaporwave" -> { speed = 0.78f; pitch = -3f; reverb = 0.34f; roomSize = 0.72f; eqGains.fill(0f); eqGains[0] = 1.2f; eqGains[2] = -0.8f; eqGains[4] = -1.2f }
            "ambient" -> { speed = 0.96f; pitch = 0f; reverb = 0.52f; roomSize = 0.88f; eqGains.fill(0f); eqGains[0] = 0.2f; eqGains[1] = 0.4f; eqGains[2] = 0.1f; eqGains[3] = -0.2f; eqGains[4] = -0.6f }
            // Genre presets are conservative starting points, not mastering targets.
            "hiphop" -> { speed = 1f; pitch = 0f; reverb = 0.12f; roomSize = 0.42f; eqGains[0] = 2.6f; eqGains[1] = 1.2f; eqGains[2] = -0.6f; eqGains[3] = 1.0f; eqGains[4] = 0.6f }
            "rock" -> { speed = 1f; pitch = 0f; reverb = 0.16f; roomSize = 0.48f; eqGains[0] = 1.0f; eqGains[1] = -0.4f; eqGains[2] = 1.2f; eqGains[3] = 1.8f; eqGains[4] = 1.0f }
            "jazz" -> { speed = 1f; pitch = 0f; reverb = 0.20f; roomSize = 0.38f; eqGains[0] = 0.8f; eqGains[1] = 0.7f; eqGains[2] = 0.4f; eqGains[3] = 0.2f; eqGains[4] = -0.4f }
            "afrobeats" -> { speed = 1f; pitch = 0f; reverb = 0.13f; roomSize = 0.44f; eqGains[0] = 2.0f; eqGains[1] = 0.8f; eqGains[2] = 0.4f; eqGains[3] = 1.0f; eqGains[4] = 0.7f }
            "pop" -> { speed = 1f; pitch = 0f; reverb = 0.14f; roomSize = 0.45f; eqGains[0] = 0.8f; eqGains[1] = 0.2f; eqGains[2] = 0.5f; eqGains[3] = 0.8f; eqGains[4] = 0.7f }
            "rnb" -> { speed = 0.98f; pitch = 0f; reverb = 0.22f; roomSize = 0.56f; eqGains[0] = 1.8f; eqGains[1] = 0.8f; eqGains[2] = -0.2f; eqGains[3] = 0.5f; eqGains[4] = 0.1f }
            "edm" -> { speed = 1f; pitch = 0f; reverb = 0.12f; roomSize = 0.55f; eqGains[0] = 2.2f; eqGains[1] = 0.6f; eqGains[2] = -0.4f; eqGains[3] = 1.1f; eqGains[4] = 1.2f }
            "phonk" -> { speed = 1f; pitch = 0f; reverb = 0.08f; roomSize = 0.32f; eqGains[0] = 3.2f; eqGains[1] = 1.6f; eqGains[2] = -1.0f; eqGains[3] = 0.8f; eqGains[4] = 0.5f }
            "reggae" -> { speed = 1f; pitch = 0f; reverb = 0.25f; roomSize = 0.62f; eqGains[0] = 1.6f; eqGains[1] = 0.3f; eqGains[2] = 0.2f; eqGains[3] = -0.2f; eqGains[4] = 0.2f }
            "lofi" -> { speed = 0.96f; pitch = 0f; reverb = 0.18f; roomSize = 0.52f; eqGains[0] = 0.8f; eqGains[1] = 0.2f; eqGains[2] = -0.8f; eqGains[3] = -1.2f; eqGains[4] = -2.0f }
        }
        buildUi()
        if (busy) updateWorkUi() else statusText.text = t("Пресет применён. Можно точно настроить регуляторы.", "Preset applied. Fine-tune the controls as needed.")
    }

    private data class LibraryTrack(
        val uri: Uri,
        val title: String,
        val artist: String,
        val album: String,
        val duration: Long,
        val albumId: Long,
        val folder: String = ""
    )

    private fun audioPermission(): String = if (Build.VERSION.SDK_INT >= 33) "android.permission.READ_MEDIA_AUDIO" else "android.permission.READ_EXTERNAL_STORAGE"

    private fun openMusicLibrary() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(audioPermission()) != PackageManager.PERMISSION_GRANTED) {
            audioPermissionLauncher.launch(audioPermission())
            return
        }
        showMusicLibrary()
    }


    private fun loadLibraryTracks(): List<LibraryTrack> {
        val tracks = mutableListOf<LibraryTrack>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: t("Без названия", "Untitled")
                val artist = cursor.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: t("Неизвестный исполнитель", "Unknown artist")
                val album = cursor.getString(albumCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: ""
                @Suppress("DEPRECATION")
                val path = if (dataCol >= 0) cursor.getString(dataCol).orEmpty() else ""
                val folder = path.takeIf { it.isNotBlank() }?.let { File(it).parentFile?.name }.orEmpty()
                tracks.add(
                    LibraryTrack(
                        uri = Uri.withAppendedPath(collection, id.toString()),
                        title = title,
                        artist = artist,
                        album = album,
                        duration = cursor.getLong(durationCol),
                        albumId = cursor.getLong(albumIdCol),
                        folder = folder
                    )
                )
            }
        }
        return tracks
    }

    private inner class LibraryTrackAdapter(private var rows: List<LibraryTrack>) : BaseAdapter() {
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): LibraryTrack = rows[position]
        override fun getItemId(position: Int): Long = rows[position].uri.lastPathSegment?.toLongOrNull() ?: position.toLong()

        fun replace(newRows: List<LibraryTrack>) {
            rows = newRows
            notifyDataSetChanged()
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val track = getItem(position)
            val row: LinearLayout
            val artwork: ImageView
            val title: TextView
            val subtitle: TextView
            val duration: TextView
            if (convertView == null) {
                row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(9), dp(8), dp(10), dp(8))
                    background = roundedGradient(cardAlt, cardColor, dp(14), Color.rgb(39, 74, 94))
                }
                val coverFrame = FrameLayout(this@MainActivity).apply {
                    background = rounded(Color.rgb(25, 54, 72), dp(10), Color.rgb(47, 98, 117))
                }
                artwork = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                coverFrame.addView(artwork, FrameLayout.LayoutParams(-1, -1))
                val glyph = TextView(this@MainActivity).apply {
                    text = "♫"
                    textSize = 22f
                    gravity = Gravity.CENTER
                    setTextColor(cyan)
                    tag = "placeholder"
                }
                coverFrame.addView(glyph, FrameLayout.LayoutParams(-1, -1))
                row.addView(coverFrame, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginEnd = dp(11) })

                val textBlock = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                title = TextView(this@MainActivity).apply {
                    textSize = 13f
                    setTextColor(white)
                    typeface = Typeface.create("sans-serif", Typeface.BOLD)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                subtitle = TextView(this@MainActivity).apply {
                    textSize = 10f
                    setTextColor(muted)
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                textBlock.addView(title)
                textBlock.addView(subtitle)
                row.addView(textBlock, LinearLayout.LayoutParams(0, -2, 1f))
                duration = TextView(this@MainActivity).apply {
                    textSize = 10f
                    setTextColor(cyan)
                    gravity = Gravity.CENTER
                    setPadding(dp(5), 0, 0, 0)
                }
                row.addView(duration, params(dp(48), -2))
                row.tag = TrackHolder(artwork, title, subtitle, duration, glyph)
            } else {
                row = convertView as LinearLayout
                val holder = row.tag as TrackHolder
                artwork = holder.artwork
                title = holder.title
                subtitle = holder.subtitle
                duration = holder.duration
            }
            val holder = row.tag as TrackHolder
            title.text = track.title
            subtitle.text = listOf(track.artist, track.album).filter { it.isNotBlank() }.distinct().joinToString(" · ")
            duration.text = formatTime(track.duration.toInt())
            artwork.tag = track.albumId
            holder.glyph.visibility = View.VISIBLE
            artwork.setImageDrawable(null)
            val cached = albumArtCache.get(track.albumId)
            if (cached != null) {
                artwork.setImageBitmap(cached)
                holder.glyph.visibility = View.GONE
            } else if (track.albumId > 0L) {
                loadAlbumArt(track.albumId, artwork, holder.glyph)
            }
            return row
        }
    }

    private data class TrackHolder(
        val artwork: ImageView,
        val title: TextView,
        val subtitle: TextView,
        val duration: TextView,
        val glyph: TextView
    )

    private fun loadAlbumArt(albumId: Long, target: ImageView, placeholder: TextView) {
        albumArtExecutor.execute {
            try {
                val artUri = Uri.parse("content://media/external/audio/albumart/$albumId")
                val bitmap = contentResolver.openInputStream(artUri)?.use { input ->
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    input.mark(1024)
                    BitmapFactory.decodeStream(input, null, bounds)
                    val scale = if (bounds.outWidth > 256 || bounds.outHeight > 256) 4 else 1
                    val options = BitmapFactory.Options().apply { inSampleSize = scale.coerceAtLeast(1) }
                    contentResolver.openInputStream(artUri)?.use { BitmapFactory.decodeStream(it, null, options) }
                }
                if (bitmap != null) {
                    albumArtCache.put(albumId, bitmap)
                    handler.post {
                        if (target.tag == albumId) {
                            target.setImageBitmap(bitmap)
                            placeholder.visibility = View.GONE
                        }
                    }
                }
            } catch (_: Exception) { }
        }
    }

    private fun showMusicLibrary() {
        val loading = AlertDialog.Builder(this)
            .setTitle(t("МЕДИАТЕКА", "MUSIC LIBRARY"))
            .setMessage(t("Сканирую музыкальную коллекцию…", "Scanning your music collection…"))
            .setNegativeButton(t("Отмена", "Cancel"), null)
            .create()
        loading.show()
        Thread({
            val result = runCatching { loadLibraryTracks() }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                loading.dismiss()
                result.onSuccess { tracks ->
                    if (tracks.isEmpty()) showMessage(t("В медиатеке пока не найдено музыкальных файлов.", "No music files were found in the media library."))
                    else showMusicLibraryDialog(tracks)
                }.onFailure { error ->
                    showMessage(t("Не удалось открыть медиатеку: ${error.message}", "Could not open music library: ${error.message}"))
                }
            }
        }, "SandLibraryScan").start()
    }

    private fun showMusicLibraryDialog(allTracks: List<LibraryTrack>) {
        try {
            val dialogView = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(10), dp(14), dp(8))
                setBackgroundColor(backgroundColor)
            }
            val heading = TextView(this).apply {
                text = t("ТВОЯ МУЗЫКАЛЬНАЯ КОЛЛЕКЦИЯ", "YOUR MUSIC COLLECTION")
                textSize = 10f
                letterSpacing = 0.08f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(cyan)
                setPadding(0, 0, 0, dp(7))
            }
            dialogView.addView(heading)

            var section = "tracks"
            var scopedRows: List<LibraryTrack>? = null
            var sortByArtist = false
            var displayedRows: List<LibraryTrack> = allTracks
            val tabs = listOf(
                "tracks" to t("ТРЕКИ", "TRACKS"),
                "albums" to t("АЛЬБОМЫ", "ALBUMS"),
                "artists" to t("ИСПОЛНИТЕЛИ", "ARTISTS"),
                "folders" to t("ПАПКИ", "FOLDERS"),
                "playlists" to t("ПЛЕЙЛИСТЫ", "PLAYLISTS"),
                "favorites" to t("ИЗБРАННОЕ", "FAVORITES")
            )
            val tabScroller = android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
            }
            val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            tabScroller.addView(tabRow)
            dialogView.addView(tabScroller, params().apply { bottomMargin = dp(8) })

            val search = EditText(this).apply {
                hint = t("Найди трек, исполнителя или альбом…", "Search track, artist or album…")
                setSingleLine(true)
                inputType = android.text.InputType.TYPE_CLASS_TEXT
                setTextColor(white)
                setHintTextColor(muted)
                textSize = 13f
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = rounded(cardAlt, dp(12), Color.rgb(44, 83, 104))
            }
            dialogView.addView(search, params().apply { bottomMargin = dp(7) })

            val toolbar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val countLabel = TextView(this).apply { textSize = 10f; setTextColor(muted) }
            toolbar.addView(countLabel, LinearLayout.LayoutParams(0, -2, 1f))
            val sortButton = actionButton(t("А–Я  Название", "A–Z  Title"), false) { }
            toolbar.addView(sortButton, params(dp(130), dp(36)))
            dialogView.addView(toolbar)

            val list = ListView(this).apply {
                divider = null
                dividerHeight = dp(6)
                cacheColorHint = Color.TRANSPARENT
                setSelector(android.R.color.transparent)
                setPadding(0, dp(8), 0, dp(4))
                clipToPadding = false
            }
            dialogView.addView(list, LinearLayout.LayoutParams(-1, dp(430)))
            val adapter = LibraryTrackAdapter(emptyList())
            list.adapter = adapter

            fun idOf(track: LibraryTrack): String = track.uri.lastPathSegment ?: track.uri.toString()
            fun savedIds(key: String): MutableSet<String> = getSharedPreferences("sand_library", MODE_PRIVATE)
                .getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
            lateinit var applyFilter: () -> Unit

            fun updateTabs() {
                tabRow.removeAllViews()
                tabs.forEach { (key, label) ->
                    tabRow.addView(actionButton(label, section == key) {
                        section = key
                        scopedRows = null
                        search.setText("")
                        updateTabs()
                        applyFilter()
                    }, LinearLayout.LayoutParams(-2, dp(36)).apply { marginEnd = dp(5) })
                }
            }

            fun rowsForSection(): List<LibraryTrack> {
                if (scopedRows != null) return scopedRows.orEmpty()
                return when (section) {
                    "albums" -> allTracks.groupBy { it.album.ifBlank { t("Без альбома", "Unknown album") } }
                        .toSortedMap(String.CASE_INSENSITIVE_ORDER)
                        .map { (name, members) -> members.first().copy(title = name, artist = "${members.size} ${t("треков", "tracks")}", album = name, duration = members.sumOf { it.duration }) }
                    "artists" -> allTracks.groupBy { it.artist.ifBlank { t("Неизвестный исполнитель", "Unknown artist") } }
                        .toSortedMap(String.CASE_INSENSITIVE_ORDER)
                        .map { (name, members) -> members.first().copy(title = name, artist = "${members.size} ${t("треков", "tracks")}", album = "", duration = members.sumOf { it.duration }) }
                    "folders" -> allTracks.groupBy { it.folder.ifBlank { t("Неизвестная папка", "Unknown folder") } }
                        .toSortedMap(String.CASE_INSENSITIVE_ORDER)
                        .map { (name, members) -> members.first().copy(title = name, artist = "${members.size} ${t("треков", "tracks")}", album = "", folder = name, duration = members.sumOf { it.duration }) }
                    "favorites" -> {
                        val ids = savedIds("favorite_ids")
                        allTracks.filter { idOf(it) in ids }
                    }
                    "playlists" -> {
                        val ids = savedIds("playlist_ids")
                        allTracks.filter { idOf(it) in ids }
                    }
                    else -> allTracks
                }
            }

            applyFilter = {
                val query = search.text?.toString()?.trim()?.lowercase(Locale.ROOT).orEmpty()
                var filtered = rowsForSection().filter {
                    it.title.lowercase(Locale.ROOT).contains(query) ||
                        it.artist.lowercase(Locale.ROOT).contains(query) ||
                        it.album.lowercase(Locale.ROOT).contains(query) ||
                        it.folder.lowercase(Locale.ROOT).contains(query)
                }
                filtered = if (sortByArtist) {
                    filtered.sortedWith(compareBy<LibraryTrack> { it.artist.lowercase(Locale.ROOT) }.thenBy { it.title.lowercase(Locale.ROOT) })
                } else filtered.sortedBy { it.title.lowercase(Locale.ROOT) }
                displayedRows = filtered
                adapter.replace(filtered)
                countLabel.text = when (section) {
                    "albums" -> t("${filtered.size} альбомов", "${filtered.size} albums")
                    "artists" -> t("${filtered.size} исполнителей", "${filtered.size} artists")
                    "folders" -> t("${filtered.size} папок", "${filtered.size} folders")
                    "favorites" -> t("${filtered.size} избранных треков", "${filtered.size} favorite tracks")
                    "playlists" -> t("${filtered.size} треков в плейлисте", "${filtered.size} playlist tracks")
                    else -> t("${filtered.size} треков", "${filtered.size} tracks")
                }
                sortButton.text = if (sortByArtist) t("А–Я  Исполнитель", "A–Z  Artist") else t("А–Я  Название", "A–Z  Title")
            }

            updateTabs()
            sortButton.setOnClickListener { sortByArtist = !sortByArtist; applyFilter() }
            search.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { applyFilter() }
                override fun afterTextChanged(s: Editable?) {}
            })
            applyFilter()

            val dialog = AlertDialog.Builder(this)
                .setTitle(t("МЕДИАТЕКА", "MUSIC LIBRARY"))
                .setView(dialogView)
                .setNegativeButton(t("Закрыть", "Close"), null)
                .create()
            dialog.setOnShowListener {
                dialog.window?.setBackgroundDrawable(rounded(backgroundColor, dp(20), Color.rgb(50, 94, 116)))
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(cyan)
            }
            list.setOnItemClickListener { _, _, position, _ ->
                val track = displayedRows.getOrNull(position) ?: return@setOnItemClickListener
                if (scopedRows == null && section in listOf("albums", "artists", "folders")) {
                    scopedRows = when (section) {
                        "albums" -> allTracks.filter { it.album.ifBlank { t("Без альбома", "Unknown album") } == track.title }
                        "artists" -> allTracks.filter { it.artist == track.title }
                        else -> allTracks.filter { it.folder.ifBlank { t("Неизвестная папка", "Unknown folder") } == track.title }
                    }
                    section = "tracks"
                    updateTabs()
                    applyFilter()
                    return@setOnItemClickListener
                }
                selectedUri = track.uri
                sourceName = track.title
                sourceDetails = listOf(track.artist, track.album.ifBlank { null }, formatTime(track.duration.toInt()))
                    .filterNotNull().joinToString(" · ")
                trackTitle.text = sourceName
                trackDetails.text = sourceDetails
                transportTitle.text = sourceName
                val queue = displayedRows.toList()
                playLibraryQueue(queue, position)
                if (busy) updateWorkUi() else statusText.text = t("Воспроизведение из медиатеки.", "Playing from your library.")
                dialog.dismiss()
            }
            list.setOnItemLongClickListener { _, _, position, _ ->
                if (section in listOf("albums", "artists", "folders")) return@setOnItemLongClickListener true
                val track = displayedRows.getOrNull(position) ?: return@setOnItemLongClickListener true
                AlertDialog.Builder(this)
                    .setTitle(track.title)
                    .setItems(arrayOf(t("Добавить / убрать из избранного", "Toggle favorite"), t("Добавить / убрать в плейлисте", "Toggle My Playlist"))) { _, which ->
                        val key = if (which == 0) "favorite_ids" else "playlist_ids"
                        val ids = savedIds(key)
                        val id = idOf(track)
                        if (!ids.add(id)) ids.remove(id)
                        getSharedPreferences("sand_library", MODE_PRIVATE).edit().putStringSet(key, ids).apply()
                        applyFilter()
                        showMessage(if (which == 0) t("Избранное обновлено.", "Favorites updated.") else t("Мой плейлист обновлён.", "My Playlist updated."))
                    }
                    .show()
                true
            }
            dialog.show()
        } catch (error: Exception) {
            showMessage(t("Не удалось открыть медиатеку: ${error.message}", "Could not open music library: ${error.message}"))
        }
    }

    private fun pickAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            // Accept audio-only files and video containers that may contain an audio track.
            // FFmpeg probes the actual container/codec, so the filename extension is not trusted.
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*", "application/octet-stream"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_PICK_AUDIO)
    }

    @Deprecated("Legacy activity result is used to keep this project dependency-light.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) {
            if (requestCode == REQUEST_CREATE_EXPORT && pendingExport?.exists() == true) {
                val savedFile = pendingExport!!
                statusText.text = t("Результат сохранён внутри приложения. Его можно выгрузить позже.", "The render is kept inside the app. You can export it later.")
                AlertDialog.Builder(this)
                    .setTitle(t("Файл пока не сохранён", "File not exported yet"))
                    .setMessage(t("Готовый файл не удалён. Повторить выбор места сохранения?", "The completed render was not deleted. Choose a save location now?"))
                    .setPositiveButton(t("Повторить", "Retry")) { _, _ ->
                        launchExportSaveDialog(savedFile, activeWorkSourceName, activeWorkAction)
                    }
                    .setNegativeButton(t("Позже", "Later"), null)
                    .show()
            }
            return
        }
        val uri = data.data!!
        when (requestCode) {
            REQUEST_PICK_AUDIO -> {
                selectedUri = uri
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                val fallbackName = uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
                    ?: t("Читаю медиафайл…", "Reading media file…")
                sourceName = fallbackName
                sourceDetails = t("Читаю сведения о файле…", "Reading file information…")
                trackTitle.text = sourceName
                trackDetails.text = sourceDetails
                transportTitle.text = sourceName
                if (busy) updateWorkUi() else statusText.text = t("Файл выбран. Читаю метаданные…", "File selected. Reading metadata…")
                Thread({
                    val meta = readAudioInfo(uri)
                    runOnUiThread {
                        if (isFinishing || isDestroyed || selectedUri != uri) return@runOnUiThread
                        sourceName = meta.first
                        sourceDetails = meta.second
                        trackTitle.text = sourceName
                        trackDetails.text = sourceDetails
                        transportTitle.text = sourceName
                        if (!busy) statusText.text = t("Файл выбран. Можно включить оригинал или создать ремикс.", "Track loaded. Play the original or render a remix.")
                    }
                }, "SandReadMetadata").start()
            }
            REQUEST_CREATE_EXPORT -> {
                val source = pendingExport
                if (source != null) saveExportInBackground(source, uri)
            }
        }
    }

    private fun saveExportInBackground(source: File, destination: Uri) {
        statusText.text = t("Сохраняю файл…", "Saving file…")
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = true
        Thread({
            var saveError: String? = null
            try {
                val output = applicationContext.contentResolver.openOutputStream(destination, "w")
                    ?: throw IllegalStateException("Не удалось открыть выбранное место сохранения.")
                output.buffered().use { target ->
                    source.inputStream().buffered().use { input ->
                        val buffer = ByteArray(1024 * 1024)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            target.write(buffer, 0, count)
                        }
                        target.flush()
                    }
                }
            } catch (error: Exception) {
                saveError = error.message ?: error.javaClass.simpleName
            }

            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                progressBar.isIndeterminate = false
                progressBar.visibility = View.GONE
                if (saveError == null) {
                    source.delete()
                    pendingExport = null
                    getSharedPreferences("sand_settings", MODE_PRIVATE).edit()
                        .remove("pending_export_path")
                        .remove("pending_export_action")
                        .remove("pending_export_name")
                        .apply()
                    val formatLabel = if (source.extension.equals("mp3", true)) "MP3" else "WAV"
                    statusText.text = t("Экспорт завершён — $formatLabel сохранён.", "Export complete — $formatLabel saved.")
                } else {
                    pendingExport = source
                    statusText.text = t("Не удалось сохранить файл: $saveError. Результат оставлен в приложении.", "Could not save file: $saveError. The render is kept in the app.")
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(t("Сохранение не завершено", "Save did not finish"))
                        .setMessage(t("Готовый файл не удалён. Выбери другое место и повтори сохранение.", "The completed render was not deleted. Choose another destination and retry."))
                        .setPositiveButton(t("Повторить", "Retry")) { _, _ ->
                            launchExportSaveDialog(source, activeWorkSourceName, activeWorkAction)
                        }
                        .setNegativeButton(t("Позже", "Later"), null)
                        .show()
                }
            }
        }, "SandExportSave").start()
    }

    private fun readAudioInfo(uri: Uri): Pair<String, String> {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: t("Медиафайл", "Media file")
        var size: Long? = null
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            if (cursor?.moveToFirst() == true) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        } catch (_: Exception) { } finally { cursor?.close() }
        var durationText = ""
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            if (durationMs != null) durationText = " · ${formatTime(durationMs.toInt())}"
        } catch (_: Exception) { } finally { try { retriever.release() } catch (_: Exception) { } }
        val sizeText = size?.let { " · ${String.format(Locale.US, "%.1f MB", it / (1024f * 1024f))}" } ?: ""
        return name to (t("Медиафайл", "Media file") + durationText + sizeText)
    }

    private fun previewOriginal() {
        startAudioWork(AudioRenderWorker.ACTION_ORIGINAL)
    }

    private fun togglePlayback() {
        val controller = mediaController
        if (controller != null && controller.mediaItemCount > 0) {
            if (controller.isPlaying) {
                controller.pause()
                statusText.text = t("Пауза.", "Paused.")
            } else {
                controller.play()
                statusText.text = t("Воспроизведение продолжается.", "Playback resumed.")
                handler.removeCallbacks(progressTicker)
                handler.post(progressTicker)
            }
            updateTransportUi()
            return
        }
        val current = player
        if (current == null || !playerPrepared) {
            showMessage(t("Сначала запусти оригинал или создай предпрослушивание.", "Start the original or render a preview first."))
            return
        }
        try {
            if (current.isPlaying) {
                current.pause()
                statusText.text = t("Пауза.", "Paused.")
            } else {
                current.start()
                statusText.text = t("Воспроизведение продолжается.", "Playback resumed.")
                handler.removeCallbacks(progressTicker)
                handler.post(progressTicker)
            }
            updateTransportUi()
        } catch (error: Exception) {
            showMessage(t("Не удалось изменить воспроизведение: ${error.message}", "Playback control failed: ${error.message}"))
        }
    }

    private fun stopPlayback() {
        handler.removeCallbacks(progressTicker)
        try { mediaController?.pause(); mediaController?.clearMediaItems() } catch (_: Exception) { }
        stopLocalPreviewOnly()
        isSeeking = false
        if (::transportSeek.isInitialized) transportSeek.progress = 0
        if (::transportTime.isInitialized) transportTime.text = "0:00 / 0:00"
        updateTransportUi()
    }

    private fun finishPlayback(message: String) {
        handler.removeCallbacks(progressTicker)
        try { player?.release() } catch (_: Exception) { }
        player = null
        playerPrepared = false
        previewCacheFile?.delete()
        previewCacheFile = null
        if (::transportSeek.isInitialized) transportSeek.progress = 0
        if (::transportTime.isInitialized) transportTime.text = "0:00 / 0:00"
        if (::statusText.isInitialized) statusText.text = message
        updateTransportUi()
    }

    private fun updateTransportUi() {
        if (!::playPauseButton.isInitialized) return
        val controller = mediaController
        val serviceActive = controller != null && controller.mediaItemCount > 0
        val localActive = player != null && playerPrepared
        val active = serviceActive || localActive
        val playing = if (serviceActive) controller?.isPlaying == true else try { player?.isPlaying == true } catch (_: Exception) { false }
        playPauseButton.text = if (playing) "Ⅱ" else "▶"
        playPauseButton.isEnabled = active
        playPauseButton.alpha = if (active) 1f else 0.55f
        if (!active && ::transportTitle.isInitialized && transportTitle.text.isNullOrBlank()) {
            transportTitle.text = t("Плеер готов к запуску", "Player ready")
        }
    }

    private fun formatTime(milliseconds: Int): String {
        val seconds = (milliseconds.coerceAtLeast(0) / 1000)
        return "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
    }

    private fun render(exportFormat: MediaPipeline.OutputFormat?) {
        val action = when (exportFormat) {
            MediaPipeline.OutputFormat.WAV -> AudioRenderWorker.ACTION_RENDER
            MediaPipeline.OutputFormat.MP3 -> AudioRenderWorker.ACTION_MP3
            null -> AudioRenderWorker.ACTION_PREVIEW
        }
        startAudioWork(action)
    }

    private fun startAudioWork(action: String) {
        val uri = selectedUri ?: return showMessage(t("Сначала выбери аудиофайл.", "Choose a media file first."))
        if (busy) return
        stopPlayback()

        activeWorkAction = action
        activeWorkSourceName = sourceName.ifBlank { "SandOfMusic" }
        activeWorkProgress = 0
        activeWorkStage = t("Подготовка задачи…", "Preparing task…")
        workCompletionHandled = false

        val dataBuilder = androidx.work.Data.Builder()
            .putString(AudioRenderWorker.KEY_ACTION, action)
            .putString(AudioRenderWorker.KEY_URI, uri.toString())
            .putString(AudioRenderWorker.KEY_SOURCE_NAME, activeWorkSourceName)
            .putFloat(AudioRenderWorker.KEY_SPEED, speed)
            .putFloat(AudioRenderWorker.KEY_PITCH, pitch)
            .putFloat(AudioRenderWorker.KEY_REVERB, reverb)
            .putFloat(AudioRenderWorker.KEY_ROOM, roomSize)
            .putString(AudioRenderWorker.KEY_EQ, eqGains.joinToString(",") { it.toString() })
            .putBoolean(AudioRenderWorker.KEY_LIMITER, limiterEnabled)
            .putBoolean(AudioRenderWorker.KEY_ENGLISH, english)
            .putString(AudioRenderWorker.KEY_LANGUAGE, languageCode)

        val request = OneTimeWorkRequestBuilder<AudioRenderWorker>()
            .setInputData(dataBuilder.build())
            .addTag("sand-audio-render")
            .build()

        activeWorkId = request.id
        getSharedPreferences("sand_settings", MODE_PRIVATE).edit()
            .putString("active_work_id", request.id.toString())
            .putString("active_work_action", action)
            .putString("active_work_source", activeWorkSourceName)
            .apply()

        updateBusyState(true)
        updateWorkUi()
        WorkManager.getInstance(applicationContext).enqueueUniqueWork(
            UNIQUE_WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            request
        )
        observeWork(request.id)
    }

    private fun observeWork(id: UUID) {
        val manager = WorkManager.getInstance(applicationContext)
        activeWorkObserver?.let { observer -> activeWorkLiveData?.removeObserver(observer) }
        val liveData = manager.getWorkInfoByIdLiveData(id)
        val observer = Observer<WorkInfo?> { info ->
            if (info != null && activeWorkId == info.id) onWorkInfoChanged(info)
        }
        activeWorkLiveData = liveData
        activeWorkObserver = observer
        liveData.observe(this, observer)
    }

    private fun onWorkInfoChanged(info: WorkInfo) {
        activeWorkProgress = info.progress.getInt(AudioRenderWorker.KEY_PROGRESS, activeWorkProgress)
        activeWorkStage = info.progress.getString(AudioRenderWorker.KEY_STAGE)
            ?: when (info.state) {
                WorkInfo.State.ENQUEUED -> t("Задача в очереди…", "Task queued…")
                WorkInfo.State.BLOCKED -> t("Ожидание…", "Waiting…")
                WorkInfo.State.RUNNING -> t("Обработка аудио…", "Processing audio…")
                else -> activeWorkStage
            }
        if (!info.state.isFinished) {
            updateBusyState(true)
            updateWorkUi()
        } else {
            handleFinishedWork(info)
        }
    }

    private fun updateWorkUi() {
        if (!::statusText.isInitialized || !::progressBar.isInitialized) return
        progressBar.isIndeterminate = false
        progressBar.progress = activeWorkProgress.coerceIn(0, 100)
        progressBar.visibility = View.VISIBLE
        statusText.text = "${localizedWorkStage(activeWorkStage.ifBlank { t("Обработка аудио…", "Processing audio…") })}  ${activeWorkProgress.coerceIn(0, 100)}%"
        if (::cancelWorkButton.isInitialized) cancelWorkButton.visibility = View.VISIBLE
    }

    private fun localizedWorkStage(value: String): String {
        if (languageCode == "ru") return value
        val pairs = listOf(
            "Копирование исходного файла" to "Copying source file",
            "Файл подготовлен" to "Source file ready",
            "Обработка аудио" to "Processing audio",
            "Финальная проверка файла" to "Final file check",
            "Подготовка файла" to "Preparing file…",
            "Подготовка задачи" to "Preparing task…",
            "Готово" to "Complete"
        )
        val pair = pairs.firstOrNull { value.startsWith(it.first) } ?: return value
        return LanguageCatalog.translate(languageCode, pair.first, pair.second) + value.removePrefix(pair.first)
    }

    private fun handleFinishedWork(info: WorkInfo) {
        if (workCompletionHandled) return
        workCompletionHandled = true
        val action = info.outputData.getString(AudioRenderWorker.KEY_ACTION) ?: activeWorkAction
        val name = info.outputData.getString(AudioRenderWorker.KEY_SOURCE_NAME) ?: activeWorkSourceName
        val outputPath = info.outputData.getString(AudioRenderWorker.KEY_OUTPUT_FILE)
        val error = info.outputData.getString(AudioRenderWorker.KEY_ERROR)
        val outputFile = outputPath?.let(::File)

        activeWorkObserver?.let { activeWorkLiveData?.removeObserver(it) }
        activeWorkLiveData = null
        activeWorkObserver = null
        activeWorkId = null
        getSharedPreferences("sand_settings", MODE_PRIVATE).edit()
            .remove("active_work_id")
            .remove("active_work_action")
            .remove("active_work_source")
            .apply()
        updateBusyState(false)
        progressBar.progress = if (info.state == WorkInfo.State.SUCCEEDED) 100 else 0

        when (info.state) {
            WorkInfo.State.SUCCEEDED -> {
                if (outputFile == null || !outputFile.exists() || outputFile.length() == 0L) {
                    statusText.text = t("Задача завершилась, но файл результата не найден.", "The task finished, but its output file is missing.")
                    return
                }
                activeWorkProgress = 100
                when (action) {
                    AudioRenderWorker.ACTION_RENDER, AudioRenderWorker.ACTION_MP3 -> {
                        pendingExport = outputFile
                        getSharedPreferences("sand_settings", MODE_PRIVATE).edit()
                            .putString("pending_export_path", outputFile.absolutePath)
                            .putString("pending_export_action", action)
                            .putString("pending_export_name", name)
                            .apply()
                        launchExportSaveDialog(outputFile, name, action)
                    }
                    AudioRenderWorker.ACTION_ORIGINAL -> {
                        statusText.text = t("Оригинальная дорожка готова.", "Original audio is ready.")
                        playRenderedFile(outputFile, isOriginal = true)
                    }
                    else -> {
                        statusText.text = t("Предпрослушивание готово.", "Preview is ready.")
                        playRenderedFile(outputFile)
                    }
                }
            }
            WorkInfo.State.CANCELLED -> {
                statusText.text = t("Обработка остановлена. Исходный файл не изменён.", "Processing cancelled. The source file was not changed.")
                outputFile?.delete()
            }
            WorkInfo.State.FAILED -> {
                statusText.text = t("Ошибка обработки: ${error ?: "неизвестная ошибка"}", "Processing failed: ${error ?: "unknown error"}")
                outputFile?.delete()
            }
            else -> statusText.text = t("Обработка завершилась.", "Processing finished.")
        }
    }

    private fun launchExportSaveDialog(file: File, originalName: String, action: String) {
        val mp3 = action == AudioRenderWorker.ACTION_MP3
        val extension = if (mp3) "mp3" else "wav"
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = if (mp3) "audio/mpeg" else "audio/wav"
            putExtra(Intent.EXTRA_TITLE, safeFileName(originalName) + "_remix.$extension")
        }
        statusText.text = t("Обработка завершена. Выбери место сохранения ${extension.uppercase(Locale.ROOT)}.", "Processing complete. Choose where to save the ${extension.uppercase(Locale.ROOT)} file.")
        startActivityForResult(intent, REQUEST_CREATE_EXPORT)
    }

    private fun playRenderedFile(file: File, isOriginal: Boolean = false) {
        stopPlayback()
        previewCacheFile = file
        try {
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnPreparedListener { media ->
                    playerPrepared = true
                    media.start()
                    transportTitle.text = if (isOriginal) t("Оригинал", "Original") else t("Обработанный ремикс", "Processed remix")
                    statusText.text = if (isOriginal) t("Прослушивается оригинальная дорожка.", "Playing the original audio track.") else t("Прослушивается обработанный ремикс.", "Playing processed remix.")
                    updateTransportUi()
                    handler.removeCallbacks(progressTicker)
                    handler.post(progressTicker)
                }
                setOnCompletionListener { finishPlayback(t("Предпрослушивание завершено.", "Preview finished.")) }
                setOnErrorListener { _, what, extra ->
                    showMessage("Playback error ($what/$extra)")
                    finishPlayback(t("Ошибка предпрослушивания.", "Preview playback error."))
                    true
                }
                prepareAsync()
            }
            transportTitle.text = t("Загрузка предпрослушивания…", "Loading preview…")
        } catch (error: Exception) {
            finishPlayback(t("Ошибка предпрослушивания: ${error.message}", "Preview error: ${error.message}"))
        }
    }

    private fun safeFileName(value: String): String {
        val noExtension = value.substringBeforeLast('.', value).trim()
        val cleaned = noExtension.replace(Regex("[^A-Za-zА-Яа-я0-9_-]+"), "_").trim('_')
        return cleaned.ifBlank { "SandOfMusic" }.take(48)
    }

    private fun updateBusyState(isBusy: Boolean) {
        busy = isBusy
        if (::progressBar.isInitialized) progressBar.visibility = if (isBusy) View.VISIBLE else View.GONE
        if (::renderButton.isInitialized) { renderButton.isEnabled = !isBusy; renderButton.alpha = if (isBusy) 0.55f else 1f }
        if (::mp3ExportButton.isInitialized) { mp3ExportButton.isEnabled = !isBusy; mp3ExportButton.alpha = if (isBusy) 0.55f else 1f }
        if (::previewButton.isInitialized) { previewButton.isEnabled = !isBusy; previewButton.alpha = if (isBusy) 0.55f else 1f }
        if (::sourcePreviewButton.isInitialized) { sourcePreviewButton.isEnabled = !isBusy; sourcePreviewButton.alpha = if (isBusy) 0.55f else 1f }
        if (::cancelWorkButton.isInitialized) cancelWorkButton.visibility = if (isBusy) View.VISIBLE else View.GONE
    }

    private fun showMessage(message: String) {
        if (::statusText.isInitialized) statusText.text = message
    }

    override fun onDestroy() {
        handler.removeCallbacks(progressTicker)
        activeWorkObserver?.let { activeWorkLiveData?.removeObserver(it) }
        activeWorkObserver = null
        activeWorkLiveData = null
        stopLocalPreviewOnly()
        playbackListener?.let { listener -> mediaController?.removeListener(listener) }
        controllerFuture?.let { MediaController.releaseFuture(it) }
        mediaController = null
        controllerFuture = null
        albumArtExecutor.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_PICK_AUDIO = 410
        private const val REQUEST_CREATE_EXPORT = 411
        private const val REQUEST_LIBRARY_PERMISSION = 412
        private const val REQUEST_NOTIFICATION_PERMISSION = 413
        private const val UNIQUE_WORK_NAME = "sand_audio_processing_unique"
    }
}
