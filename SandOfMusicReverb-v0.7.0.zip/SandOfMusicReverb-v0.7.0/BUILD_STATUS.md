# Sand of Music Reverb v0.7.0

This source package includes the 0.6.5 offline render pipeline plus the v0.7.0 playback and library additions.

Added: AndroidX Media3 ExoPlayer + MediaSessionService, system media session/notification controls, ten genre presets, library category tabs, Favorites and My Playlist persistence, and an eight-language offline UI dictionary.

Build verification: ZIP structure and source-level checks are performed in this workspace. A full Android Gradle build must be confirmed by the GitHub Actions run; this workspace does not include the Android SDK or Gradle installation.
