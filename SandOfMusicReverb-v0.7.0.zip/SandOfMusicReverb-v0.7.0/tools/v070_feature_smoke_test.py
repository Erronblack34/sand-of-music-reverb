from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
main = (root / "app/src/main/java/com/sandofmusic/reverb/MainActivity.kt").read_text(encoding="utf-8")
manifest = ET.parse(root / "app/src/main/AndroidManifest.xml").getroot()
app_gradle = (root / "app/build.gradle.kts").read_text(encoding="utf-8")

required_presets = ["hiphop", "rock", "jazz", "afrobeats", "pop", "rnb", "edm", "phonk", "reggae", "lofi", "nightcore", "daycore", "vaporwave", "ambient"]
required_tabs = ['"tracks"', '"albums"', '"artists"', '"folders"', '"playlists"', '"favorites"']
required_languages = ["ru", "en", "ja", "zh", "tr", "uk", "be", "uz"]

for preset in required_presets:
    assert f'"{preset}"' in main, f"Missing preset: {preset}"
for tab in required_tabs:
    assert tab in main, f"Missing library section: {tab}"
lang_source = (root / "app/src/main/java/com/sandofmusic/reverb/LanguageCatalog.kt").read_text(encoding="utf-8")
for code in required_languages:
    assert f'"{code}"' in lang_source, f"Missing language: {code}"
assert "androidx.media3:media3-exoplayer:1.11.1" in app_gradle
assert "androidx.media3:media3-session:1.11.1" in app_gradle

android = "http://schemas.android.com/apk/res/android"
services = manifest.find("application").findall("service")
assert any(s.get(f"{{{android}}}name") == ".PlaybackService" for s in services)
permissions = {el.get(f"{{{android}}}name") for el in manifest.findall("uses-permission")}
assert "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" in permissions
print("v0.7.0 feature smoke checks: PASS")
